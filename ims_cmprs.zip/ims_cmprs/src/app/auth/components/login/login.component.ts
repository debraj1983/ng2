import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';

import { Observable, Subscription } from 'rxjs';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;
  public isError: boolean;
  public errMsg: string;
  public isLoging: boolean;

  public subscription: Subscription;

  constructor(
    private fb: FormBuilder,
    private route: Router
  ) {
    
  }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required, Validators.pattern('[^ @]*@[^ @]*') ]],
      password: ['', Validators.required]
    });

  }

}
