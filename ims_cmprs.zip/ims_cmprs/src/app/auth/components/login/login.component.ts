import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { AppStorageService } from '../../../services/app.storage.service';
import { AuthService } from '../../../services/auth.service';
import { Observable, Subscription } from 'rxjs';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;
  public isError: boolean;
  public errMsg: string;
  public isLoging: boolean;

  public subscription: Subscription;

  constructor(
    private fb: FormBuilder,
    private route: Router,
    private appStorageService: AppStorageService,
    private authService: AuthService
  ) {
    
  }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });

  }

  public userLogin(): void {
    const loginData = {
      username: this.loginForm.value['username'],
      password: this.loginForm.value['password']
    };
    this.checkLogin(loginData);
  }


  private checkLogin(data): void {
    if (data.username === 'admin' && data.password === 'admin') {
      this.appStorageService.setData('loggedIn', 1);
      this.appStorageService.setData('isadmin', 1);
      this.authService.isLoggedIn(true);
      this.route.navigateByUrl('/user/dashboard');
    } else if (data.username === 'user' && data.password === 'user') {
      this.appStorageService.setData('loggedIn', 1);
      this.appStorageService.setData('isadmin', 0);
      this.authService.isLoggedIn(true);
      this.route.navigateByUrl('/user/dashboard');
    } else {
      this.isError = true;
      this.errMsg = 'Invalid Username or Password';
    }
  }

}
