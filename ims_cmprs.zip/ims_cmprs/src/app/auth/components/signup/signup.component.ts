import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { CustomValidator } from '../../../shared/utility/custom.validator';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  public signUpForm: FormGroup;
  public passwordFormGroup: FormGroup;

  public firstRandom: number;
  public secondRandom: number;
  public sum: any;

  public isError = false;
  public errMsg: string;
  public isRegistration: boolean;

  constructor(private fb: FormBuilder,
    private route: Router) { }

  ngOnInit() {
    this.getRandomNumbers();

    this.passwordFormGroup = this.fb.group({
      Password: ['', Validators.required],
      RePassword: ['', Validators.required]
    }, {
      validator: CustomValidator.passwordValidator.bind(this)
    });



    this.signUpForm = this.fb.group({
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      EmailId: ['', [Validators.required, Validators.pattern('[^ @]*@[^ @]*') ] ],
      passwordFormGroup: this.passwordFormGroup,
      sumFirstSecond:  ['', Validators.required]
    });
  }


  public submitSignupForm(): void {
    this.isRegistration = true;
    const signUpObj: any = {
      'FirstName': this.signUpForm.value['FirstName'],
      'LastName': this.signUpForm.value['LastName'],
      'EmailId': this.signUpForm.value['EmailId'],
      'Password': this.signUpForm.value.passwordFormGroup['Password']
    };

    /*this.authenticationService.doSignUp(signUpObj).subscribe(
      data => {
        this.isRegistration = false;
        if (data['message'] === 'success') {
          this.appStorageService.setData('loggedIn', 1);
          this.appStorageService.setData('userData', data['data']);
          this.authService.isLoggedIn(true);
          const redirectUrl = this.appStorageService.getData('redirectUrl');
          if (redirectUrl) {
            this.route.navigateByUrl(redirectUrl);
          } else {
            this.route.navigateByUrl('/user/dashboard');
          }
        } else {
            this.isError = true;
            this.errMsg = data['data'];
        }
      },
      error => {
        Observable.throw(error);
      });*/
  }


  public getRandomNumbers(): void {
    this.firstRandom = Math.floor(Math.random() * 10) + 1;
    this.secondRandom = Math.floor(Math.random() * 99) + 11;
    this.sum = this.firstRandom + this.secondRandom;
 }

}
