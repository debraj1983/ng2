import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { GuardService, NotLoggedInGuardService } from './services/guard.service';

import { HomeComponent } from './components/home/home.component';
import { LogoutComponent } from './components/logout/logout.component';

// import { bookRoute } from './book/book-route.module';

const appRoute: Routes = [
    {
      path: '',
      component: HomeComponent
    },
    {
      path: 'home',
      component: HomeComponent
    },
    {
      path: 'book',
      loadChildren: './book/book.module#BookModule'
    },
    {
      path: 'auth',
      loadChildren: './auth/auth.module#AuthModule',
      canLoad: [NotLoggedInGuardService]
    },
    {
      path: 'admin',
      loadChildren: './admin/admin.module#AdminModule'
    },
   {
     path: 'user',
     loadChildren: './user/user.module#UserModule',
     canLoad: [GuardService]
    },
    {
      path: 'logout',
      component: LogoutComponent,
      canActivate: [GuardService]
    }
];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(
      appRoute,
      { enableTracing: false, useHash: false } // <-- debugging purposes only
    )
  ],
  declarations: []
})
export class AppRouteModule { }
