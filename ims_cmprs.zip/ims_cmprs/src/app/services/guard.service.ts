import { Injectable } from '@angular/core';
import { Router, CanLoad, CanActivate } from '@angular/router';

import { AuthService } from './auth.service';

@Injectable()
export class GuardService implements CanLoad, CanActivate {

  constructor(private route: Router,
    private authService: AuthService) { }

  public canLoad(): boolean {
    return this.checkLoggedIn();
  }

  public canActivate(): boolean {
    return this.checkLoggedIn();
  }

  private checkLoggedIn(): boolean {
    const isLoggedIn = this.authService.checkUserLoggedIn();
    if (!isLoggedIn) {
      console.log(window.location.href);
      this.route.navigate(['/auth']);
    }
   return isLoggedIn;
  }

}

@Injectable()
export class NotLoggedInGuardService implements CanLoad {

  constructor(private route: Router,
    private authService: AuthService) { }

  public canLoad(): boolean {
    const isLoggedIn = this.authService.checkUserLoggedIn();
    if (isLoggedIn) {
      this.route.navigate(['/user']);
    }
   return !isLoggedIn;
  }
}
