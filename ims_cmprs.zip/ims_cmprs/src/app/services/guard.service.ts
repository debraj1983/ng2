import { Injectable } from '@angular/core';
import { Router, CanLoad, CanActivate } from '@angular/router';

import { AuthService } from './auth.service';
import { AppStorageService } from './app.storage.service';

@Injectable()
export class GuardService implements CanLoad, CanActivate {

  constructor(private route: Router,
    private authService: AuthService) { }

  public canLoad(): boolean {
    return this.checkLoggedIn();
  }

  public canActivate(): boolean {
    return this.checkLoggedIn();
  }

  private checkLoggedIn(): boolean {
    const isLoggedIn = this.authService.checkUserLoggedIn();
    if (!isLoggedIn) {
      console.log(window.location.href);
      this.route.navigate(['/auth']);
    }
   return isLoggedIn;
  }

}

@Injectable()
export class NotLoggedInGuardService implements CanLoad {

  constructor(private route: Router,
    private authService: AuthService) { }

  public canLoad(): boolean {
    const isLoggedIn = this.authService.checkUserLoggedIn();
    if (isLoggedIn) {
      this.route.navigate(['/user']);
    }
   return !isLoggedIn;
  }
}


@Injectable()
export class CheckAdminGuardService implements CanActivate {

  constructor(private route: Router,
    private authService: AuthService,
    private appStorageService: AppStorageService) { }

  public canActivate(): boolean {
    const isLoggedIn = this.authService.checkUserLoggedIn();
    const isAdminValue = this.appStorageService.getData('isadmin');
    const isAdmin = (isAdminValue === 1) ? true : false;
    if (isLoggedIn && isAdmin) {
      return true;
    }
    this.route.navigate(['/user']);
    return false;
  }
}

@Injectable()
export class CheckUserGuardService implements CanActivate {

  constructor(private route: Router,
    private authService: AuthService,
    private appStorageService: AppStorageService) { }

  public canActivate(): boolean {
    const isLoggedIn = this.authService.checkUserLoggedIn();
    const isAdminValue = this.appStorageService.getData('isadmin');
    const isAdmin = (isAdminValue === 1) ? true : false;
    if (isLoggedIn && !isAdmin) {
      return true;
    }
    this.route.navigate(['/user']);
    return false;
  }
}