import { LmsService } from './lms.service';
import { AuthService } from './auth.service';
import { AppStorageService } from './app.storage.service';
import { GuardService, NotLoggedInGuardService } from './guard.service';
import { LoginOperationsService } from './login-operations.service';
import { UserService } from './user.service';

export const SERVICES = [
    LmsService,
    AuthService,
    AppStorageService,
    GuardService,
    NotLoggedInGuardService,
    LoginOperationsService,
    UserService
];
