import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfig } from '../constant/config';
import { Observable } from 'rxjs';




export const endPoints = {
 'getUserInfo': (url: string) => `${url}user/get`
};



export const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UserService {

  public config: any;

  constructor(private http: HttpClient) {
    this.config = AppConfig;
  }

  


}
