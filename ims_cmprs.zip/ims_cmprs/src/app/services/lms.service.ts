import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConfig } from '../constant/config';
import { Observable } from 'rxjs';

export const endPoints = {
  'getAllCategories': (url: string) => `${url}getCategory`,
};

export const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class LmsService {

  public config: any;

  constructor(private http: HttpClient) {
    this.config = AppConfig;
  }


}
