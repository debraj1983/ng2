import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { AppStorageService } from './app.storage.service';
import { UserService } from './user.service';
import { Router } from '@angular/router';

import { Observable } from 'rxjs';

import { appStaticData } from '../constant/app.constants';


export const typeObj = {
  'book': '1',
  'magazine': '2',
  'writer': '3'
};

@Injectable({
  providedIn: 'root'
})
export class LoginOperationsService {

  public isLoggedIn: boolean;

  constructor(private authService: AuthService,
              private appStorageService: AppStorageService,
              private userService: UserService,
              private route: Router) {

                authService.showNavBarEmitter.subscribe((mode) => {
                  this.isLoggedIn = mode;
                });
               }



  public getLoggedInUserID(): any {
    const user = this.getUserData();
    return (user && user.UserID) ? user.UserID : undefined;
  }

  public getLoggedInProfilePic(): any {
    const user = this.getUserData();
    return (user && user.UserImagePath && user.UserImage) ? (user.UserImagePath + '/' + user.UserImage) : undefined;
  }

  public getUserData(): any {
    return this.appStorageService.getData('userData');
  }

  public setUserData(key, data): void {
    this.appStorageService.setDataInObject('userData', key, data);
  }
}
