import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';

const STORAGE_KEY = 'pap-storage';

@Injectable()
export class AppStorageService {

  constructor(@Inject(SESSION_STORAGE) private storage: StorageService) { }

  public setData(key: string, data: any): void {
    let addedData = this.storage.get(STORAGE_KEY);
    if (!addedData) {
      addedData = {};
      addedData[key] = data;
    } else {
      addedData[key] = data;
    }
    this.storage.set(STORAGE_KEY, addedData);
  }

  public getData(key): any {
    const data = this.storage.get(STORAGE_KEY);
    return (data && data[key]) ? data[key] : null;
  }

  public setDataInObject(key: string, subkey: string, data: string) {
    const keyData = this.getData(key);
    keyData[subkey] = data;
    this.setData(key, keyData);
  }

  public clearData(): void {
    this.storage.clear();
  }

}
