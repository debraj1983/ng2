export const appStaticData = {
 'AddToFavoriteBook': 'addToFavoriteBook',
 'RedirectUrl': 'redirectUrl'
};

export const storageKeys = {
	UserData: 'user',
	CollectionKey: 'collection'
};


