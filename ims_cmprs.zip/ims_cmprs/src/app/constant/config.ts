const DOMAIN_NAME = 'http://localhost/lms_services/';
export const AppConfig = {
 'appUrl': `${DOMAIN_NAME}beta/`,
 'apiUrl': `${DOMAIN_NAME}`
};


