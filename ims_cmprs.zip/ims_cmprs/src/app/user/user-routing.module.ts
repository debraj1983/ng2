import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CheckAdminGuardService, CheckUserGuardService } from '../services/guard.service';


import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BooklistComponent } from './components/booklist/booklist.component';
import { AddbookComponent } from './components/addbook/addbook.component';
import { UserlistComponent } from './components/userlist/userlist.component';
import { MyoccupiedbookComponent } from './components/myoccupiedbook/myoccupiedbook.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';


const routes: Routes = [
  { path: '', redirectTo: 'dashboard' },
  { path: 'dashboard', component: DashboardComponent  },
  { path: 'booklist', component: BooklistComponent, canActivate: [CheckAdminGuardService]  },
  { path: 'addbook', component: AddbookComponent, canActivate: [CheckAdminGuardService]  },
  { path: 'userlist', component: UserlistComponent, canActivate: [CheckAdminGuardService]  },
  { path: 'myoccupiedbook', component: MyoccupiedbookComponent, canActivate: [CheckUserGuardService]   },
  { path: 'changepassword', component: ChangepasswordComponent  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
