import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserRoutingModule } from './user-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { BooklistComponent } from './components/booklist/booklist.component';
import { AddbookComponent } from './components/addbook/addbook.component';
import { UserlistComponent } from './components/userlist/userlist.component';
import { MyoccupiedbookComponent } from './components/myoccupiedbook/myoccupiedbook.component';
import { ChangepasswordComponent } from './components/changepassword/changepassword.component';

import { CheckAdminGuardService, CheckUserGuardService } from '../services/guard.service';


@NgModule({
  imports: [
    CommonModule,
    UserRoutingModule
  ],
  declarations: [
    DashboardComponent, 
    BooklistComponent, 
    AddbookComponent, 
    UserlistComponent, 
    MyoccupiedbookComponent, 
    ChangepasswordComponent
  ],
  providers: [ CheckAdminGuardService,
    CheckUserGuardService]
})
export class UserModule { }
