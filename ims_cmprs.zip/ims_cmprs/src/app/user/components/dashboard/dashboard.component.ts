import { Component, OnInit } from '@angular/core';
import { AppStorageService } from '../../../services/app.storage.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  public isAdmin: boolean;
  constructor(private appStorageService: AppStorageService) { }

  ngOnInit() {
    const isAdminValue = this.appStorageService.getData('isadmin');
    this.isAdmin = (isAdminValue === 1) ? true : false;
  }

}
