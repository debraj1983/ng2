import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myoccupiedbook',
  templateUrl: './myoccupiedbook.component.html',
  styleUrls: ['./myoccupiedbook.component.scss']
})
export class MyoccupiedbookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
