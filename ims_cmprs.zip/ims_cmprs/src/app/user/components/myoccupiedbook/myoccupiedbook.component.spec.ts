import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyoccupiedbookComponent } from './myoccupiedbook.component';

describe('MyoccupiedbookComponent', () => {
  let component: MyoccupiedbookComponent;
  let fixture: ComponentFixture<MyoccupiedbookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyoccupiedbookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyoccupiedbookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
