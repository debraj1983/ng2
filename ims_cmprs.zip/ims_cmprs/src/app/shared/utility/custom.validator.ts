import { FormGroup } from '@angular/forms';


export class CustomValidator {


  static passwordValidator(passwordFormGroup: FormGroup): any {
    const password = passwordFormGroup.controls.Password.value;
    const repeatPassword = passwordFormGroup.controls.RePassword.value;

    if (repeatPassword.length <= 0) {
        return null;
    }

    if (repeatPassword !== password) {
        return {
            doesMatchPassword: true
        };
    }

    return null;
  }
}
