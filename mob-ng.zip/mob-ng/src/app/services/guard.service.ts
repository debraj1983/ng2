import { Injectable } from '@angular/core';
import { Router, CanLoad, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

@Injectable()
export class GuardService implements CanLoad, CanActivate {

  constructor(private route: Router) { }

  public canLoad(): boolean {
    return this.checkLoggedIn();
  }

  public canActivate(): boolean {
    return this.checkLoggedIn();
  }

  private checkLoggedIn(): boolean {
    // const isLoggedIn = this.authService.checkUserLoggedIn();
    const isLoggedIn = false;
    if (!isLoggedIn) {
      console.log(window.location.href);
      this.route.navigate(['/auth']);
    }
   return isLoggedIn;
  }

}
