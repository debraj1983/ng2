import { LoginCommonComponent } from './login-common/login-common.component';


export const COMPONENTS = [
    LoginCommonComponent
];
