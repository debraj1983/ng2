import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-login-common',
  templateUrl: './login-common.component.html',
  styleUrls: ['./login-common.component.scss']
})
export class LoginCommonComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public loginInfo: EventEmitter<any> = new EventEmitter();

  public loginForm: FormGroup;

  constructor(
    private fb: FormBuilder
  ) { }

  ngOnInit() {

    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });

  }

  public userLogin(): void {

    console.log(this.loginForm);

    const loginData: any = {
      LoginFor: this.options.loginFor,
      Username: this.loginForm.value.username,
      Password: this.loginForm.value.password
    };
    this.loginInfo.emit(loginData);
  }

}
