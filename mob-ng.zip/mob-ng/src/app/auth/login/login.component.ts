import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public bankLoginOption: any;
  public agencyLoginOption: any;
  public merchantLoginOption: any;

  constructor() { }

  public ngOnInit() {
    this.bankLoginOption = {
      loginFor: 'bank',
      btnClass: 'bank-login-btn'
    };
    this.agencyLoginOption = {
      loginFor: 'agency',
      btnClass: 'agency-login-btn'
    };
    this.merchantLoginOption = {
      loginFor: 'merchant',
      btnClass: 'merchant-login-btn'
    };
  }

  public getLoginInfo(event): void {
    console.log(event);
  }

}
