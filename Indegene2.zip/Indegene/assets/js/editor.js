
(function(option, Base64) {
    var droppedObj = [];
    var count = 0;
    var resizerArr = ['resizer top-left', 'resizer top-right', 'resizer bottom-left', 'resizer bottom-right'];
    function draggableZone(ball, mainZone) {
        ball.addEventListener('mousedown', function(event) {
            // (2) prepare to moving: make absolute and on top by z-index
            ball.style.position = 'absolute';
            ball.style.zIndex = 1000;
            // move it out of any current parents directly into body
            // to make it positioned relative to the body
            mainZone.append(ball);
            // ...and put that absolutely positioned ball under the pointer

            moveAt(event.pageX, event.pageY);

            // centers the ball at (pageX, pageY) coordinates
            function moveAt(pageX, pageY) {
                ball.style.left = pageX - ball.offsetWidth / 2 + 'px';
                ball.style.top = pageY - ball.offsetHeight / 2 + 'px';
            }

            function onMouseMove(event) {
                moveAt(event.pageX, event.pageY);
            }

            // (3) move the ball on mousemove
            mainZone.addEventListener('mousemove', onMouseMove);

            // (4) drop the ball, remove unneeded handlers
            ball.addEventListener('mouseup', function(event) {
                mainZone.removeEventListener('mousemove', onMouseMove);
                ball.addEventListener('mouseup', null);
            });
        });
        ball.addEventListener('dragstart', function(event) {
            return false;
        });
    }
   
    var fn = {
        createView: function() {
            var viewConfig = config.viewConfig;
            var dragImages = config.draggableImages;
            var dragObjectZone = document.createElement('div');
            dragObjectZone.setAttribute('class', 'item1');
            dragObjectZone.setAttribute('id', viewConfig.dragZoneID);
            dragObjectZone.setAttribute('style', 'width:' + viewConfig.dragContainerWidth.toString() + 'px');
            if (dragImages && dragImages.length > 0) {
                for (var pos =0; pos < dragImages.length; pos++) {
                    var div = document.createElement('div');
                    var img = document.createElement('img');
                    img.setAttribute('src', dragImages[pos]);
                    img.setAttribute('id', "dragImageId" + pos);
                    img.setAttribute('width', 100); // TODO:: make it configurable
                    img.setAttribute('draggable', true); // TODO:: make it configurable
                    img.addEventListener('dragstart', function(event) {
                        event.dataTransfer.setData("text/html", event.target.id);
                    });
                    div.appendChild(img);
                    dragObjectZone.appendChild(div);
                }
            }

            var dropObjectZone = document.createElement('div');
            dropObjectZone.setAttribute('class', 'item2');
            dropObjectZone.setAttribute('id', viewConfig.dropZoneID);
            dropObjectZone.setAttribute('style', 'width:'+(window.innerWidth-viewConfig.dragContainerWidth)+'px');

            dropObjectZone.addEventListener('dragover', function(event) {
                event.preventDefault();
              });
              dropObjectZone.addEventListener('drop', function(event) {
                event.preventDefault();
                var data=event.dataTransfer.getData("text/html");
                /* If you use DOM manipulation functions, their default behavior it not to copy but to alter and move elements. By appending a ".cloneNode(true)", you will not move the original element, but create a copy. */
                var nodeCopy = document.getElementById(data).cloneNode(true);
                nodeCopy.id = "droppedObjID_"+count;
                count++;
                draggableZone(nodeCopy, dropObjectZone);



               /* var div = document.createElement('div');
                div.setAttribute('class', 'resizable');

                var divCh1 = document.createElement('div');
                divCh1.setAttribute('class', 'resizers');

                for(var elem = 0; elem < resizerArr.length; elem++) {
                    var divCh2 = document.createElement('div');
                    divCh2.setAttribute('class', resizerArr[elem]);
                    divCh1.appendChild(divCh2);
                }
                divCh1.appendChild(nodeCopy);
                div.appendChild(divCh1);*/
                // event.target.appendChild(div);
                nodeCopy.addEventListener('click', function(event) {
                    
                });
                droppedObj.push(nodeCopy);
                event.target.appendChild(nodeCopy);
              });

            document.getElementById(viewConfig.containerId).append(dragObjectZone);
            document.getElementById(viewConfig.containerId).append(dropObjectZone);
        },
        setEditorBackground: function() {
            var editorID = option.editorBg.blockId;
            var width = document.getElementById(editorID).offsetWidth;
            var height = document.getElementById(editorID).offsetHeight;
            var gap = option.editorBg.gap;
            var strokeColor = option.editorBg.strokeColor;

            var svg = '<svg width="'+width+'" height="'+height+'" xmlns="http://www.w3.org/2000/svg">';
            for(var x = 0; x <= height; x+=gap) {
                svg += '<line x1="0" x2="'+width+'" y1="'+x+'" y2="'+x+'" stroke="'+strokeColor+'" stroke-width="1" />'
            }
            for(var y = 0; y <= width; y+=gap) {
                svg += '<line x1="'+y+'" x2="'+y+'" y1="0" y2="'+height+'" stroke="'+strokeColor+'" stroke-width="1" />'
            }
            svg += '</svg>';
            document.getElementById(editorID).style.backgroundImage = "url('data:image/svg+xml;base64,"+Base64.encode(svg)+"')";
        }, init: function() {
            this.createView();
            this.setEditorBackground();
        }
    };

    fn.init(); 
})(config, Base64);

