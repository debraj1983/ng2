/*var svg = document. createElementNS("http://www.w3.org/2000/svg", "svg");
        // set width and height
        svg.setAttribute("width", width);
        svg.setAttribute("height", height);

            // horizontal stroke
            for(var x = 0; x <= height; x+=gap) {
                var h = document. createElementNS("http://www.w3.org/2000/svg", "line");
                h.setAttribute("x1", 0);
                h.setAttribute("y1", x);
                h.setAttribute("x2", width);
                h.setAttribute("y2", x);
                h.setAttribute("stroke", strokeColor);
                h.setAttribute("stroke-width", 1);
                svg.appendChild(h);
            }
        
            // vertical stroke
            for(var y = 0; y <= width; y+=gap) {
                var v = document. createElementNS("http://www.w3.org/2000/svg", "line");
                v.setAttribute("x1", y);
                v.setAttribute("y1", 0);
                v.setAttribute("x2", y);
                v.setAttribute("y2", height);
                v.setAttribute("stroke", strokeColor);
                v.setAttribute("stroke-width", 1);
                svg.appendChild(v);
            } <!-- <div
      class="geBackgroundPage"
      style="
        position: absolute;
        border-width: 1px;
        overflow: hidden;
        left: 285px;
        top: 517px;
        width: 849px;
        height: 1099px;
        border-color: rgb(255, 255, 255);
        border-style: solid;
        background-color: rgb(255, 255, 255);
        background-image: url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0iIzdGMDBGRiIgb3BhY2l0eT0iMC4yIiBzdHJva2Utd2lkdGg9IjEiLz48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjN0YwMEZGIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=');
        background-position: -1px -1px;
      "
    ></div>-->*/