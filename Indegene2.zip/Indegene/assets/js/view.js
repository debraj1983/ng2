var createView = function() {
    
    return function(viewConfig, dragImages) {
        console.log(viewConfig, dragImages);
        var dragObjectZone = document.createElement('div');
        dragObjectZone.setAttribute('class', 'item1');
        
        if (dragImages && dragImages.length > 0) {
            for (var pos =0; pos < dragImages.length; pos++) {
                var div = document.createElement('div');
                var img = document.createElement('img');
                img.setAttribute('src', dragImages[pos]);
                img.setAttribute('width', 100); // TODO:: make it configurable
                img.setAttribute('draggable', true); // TODO:: make it configurable
                div.appendChild(img);
                dragObjectZone.appendChild(div);
            }
        }
        document.getElementById(viewConfig.containerId).append(dragObjectZone);
    }

};