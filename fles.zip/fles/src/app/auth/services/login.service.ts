import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    'Authorization': 'my-auth-token'
  })
};

export const endPoints = {
  bankLogin: environment.apiUrls.login.bankLogin,
  agentLogin: environment.apiUrls.login.agentLogin,
  merchantLogin: environment.apiUrls.login.merchantLogin,
  signUp: environment.apiUrls.signUp
};

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }


  public doSignUp(payload: any): Observable<any> {
    return this.http.post(endPoints.signUp, payload, httpOptions);
  }


  public decideAndCallLoginService(loginFor: string, userName: string, password: string): Observable<any> {
    if (!loginFor) {
      console.log('Error Occurred!!');
    }

    switch(loginFor) {
      case 'bank':
          return this.bankLogin(userName, password);
        break;
      case 'agency':
          return this.agencyLogin(userName, password);
        break;
      case 'merchant':
          return this.merchantLogin(userName, password);
        break;
    }
  }

  private bankLogin(userName: string, password: string): Observable<any> {
    const payload = {
      loginId: userName,
      pass: password
    };
    return this.http.post(endPoints.bankLogin, payload, httpOptions);
  }

  private agencyLogin(userName: string, password: string): Observable<any> {
    const payload = {
      loginId: userName,
      pass: password
    };
    return this.http.post(endPoints.agentLogin, payload, httpOptions);
  }

  private merchantLogin(userName: string, password: string): Observable<any> {
    const payload = {
      loginId: userName,
      pass: password
    };
    return this.http.post(endPoints.merchantLogin, payload, httpOptions);
  }
}
