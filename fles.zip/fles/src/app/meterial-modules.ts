import { MatFormFieldModule } from '@angular/material/form-field';

export const METERIAL = [
    MatFormFieldModule
];
