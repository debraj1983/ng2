import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agency-home',
  templateUrl: './agency-home.component.html',
  styleUrls: ['./agency-home.component.scss']
})
export class AgencyHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
