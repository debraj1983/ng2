import { LoginCommonComponent } from './login-common/login-common.component';
import { HeaderComponent } from './header/header.component';
import { BankSignupComponent } from './bank-signup/bank-signup.component';
import { AgencySignupComponent } from './agency-signup/agency-signup.component';
import { MerchantSignupComponent } from './merchant-signup/merchant-signup.component';

export const COMPONENTS = [
    LoginCommonComponent,
    HeaderComponent,
    BankSignupComponent,
    AgencySignupComponent,
    MerchantSignupComponent
];
