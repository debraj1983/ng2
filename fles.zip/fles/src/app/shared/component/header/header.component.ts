import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AuthService } from '../../../services/auth.service';
import { AppStorageService } from '../../../services/app-storage.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public isLoggedIn: boolean = false;
  constructor(private authService: AuthService,
    private appStorageService: AppStorageService,
    private route: Router) { }

  ngOnInit() {
    this.authService.showNavBarEmitter.subscribe((mode)=>{
      console.log(mode);
      this.isLoggedIn = mode;
     });
  }

  public logout(): void {
    this.appStorageService.clearData();
    this.authService.checkLoggedIN();
    this.route.navigate(['/auth']);
  }
}
