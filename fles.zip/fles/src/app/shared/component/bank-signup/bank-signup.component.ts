import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-bank-signup',
  templateUrl: './bank-signup.component.html',
  styleUrls: ['./bank-signup.component.scss']
})
export class BankSignupComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public backToLogin: EventEmitter<any> = new EventEmitter();

  @Output()
  public bankSignUpDataObj: EventEmitter<any> = new EventEmitter();

  public bankSignUpForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.bankSignUpForm = this.fb.group({
      uniqueId: ['', [Validators.required]],
      name: ['', Validators.required],
      password: ['', Validators.required],
      domainName: ['', Validators.required]
    });
  }

  public bankSignUp(): void {
    const bankSignUpSata: any = {
      uniqueId: this.bankSignUpForm.value.uniqueId,
      name: this.bankSignUpForm.value.name,
      password: this.bankSignUpForm.value.password,
      domainName: this.bankSignUpForm.value.domainName,
      role: AC.ROLE.BANK
    };
    this.bankSignUpDataObj.emit(bankSignUpSata);
  }

  public backToLoginView(): void {
    this.backToLogin.emit();
  }

}
