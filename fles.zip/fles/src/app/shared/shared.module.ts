import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { COMPONENTS } from './component/index';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { METERIAL } from '../meterial-modules';


@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgxMyDatePickerModule.forRoot(),
    ...METERIAL
  ],
  exports: [
    ...COMPONENTS
  ]
})
export class SharedModule { }
