import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchant-home',
  templateUrl: './merchant-home.component.html',
  styleUrls: ['./merchant-home.component.scss']
})
export class MerchantHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
