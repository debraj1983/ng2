import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bank-home',
  templateUrl: './bank-home.component.html',
  styleUrls: ['./bank-home.component.scss']
})
export class BankHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
