import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { LoginService } from '../services/login.service';
import { AppStorageService } from '../../services/app-storage.service';
import { AuthService } from '../../services/auth.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public bankLoginOption: any;
  public agencyLoginOption: any;
  public merchantLoginOption: any;

  public isBankSignUp: boolean;
  public isAgencySignUp: boolean;
  public isMerchantSignUp: boolean;

  @ViewChild('bankLoginModalID', {static: false}) bankLoginModalID: ElementRef;
  @ViewChild('agencyLoginModalID', {static: false}) agencyLoginModalID: ElementRef;
  @ViewChild('merchantLoginModalID', {static: false}) merchantLoginModalID: ElementRef;


  constructor(private loginService: LoginService,
              private route: Router,
              private appStorageService: AppStorageService,
              private authService: AuthService) { }

  public ngOnInit() {
    this.initiateSignUp();
    this.bankLoginOption = {
      loginFor: 'bank',
      btnClass: 'bank-login-btn',
      linkClass: 'bank-sign-up'
    };
    this.agencyLoginOption = {
      loginFor: 'agency',
      btnClass: 'agency-login-btn',
      linkClass: 'agency-sign-up'
    };
    this.merchantLoginOption = {
      loginFor: 'merchant',
      btnClass: 'merchant-login-btn',
      linkClass: 'merchant-sign-up'
    };
  }

  public getLoginInfo(event): void {
    console.log(event);
    this.navigateToPage(event.LoginFor);
    this.authService.checkLoggedIN();

/*
    this.loginService.decideAndCallLoginService(event.LoginFor, event.Password, event.Username).subscribe(data => {
        switch(event.LoginFor) {
          case 'bank':
              this.appStorageService.setData('bankLoggedIn', 1);
              this.route.navigateByUrl('/bank');
            break;
          case 'agency':
              this.appStorageService.setData('agencyLoggedIn', 1);
              this.route.navigateByUrl('/agency');
            break;
          case 'merchant':
              this.appStorageService.setData('merchantLoggedIn', 1);
              this.route.navigateByUrl('/merchant');
            break;
        }
    });

*/
    
  }


  public setSignUpInfo(loginFor: string): void {
    this.initiateSignUp();
    switch (loginFor) {
      case 'bank':
          this.isBankSignUp = true;
          break;
      case 'agency':
          this.isAgencySignUp = true;
          break;
      case 'merchant':
          this.isMerchantSignUp = true; 
          break;
    }
  }

  public backToLoginView(): void {
    this.initiateSignUp();
  }

  public doBankSignUp(payload: any): void {
    this.navigateToPage('bank');
    /*this.loginService.doSignUp(payload).subscribe( data => {
      // Need to write code
    });*/
  }

  public doAgencySignUp(payload: any): void {
    this.navigateToPage('agency');
    /*this.loginService.doSignUp(payload).subscribe( data => {
      // Need to write code
    });*/
  }

  public doMerchantSignUp(payload: any): void {
    // console.log(payload);
    this.navigateToPage('merchant');
    /*this.loginService.doSignUp(payload).subscribe( data => {
      // Need to write code
    });*/
  }

  private initiateSignUp(): void {
    this.isBankSignUp = false;
    this.isAgencySignUp = false;
    this.isMerchantSignUp = false;
  }

  private navigateToPage(to: any): void {
    console.log('--->'+to);
    switch (to) {
      case 'bank':
        this.appStorageService.setData('bankLoggedIn', 1);
        this.bankLoginModalID.nativeElement.click();
        this.route.navigateByUrl('/bank');
        break;
    case 'agency':
        this.appStorageService.setData('agencyLoggedIn', 1);
        this.agencyLoginModalID.nativeElement.click();
        this.route.navigateByUrl('/agency');
        break;
    case 'merchant':
        this.appStorageService.setData('merchantLoggedIn', 1);
        this.merchantLoginModalID.nativeElement.click();
        this.route.navigateByUrl('/merchant');
        break;
    }
  }

}
