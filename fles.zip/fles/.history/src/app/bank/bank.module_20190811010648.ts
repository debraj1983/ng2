import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { BankHomeComponent } from './components/bank-home/bank-home.component';
import { BankRoutingModule } from './bank-routing.module';
import { BankService } from './service/bank.service';
import { BankComponent } from './bank.component';

import { RequestComponent } from './components/request/request.component';
import { ProfileComponent } from './components/profile/profile.component';
import { HeaderComponent } from './components/header/header.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { SettingsComponent } from './components/settings/settings.component';

@NgModule({
  declarations: [BankHomeComponent,
    BankComponent,
    RequestComponent,
    ProfileComponent,
    HeaderComponent,
    SidenavComponent,
    SettingsComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    BankRoutingModule
  ],
  providers: [BankService]
})
export class BankModule { }
