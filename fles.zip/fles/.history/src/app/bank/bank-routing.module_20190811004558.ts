import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BankHomeComponent } from './components/bank-home/bank-home.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UploadDocumentsComponent } from './components/upload-documents/upload-documents.component';
import { RequestComponent } from './components/request/request.component';
import { BankComponent } from './bank.component';

const routes: Routes = [ 
  { path: '', component: BankHomeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BankRoutingModule { }
