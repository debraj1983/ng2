import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { AgencyHomeComponent } from './components/agency-home/agency-home.component';
import { AgencyRoutingModule } from './agency-routing.module';

import { AgencyService } from './service/agency.service';
import { AgencyComponent } from './agency.component';

@NgModule({
  declarations: [AgencyHomeComponent, AgencyComponent],
  imports: [
    CommonModule,
    SharedModule,
    AgencyRoutingModule
  ],
  providers: [AgencyService]
})
export class AgencyModule { }
