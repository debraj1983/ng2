import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgencyHomeComponent } from './components/agency-home/agency-home.component';

import { AgencyComponent } from './agency.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RequestComponent } from './components/request/request.component';

const routes: Routes = [ 
  {
    path: '',
    component: AgencyComponent,
    children: [
      {path: 'dashboard', component: AgencyHomeComponent},
      {path: 'profile', component: ProfileComponent},
      {path: 'request', component: RequestComponent},
    ]}, {
      path: '',
      redirectTo: 'dashboard',
      pathMatch: 'full',
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgencyRoutingModule { }
