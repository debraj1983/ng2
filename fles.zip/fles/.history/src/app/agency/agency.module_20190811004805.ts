import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { AgencyHomeComponent } from './components/agency-home/agency-home.component';
import { AgencyRoutingModule } from './agency-routing.module';

import { AgencyService } from './service/agency.service';
import { AgencyComponent } from './agency.component';
import { ProfileComponent } from './components/profile/profile.component';
import { HeaderComponent } from './components/header/header.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { RequestComponent } from './components/request/request.component';

@NgModule({
  declarations: [
    AgencyHomeComponent,
    AgencyComponent,
    RequestComponent,
    ProfileComponent,
    HeaderComponent,
    SidenavComponent],
  imports: [
    CommonModule,
    SharedModule,
    AgencyRoutingModule
  ],
  providers: [AgencyService]
})
export class AgencyModule { }
