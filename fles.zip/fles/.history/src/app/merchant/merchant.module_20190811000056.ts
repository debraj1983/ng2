import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { MerchantHomeComponent } from './components/merchant-home/merchant-home.component';
import { MerchantRoutingModule } from './merchant-routing.module';

import { MerchantService } from './service/merchant.service';
import { RequestComponent } from './components/request/request.component';
import { UploadDocumentsComponent } from './components/upload-documents/upload-documents.component';
import { ProfileComponent } from './components/profile/profile.component';
import { HeaderComponent } from './components/header/header.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';

@NgModule({
  declarations: [MerchantHomeComponent, RequestComponent, UploadDocumentsComponent, ProfileComponent, HeaderComponent, SidenavComponent],
  imports: [
    CommonModule,
    SharedModule,
    MerchantRoutingModule
  ],
  providers: [MerchantService]
})
export class MerchantModule { }
