import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MerchantHomeComponent } from './components/merchant-home/merchant-home.component';
import { UploadDocumentsComponent } from './components/upload-documents/upload-documents.component';
import { RequestComponent } from './components/request/request.component';

const routes: Routes = [
  {
    path: '',
    component: MerchantHomeComponent,
    children: [
      {path: 'profile', component: ProfileComponent},
      {path: 'request', component: RequestComponent},
      {path: 'upload', component: UploadDocumentsComponent}
    ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MerchantRoutingModule { }
