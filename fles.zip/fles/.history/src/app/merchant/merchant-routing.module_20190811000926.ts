import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MerchantHomeComponent } from './components/merchant-home/merchant-home.component';
import { ProfileComponent } from './components/profile/profile.component';
import { RequestComponent } from './components/request/request.component';

const routes: Routes = [
  {
    path: '',
    component: MerchantHomeComponent,
    children: [
      {path: 'profile', component: ProfileComponent},
      {path: 'profile', component: ProfileComponent},
      {path: 'profile', component: ProfileComponent},
      {path: 'profile', component: ProfileComponent}
    ]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MerchantRoutingModule { }
