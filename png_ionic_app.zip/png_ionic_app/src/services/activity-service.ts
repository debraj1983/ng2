
import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { ACTIVITIES } from "./mock-activities";

export class reward {
  name: String;
  reward: number;

  constructor(name:string, reward:number){
    this.name = name;
    this.reward = reward
  }
}


@Injectable()
export class ActivityService {
  private activities: any;
  private totalTokens: number = 0;
  rewardList : Array<reward>;

  constructor(
    public httpClient: HttpClient
  ) {
    this.activities = ACTIVITIES;
  }

  getTokens() {
    return this.totalTokens;
  };

  setTokens(tokens: number) {
    this.totalTokens = tokens;
  };

  getRewards(): any {
    console.log("Get Rewards API");
    this.rewardList = JSON.parse(localStorage.getItem("rewardsList"));
    // console.log(this.rewardList);
    return this.rewardList;
  }

  setRewards(name: string, tokens: number) {
    console.log("Set Rewards API");
    this.rewardList = JSON.parse(localStorage.getItem("rewardsList"));
    // console.log(this.rewardList);

    let item = {
      name:name,
      reward: tokens
    }

    this.rewardList.push(item);
    console.log(this.rewardList);

    localStorage.setItem("rewardsList", JSON.stringify(this.rewardList));
  }

  getAll() {
    return this.activities;
  }

  getItem(id) {
    for (var i = 0; i < this.activities.length; i++) {
      if (this.activities[i].id === parseInt(id)) {
        return this.activities[i];
      }
    }
    return null;
  }

  remove(item) {
    this.activities.splice(this.activities.indexOf(item), 1);
  }
}
