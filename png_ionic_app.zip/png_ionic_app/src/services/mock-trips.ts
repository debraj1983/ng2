export let TRIPS = [
  {
    id: 1,
    videoId:"aC7lbdD1hq0",
    name: "P&G: The Look",
    reward: 150,
    time: "1:43",
    earnStatus: "0",
    thumb:"assets/img/trip/thumb/THELOOK_promo_TW_LI.jpg"
  },
  {
    id: 2,
    videoId:"rdQrwBVRzEg",
    name: "P&G: Thank You, Mom ",
    reward: 200,
    time: "2:16",
    earnStatus: "0",
    thumb:"assets/img/trip/thumb/pg-strong-ep-2016.jpg"
  },
  {
    id: 3,
    videoId:"uFI5CiiSH0w",
    name: "P&G: Shiksha 'The story of Bittu'",
    reward: 180,
    time: "1:57",
    earnStatus: "0",
    thumb:"assets/img/trip/thumb/Fi-21-may-14-1.jpg"
  }

  
]