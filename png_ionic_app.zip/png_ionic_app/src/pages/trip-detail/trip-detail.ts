import {Component, Inject} from "@angular/core";
import { NavParams, NavController, ViewController} from "ionic-angular";
import { DOCUMENT } from "@angular/common";

@Component({
  selector: 'page-trip-detail',
  templateUrl: 'trip-detail.html'
})
export class TripDetailPage {

  videoId: number;
  public YT: any;
  public player: any;
  public reframed = false;
  public madalDismissData: any;
  public data = {
    id: this.videoId,
    time: null
  };

  isRestricted = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

  constructor(
    public viewCtrl: ViewController,
    public navCtrl: NavController,
    public navParams: NavParams,
    @Inject(DOCUMENT) private document,
  ) {
    console.log('VideoId', navParams.get('videoId'));
    this.videoId = navParams.get('videoId');
    this.initVideo(this.videoId);
  }
 
  ionViewDidLoad() {
    console.log('ionViewDidLoad NewModalPage');
  }

  closeModal() {
    console.log("Closing Modal");
    this.data.time = this.cleanTime();
    this.player = null;
    window['YT'] = null;
    this.viewCtrl.dismiss(this.data);
  }

  // ? 2. Initialize method for YT IFrame API
  public initVideo(video: any): void {
    console.log("Init Video");
    // ? Return if Player is already created
    if (window['YT']) {
      this.startVideo(video);
      return;
    }

    // ? Creating a script element using elementRef for running the required scripts supported by youtube js api
    const tag = this.document.createElement('script');
    tag.src = 'https://www.youtube.com/iframe_api';
    const firstScriptTag = this.document.getElementsByTagName('script')[0];
    firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);

    window['onYouTubeIframeAPIReady'] = () => this.startVideo(video);
  }

  // ? 3. Video player creation, styles and other params
  public startVideo(video: any): void {
    console.log("Start Video");
    this.reframed = false;
    this.player = new window['YT'].Player("youtube-video-player", {
      videoId: video,
      playerVars: {
        autoplay: 1,
        modestbranding: 1,
        controls: 1,
        disablekb: 1,
        rel: 0,
        showinfo: 0,
        fs: 0,
        playsinline: 1
      },
      height: '216px',
      width: '100%',
      events: {
        'onStateChange': this.onPlayerStateChange.bind(this),
        'onError': this.onPlayerError.bind(this, video),
        'onReady': this.onPlayerReady.bind(this),
      }
    });
  }

  // ? 4. It will be called when the Video Player is ready
  public onPlayerReady(event): void {
    if (this.isRestricted) {
      event.target.mute(); // mute the video
      event.target.playVideo();
    } else {
      event.target.playVideo();
    }
  }

  // ? 5. API will call this function when Player State changes like PLAYING, PAUSED, ENDED
  public onPlayerStateChange(event): void {
    console.log(event);
  }

  public cleanTime(): number {
    return Math.round(this.player.getCurrentTime());
  }

  public onPlayerError(event, video): void {
    switch (event.data) {
      case 2:
        console.log('' + video);
        break;
      case 100:
        break;
      case 101 || 150:
        break;
    }
  }
  
}