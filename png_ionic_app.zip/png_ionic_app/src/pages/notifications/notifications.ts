import { Component } from "@angular/core";
import { ViewController } from "ionic-angular";

@Component({
  selector: 'page-notifications',
  templateUrl: 'notifications.html'
})

export class NotificationsPage {

  notifications = [
    {
      color: "secondary",
      icon: "mail",
      value: "Hola! 200 Tokens Credited"
    },
  ];
  constructor(public viewCtrl: ViewController) {
  }

  close() {
    this.viewCtrl.dismiss();
  }

}
