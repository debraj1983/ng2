import { Component } from "@angular/core";
import { NavController, ToastController } from "ionic-angular";
import { LoginPage } from "../login/login";

@Component({
  selector: 'page-register',
  templateUrl: 'register.html'
})
export class RegisterPage {

  constructor(public nav: NavController, public toastCtrl: ToastController) {
  }

  // register and go to home page
  register(fullname, email, password) {
    if ((fullname.value != null && email.value != null && password.value != null) || (fullname.value != undefined && email.value != undefined && password.value != undefined)) {
      sessionStorage.setItem("fullname", fullname.value);
      sessionStorage.setItem("email", email.value);
      sessionStorage.setItem("password", password.value);
      sessionStorage.setItem("welcome", "false");
      let toast = this.toastCtrl.create({
        message: 'Registration Successful',
        duration: 1500,
        position: 'bottom',
        cssClass: 'dark-trans',
        closeButtonText: 'OK',
        // showCloseButton: true
      });
      toast.present();
      this.nav.setRoot(LoginPage);
    }
    else {
      let toast = this.toastCtrl.create({
        message: 'Email or Password cannot be null/undefined',
        duration: 1500,
        position: 'bottom',
        cssClass: 'dark-trans',
        closeButtonText: 'OK',
        // showCloseButton: true
      });
      toast.present();
    }
  }
  // go to login page
  login() {
    this.nav.setRoot(LoginPage);
  }

}
