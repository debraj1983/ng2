import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { HomePage } from '../home/home';
import { SettingsPage } from '../settings/settings';
import { ActivityService, reward } from '../../services/activity-service';
// import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'page-local-weather',
  templateUrl: 'local-weather.html'
})
export class LocalWeatherPage {

  rewardsList: Array<reward>;
  totalTokens: number = 0;
  constructor(
    public nav: NavController, public activityService: ActivityService) {
    this.rewardsList = this.activityService.getRewards();
    this.rewardsList.forEach(item => {
      this.totalTokens += item.reward;
    });
  }

  changeTab(tab: string) {
    console.log("Selected Tab is : ", tab);
    if (tab == 'rewards')
      this.nav.setRoot(LocalWeatherPage);
    else if (tab == 'dashboard')
      this.nav.setRoot(HomePage);
    else if (tab == 'settings')
      this.nav.setRoot(SettingsPage);
  }
}