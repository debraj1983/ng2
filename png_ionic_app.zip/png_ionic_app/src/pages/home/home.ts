import { ActivityService, reward } from './../../services/activity-service';
import { Component, OnInit, ViewChild } from "@angular/core";
import { NavController, PopoverController, ModalController, ToastController } from "ionic-angular";

import { NotificationsPage } from "../notifications/notifications";
import { SettingsPage } from "../settings/settings";
import { TripService } from "../../services/trip-service";
import { TripDetailPage } from "../trip-detail/trip-detail";
import { Slides } from 'ionic-angular';
import { FotoProvider } from '../../services/foto';
import { LocalWeatherPage } from '../local-weather/local-weather';
import { Storage } from "@ionic/storage";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})

export class HomePage implements OnInit {

  public trips: any;
  madalDismissData: string;
  @ViewChild('slides') slides: Slides;
  slideOpts = {
    initialSlide: 3,
    speed: 400
  };
  photos: string[];
  public tokens = 0;
  fullname: string;
  // rewardsList = [];
  rewardList: Array<reward> = [];

  constructor(
    public nav: NavController,
    public popoverCtrl: PopoverController,
    public tripService: TripService,
    public modalCtrl: ModalController,
    public activityService: ActivityService,
    public fotoService: FotoProvider,
    private toastCtrl: ToastController,
    private storage: Storage,
  ) {
    this.fullname = sessionStorage.getItem("fullname");
    this.trips = tripService.getAll();
    this.getTokens();
  }

  getTokens() {
    this.tokens = 0;
    this.rewardList = this.activityService.getRewards();
    console.log(this.rewardList);
    this.rewardList.forEach(item => {
      this.tokens += item.reward;
    });
  }

  ngOnInit(): void {
    this.fotoService.loadSaved();
    let toast = this.toastCtrl.create({
      message: 'Welcome to P&G loyality platform. You will be rewarded with 200 Tokens as a welcome gift.',
      // duration: 3000,
      position: 'middle',
      showCloseButton: true,
      closeButtonText: "Ok"
    });
    toast.onDidDismiss(() => {
      console.log('Dismissed toast');
      sessionStorage.setItem("welcome", "true");
    });
    if (sessionStorage.getItem("welcome") == "false")
      toast.present();
  }

  // to go account page
  goToAccount() {
    this.nav.push(SettingsPage);
  }

  presentNotifications(myEvent) {
    console.log(myEvent);
    let popover = this.popoverCtrl.create(NotificationsPage);
    popover.present({
      ev: myEvent
    });
  }

  viewDetail(video) {
    console.log(video);
    sessionStorage.setItem("video", JSON.stringify(video));
    const profileModal = this.modalCtrl.create(TripDetailPage, {
      videoId: video
    }, {
        enableBackdropDismiss: false,
        enterAnimation: 'enter-animation',
        leaveAnimation: 'leave-animation'
      });
    profileModal.onDidDismiss(data => {
      // console.log(data);
      this.madalDismissData = data;
      this.analyseVideo(this.madalDismissData);
    });
    profileModal.present();
  }

  analyseVideo(data): any {
    console.log("Time Viewed(in seconds): ", data);
    if (data.time > 80) {
      console.log("Reward Awarded");
      let video = JSON.parse(sessionStorage.getItem('video'))
      console.log("Video Details", video);
      let toast = this.toastCtrl.create({
        message: 'Congrats, Rewards will be credited shortly!',
        duration: 1500,
        position: 'bottom'
      });
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
        this.activityService.setRewards(video.name, video.reward);
      });
      toast.present();
    } else {
      console.log("Please complete the video to get the reward");
      let toast = this.toastCtrl.create({
        message: 'Sorry, Watch the complete video to earn the reward.',
        duration: 1500,
        position: 'bottom'
      });
      toast.onDidDismiss(() => {
        console.log('Dismissed toast');
      });
      toast.present();
    }
  }

  getStatus(event: any) {
    console.log(event);
  }

  next() {
    this.slides.slideNext();
  }

  prev() {
    this.slides.slidePrev();
  }

  updateTokens() {

    let toast = this.toastCtrl.create({
      message: 'Congrats, Rewards will be credited shortly!',
      duration: 1500,
      position: 'bottom',
    });
    toast.onDidDismiss(() => {
      this.activityService.setRewards("Bill Rewards", 894);
      console.log('Dismissed toast');
      this.fotoService.fotos = [];
      this.storage.set("fotos", null);
      this.getTokens();
    });
    toast.present();

  }

  openPage() {
    this.nav.setRoot(LocalWeatherPage);
  }

  changeTab(tab: string) {
    console.log("Selected Tab is : ", tab);
    if (tab == 'rewards')
      this.nav.setRoot(LocalWeatherPage);
    else if (tab == 'dashboard')
      this.nav.setRoot(HomePage);
    else if (tab == 'settings')
      this.nav.setRoot(SettingsPage);
  }
}