import storage from "./AppStorage";

const STORAGE_KEYS = {
  LOGGEDIN: "loggedIn"
};

const storageUtility = {
  checkLoggedIn: () => storage.getData(STORAGE_KEYS.LOGGEDIN, "session")
};

export default storageUtility;
