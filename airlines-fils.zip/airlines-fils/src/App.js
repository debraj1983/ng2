import React from "react";
import "./App.scss";
import utility from "./Utility/StorageUtility";
import Login from "./Login/Login";

class App extends React.Component {
  render() {
    return (
      <div className="App">
        {utility.checkLoggedIn() ? <div>Logged In</div> : <Login />}
      </div>
    );
  }
}

export default App;
