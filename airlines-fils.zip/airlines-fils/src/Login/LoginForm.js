import React from "react";

class LoginForm extends React.Component {
  render() {
    return (
      <div className="row">
        <div className="col-lg-4 col-md-6 col-sm-12 mx-auto mt-5">
          <div className="card text-left">
            <div className="card-header">Login</div>
            <div className="card-body">
              <form onSubmit={this.props.doLogin}>
                <div className="form-group">
                  <label htmlFor="loginId">Login ID</label>
                  <input
                    type="text"
                    className="form-control"
                    id="loginId"
                    name="loginId"
                    placeholder="Enter Login ID"
                    onChange={this.props.changeData}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="password">Password</label>
                  <input
                    type="password"
                    className="form-control"
                    id="password"
                    name="password"
                    placeholder="Password"
                    onChange={this.props.changeData}
                    required
                  />
                </div>
                <button type="submit" className="btn btn-primary">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default LoginForm;
