import * as types from "../actionTypes";
import { getApiCall } from "../../ApiCall/apiCalls";

const baseUrl = "http://localhost:3001/";
export const doLoginAction = payload => {
  return function(dispatch, getState) {
    return getApiCall(baseUrl + "Users").then(data => {
      const user = data.find(
        elem =>
          elem.userId === payload.loginId && elem.password === payload.password
      );
      console.log(user);
    });
  };
};
