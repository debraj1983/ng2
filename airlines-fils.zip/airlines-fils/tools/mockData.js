const names = [
  "Aaron Poynter",
  "Adell Norton",
  "Al Dusek",
  "Alanna Balsamo",
  "Alayna Mullin",
  "Alex Wiley",
  "Alise Hindle",
  "Allegra Lindsey",
  "Annabel Fisher",
  "Antonetta Marshal",
  "Becky Baty",
  "Boyd Smoak",
  "Breanna Fine",
  "Bree Ramirez",
  "Caleb Deluna",
  "Camilla Ehrenberg",
  "Carlo Stcyr",
  "Cassidy Swett",
  "Cassie Loyd",
  "Charley Mcdermott",
  "Chase Ausmus",
  "Chauncey Dahm",
  "Chi Cannady",
  "Christine Rueda",
  "Claire Garbett",
  "Cleotilde Beaton",
  "Cleta Epperson",
  "Clifford Kaup",
  "Clifton Batiste",
  "Connie Freiberg",
  "Daisey Bojorquez",
  "Danial Robins",
  "Darcie Melecio",
  "Darrel Cork",
  "Dayle Labarre",
  "Delilah Lui",
  "Deloras Valcourt",
  "Delsie Rothwell",
  "Dennise Patillo",
  "Dion Dantin",
  "Dominque Vankirk",
  "Donna Sabala",
  "Donya Lema",
  "Dorene Meuser",
  "Dorian Gerrard",
  "Douglass Stephenson",
  "Doyle Pergande",
  "Earl Okada",
  "Earnest Norby",
  "Edison Patillo",
  "Efrain Dunkerson",
  "Elaine Wint",
  "Elba Langone",
  "Elsy Fripp",
  "Elvia Taillon",
  "Emery Pederson",
  "Emile Maglio",
  "Erna Diener",
  "Estelle Kulesza",
  "Eusebio Brinkley",
  "Evelia Raimondi",
  "Evelynn Windholz",
  "Ezra Kahl",
  "Fatimah Mccane",
  "Faye Zoll",
  "Florentina Testerman",
  "Frida Connally",
  "Garland Milholland",
  "Gilbert Linney",
  "Gillian Kiely",
  "Gino Pakele",
  "Gisela Jakubowski",
  "Glennis Frigo",
  "Gloria Allman",
  "Gloria Phelps",
  "Hannelore Trisler",
  "Harry Kallas",
  "Hien Bakley",
  "Hipolito Crotty",
  "Ida Sons",
  "Ilda Daigre",
  "Ilona Aust",
  "Irmgard Coady",
  "Janel Mccaster",
  "Janis Letellier",
  "Jasmin Spurrier",
  "Jeanna Botts",
  "Jenifer Cygan",
  "Jesica Anstett",
  "Jesus Pickle",
  "Jim Iriarte",
  "Joane Opp",
  "Joleen Tisby",
  "Jose Kirst",
  "Josefina Salvaggio",
  "Joseph Begley",
  "Joye Richeson",
  "Julene Durante",
  "Jules Jawad",
  "Juli Troy",
  "Julieann Hinojos",
  "Julienne Brinn",
  "Karan Corkery",
  "Karyn Wolfrum",
  "Kasey Kehrer",
  "Kassandra Washington",
  "Kathi Leitzel",
  "Katie Jolicoeur",
  "Kenyatta Koll",
  "Keven Hayner",
  "Kiara Chittum",
  "Kimberely Marshell",
  "Kiyoko Brizendine",
  "Kristi Gardner",
  "Lanell Pleas",
  "Larraine Rivard",
  "Larue Kiley",
  "Lashaunda Page",
  "Latrice Hardin",
  "Latrisha Lambert",
  "Lavonia Courser",
  "Lavonne Eastburn",
  "Leena Pegues",
  "Leone Madere",
  "Leonora Desai",
  "Lizeth Miera",
  "Lola Rawls",
  "Londa Munk",
  "Lonna Packard",
  "Lovella Down",
  "Lynette Mebane",
  "Macy Newingham",
  "Maile Sim",
  "Major Delara",
  "Malisa Batie",
  "Marcelo Puls",
  "Margeret Ference",
  "Marilou Greenfield",
  "Mattie Hindman",
  "Melvin Armwood",
  "Merrill Reiter",
  "Micheline Obey",
  "Micheline Zachery",
  "Mike Divens",
  "Milda Arellano",
  "Milford Motley",
  "Mina Kisling",
  "Monet Orange",
  "Myrtie Mcdonalds",
  "Nana Luck",
  "Naoma Claire",
  "Naomi Yarbrough",
  "Nelle Savoy",
  "Ngoc Vannatta",
  "Nidia Lenzen",
  "Nikita Kovar",
  "Nita Wolk",
  "Nu Chipley",
  "Onita Matlock",
  "Otha Gillingham",
  "Palma Bracken",
  "Palma Gratz",
  "Pasty Fogleman",
  "Pasty Hutzler",
  "Percy Olivero",
  "Phyliss Janz",
  "Pilar Flanders",
  "Porter Handy",
  "Queen Maio",
  "Rhett Cowger",
  "Rhoda Eastman",
  "Rhonda Klotz",
  "Rick Mccolley",
  "Rigoberto Hetzel",
  "Robt Lutes",
  "Sanora Harju",
  "Sebrina Aikens",
  "Shane Wilcoxen",
  "Shaunna Schermerhorn",
  "Shawnta Calico",
  "Sherri Danna",
  "Shirley Meigs",
  "Soo Donoho",
  "Stephine Christenberry",
  "Takisha Moncada",
  "Tameika Mcconville",
  "Temeka Thornton",
  "Terra Morneau",
  "Tianna Hillyard",
  "Tim Soliman",
  "Trula Sarro",
  "Vanita Strahan",
  "Vena Reddell",
  "Warner Huseman",
  "Yee Belcher",
  "Yoko Kellogg",
  "Yoshie Mcclinton",
  "Young Weinmann",
  "Zaida Wattley",
  "Zane Frawley"
];

// Data for Users
const Users = [
  {
    id: 1,
    userId: "admin",
    password: "asd",
    role: "admin",
    type: "admin"
  },
  {
    id: 2,
    userId: "staff1",
    password: "asd",
    role: "staff",
    type: "checkin"
  },
  {
    id: 3,
    userId: "staff1",
    password: "asd",
    role: "staff",
    type: "inflight"
  }
];

const flightDetails = [
  {
    id: 1,
    flightNo: "6E-713",
    airlinesName: "Indigo",
    fromTo: "BLR-CCU",
    departureTime: "16:00",
    arrivalTime: "18:45",
    seats: {
      rows: 30,
      seatSequence: ["A", "B", "C", "D", "E", "F"]
    },
    Passengers: []
  },
  {
    id: 2,
    flightNo: "6E-2135",
    airlinesName: "Indigo",
    fromTo: "BLR-DEL",
    departureTime: "13:40",
    arrivalTime: "16:25",
    seats: {
      rows: 30,
      seatSequence: ["A", "B", "C", "D", "E", "F"]
    },
    Passengers: []
  }
];

function LoadFlightDetails(flightDetails) {
  const modifiedFlightDetails = flightDetails.map(element => {
    const passengers = GetPassengerObj(element.seats);
    element["Passengers"] = [...passengers];
    return element;
  });
  return modifiedFlightDetails;
}

function GetPassengerObj(seatData) {
  const passengers = [];
  let c = 0;
  for (let i = 1; i <= seatData.rows; i++) {
    seatData.seatSequence.forEach(element => {
      const checkedIn = GetRandomValue([true, false]);
      const hasMealOption = GetRandomValue([true, false]);
      const obj = {
        checkedIn: checkedIn,
        hasWheelChair: checkedIn ? GetRandomValue([true, false]) : false,
        hasMealOption: checkedIn ? hasMealOption : false,
        hasInfant: checkedIn ? GetRandomValue([true, false]) : false,
        mealType: hasMealOption ? GetRandomValue(["veg", "nonveg"]) : "",
        passengerName: names[c],
        seatNo: checkedIn ? `${i}${element}` : ""
      };
      passengers.push(obj);
      c++;
    });
  }
  return passengers;
}

function GetRandomValue(Items) {
  return Items[Math.floor(Math.random() * Items.length)];
}

const FlightData = LoadFlightDetails(flightDetails);

// Using CommonJS style export so we can consume via Node (without using Babel-node)
module.exports = {
  Users,
  FlightData
};
