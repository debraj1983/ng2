// Data for Users
const Users = [
  {
    id: 1,
    userId: "admin",
    password: "asd",
    role: "admin",
    type: "admin"
  },
  {
    id: 2,
    userId: "staff1",
    password: "asd",
    role: "staff",
    type: "checkin"
  },
  {
    id: 3,
    userId: "staff1",
    password: "asd",
    role: "staff",
    type: "inflight"
  }
];

const flightDetails = [
  {
    id: 1,
    flightNo: "6E-713",
    airlinesName: "Indigo",
    fromTo: "BLR-CCU",
    departureTime: "16:00",
    arrivalTime: "18:45",
    seats: {
      rows: 30,
      seat_sequence: ["A", "B", "C", "D", "E", "F"]
    },
    Passengers: []
  },
  {
    id: 2,
    flightNo: "6E-2135",
    airlinesName: "Indigo",
    fromTo: "BLR-DEL",
    departureTime: "13:40",
    arrivalTime: "16:25",
    seats: {
      rows: 30,
      seat_sequence: ["A", "B", "C", "D", "E", "F", "G", "H", "I"]
    },
    Passengers: []
  }
];

const Passengers = [
  {
    id: 1,
    flightId: 1,
    seatNo: "3A"
  }
];
