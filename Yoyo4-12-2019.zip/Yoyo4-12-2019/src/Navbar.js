import React from 'react';
import { Link } from 'react-router-dom';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  txtAlign: {
    textAlign: 'right',
  },
});

const Navbar = props => {
  const classes = useStyles();
  return (
    <List component="nav">
      <ListItem component="div">
        <ListItemText inset className={classes.txtAlign}>
          <Link to="/gift-card-list" className="Yoyo-MuiHeaderLink">
            Gift Card List
          </Link>
          <Link to="/cart" className="Yoyo-MuiHeaderLink">
            Cart
          </Link>
          {!props.isLoggedIn ? (
            <Link className="Yoyo-MuiHeaderLink" to="/login">
              Login
            </Link>
          ) : (
            <>
              <Link className="Yoyo-MuiHeaderLink" to="/user-account">
                My Account
              </Link>
              <Link className="Yoyo-MuiHeaderLink" to="/logout">
                Logout
              </Link>
              <button type="button" className="btn btn-warning">
                Yoyo Balance{' '}
                <span className="badge badge-light">{props.yoyoBalance}</span>
              </button>
            </>
          )}
        </ListItemText>
      </ListItem>
    </List>
  );
};

export default Navbar;
