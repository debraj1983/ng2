import React from 'react';
import { connect } from 'react-redux';
import storageUtility from '../Utility/StorageUtility';
import { YoyoRedeemCode } from '../AppConstant';

import {
  getOrderHistoryAction,
  getYoyoTransactionAction,
  addYoyoBalanceAction,
  updateYoyoTransactionAction,
} from '../Store/actions/OrderAction';

import UserAccountView from '../Components/UserAccount/UserAccount';

class UserAccount extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      addedYoyoCode: '',
      status: '',
    };
    this.validateAndUpdateYoyo = this.validateAndUpdateYoyo.bind(this);
    this.changeData = this.changeData.bind(this);
  }
  componentDidMount() {
    const user = storageUtility.getLoggedInUserData();
    this.props.getOrderHistory(user.id);
    this.props.getTransactionHistory(user.id);
  }

  changeData(event) {
    const { value } = event.target;
    this.setState({ ...this.state, addedYoyoCode: value });
  }

  validateAndUpdateYoyo(event) {
    event.preventDefault();
    const yoyoRedeemCard = YoyoRedeemCode.find(
      elem => elem.code === this.state.addedYoyoCode
    );
    if (yoyoRedeemCard) {
      let userObject = { ...this.props.loginData.loggedInData };
      userObject.yoyoBalance = userObject.yoyoBalance + yoyoRedeemCard.yoyoBal;
      const user = storageUtility.getLoggedInUserData();
      const payload = { ...userObject };
      this.props.addYoyoBalance(user.id, payload);

      // Update Transaction History
      const payloadTran = {
        userId: user.id,
        amount: yoyoRedeemCard.yoyoBal,
        transactionType: 'credit',
      };
      this.props.updateYoyoTransaction(payloadTran);
      this.setState({ addedYoyoCode: '', status: 'success' });
    } else {
      this.setState({ ...this.state, status: 'invalid' });
    }
  }

  render() {
    return (
      <UserAccountView
        userData={this.props.loginData}
        order={this.props.order}
        changeData={this.changeData}
        validateAndUpdateYoyo={this.validateAndUpdateYoyo}
        addedStatus={this.state.status}
      ></UserAccountView>
    );
  }
}

const mapStateToProps = state => ({
  ...state,
});

const mapDispatchToProps = dispatch => ({
  getOrderHistory: id => dispatch(getOrderHistoryAction(id)),
  getTransactionHistory: id => dispatch(getYoyoTransactionAction(id)),
  addYoyoBalance: (id, payload) => dispatch(addYoyoBalanceAction(id, payload)),
  updateYoyoTransaction: payload =>
    dispatch(updateYoyoTransactionAction(payload)),
});

export default connect(mapStateToProps, mapDispatchToProps)(UserAccount);
