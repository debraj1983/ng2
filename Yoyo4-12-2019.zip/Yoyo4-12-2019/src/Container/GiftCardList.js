import React from 'react';
import { connect } from 'react-redux';
import { getCategoryListAction } from '../Store/actions/CategoryAction';
import {
  getGiftCardListAction,
  getGiftCardSearchAction,
} from '../Store/actions/GiftCardAction';
import {
  resetSearchStoreAction,
  searchTxtAction,
} from '../Store/actions/SearchAction';
import GiftCardListMain from '../Components/GiftCardList/GiftCardListView';

class GiftCardList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTxt: '',
    };
  }
  componentDidMount() {
    this.props.getCatList();
    this.props.getGiftCards();
  }

  componentDidUpdate(prevProps, prevState) {
    if (
      this.props.search &&
      this.props.search.data &&
      this.props.search.data !== prevState.searchTxt
    ) {
      this.setState({ searchTxt: this.props.search.data });
      this.props.getGiftSearch(this.props.search.data);
    }

    if (this.props.search && this.props.search.reset) {
      this.props.setResetSearchStore(false);
      this.props.setSearchTxtToStore('');
      this.setState({ searchTxt: '' });
      this.props.getGiftCards();
    }
  }

  render() {
    return (
      <GiftCardListMain
        categories={this.props.categories}
        giftcards={this.props.giftcards}
      ></GiftCardListMain>
    );
  }
}

const mapStateToProps = state => ({
  ...state,
});

const mapDispatchToProps = dispatch => ({
  getCatList: () => dispatch(getCategoryListAction()),
  getGiftCards: () => dispatch(getGiftCardListAction()),
  getGiftSearch: q => dispatch(getGiftCardSearchAction(q)),
  setResetSearchStore: data => dispatch(resetSearchStoreAction(data)),
  setSearchTxtToStore: data => dispatch(searchTxtAction(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(GiftCardList);
