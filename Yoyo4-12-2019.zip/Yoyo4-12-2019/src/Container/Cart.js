import React from 'react';
import { withRouter } from 'react-router-dom';
import storageUtility from '../Utility/StorageUtility';
import CartView from '../Components/Cart/CartView';

class Cart extends React.Component {
  constructor(props) {
    super(props);
    this.checkAndNavigate = this.checkAndNavigate.bind(this);
    this.navigateToShopMore = this.navigateToShopMore.bind(this);
  }

  checkAndNavigate() {
    if (storageUtility.checkLoggedIn()) {
      this.props.history.push('/add-information');
    } else {
      this.props.history.push('/login');
      storageUtility.setRedirectTo('/add-information');
    }
  }

  navigateToShopMore() {
    this.props.history.push('/gift-card-list');
  }

  render() {
    return (
      <CartView
        cartItems={storageUtility.getCartData()}
        checkAndNavigate={this.checkAndNavigate}
        navigateToShopMore={this.navigateToShopMore}
      ></CartView>
    );
  }
}

export default withRouter(Cart);
