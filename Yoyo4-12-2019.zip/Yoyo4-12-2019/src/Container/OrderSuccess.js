import React from 'react';

class OrderSuccess extends React.Component {
  render() {
    return (
      <div className="alert alert-success" role="alert">
        Order Successfully Placed
      </div>
    );
  }
}

export default OrderSuccess;
