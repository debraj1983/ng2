import React from 'react';

const TransactionHistory = props => {
  const transactionHistory = props.transactionHistory;
  const unitTimeToDate = unixTimestamp => {
    const date = new Date(unixTimestamp);
    return `${date.getDate()}-${date.getMonth() +
      1}-${date.getFullYear()} ${date.getHours()}: ${date.getMinutes()}: ${date.getSeconds()}`;
  };
  return (
    <>
      {transactionHistory && transactionHistory.length > 0 ? (
        <div>
          <table className="table table-bordered">
            <thead className="thead-light">
              <tr>
                <th scope="col">Transaction Date</th>
                <th scope="col">Yoyo Point</th>
                <th scope="col">Type</th>
              </tr>
            </thead>
            <tbody>
              {transactionHistory.map((tH, index) => (
                <tr key={index}>
                  <td>{unitTimeToDate(tH.createdAt)}</td>
                  <td>{tH.amount}</td>
                  <td>{tH.transactionType}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default TransactionHistory;
