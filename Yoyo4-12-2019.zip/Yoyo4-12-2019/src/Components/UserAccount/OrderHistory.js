import React from 'react';

const OrderHistory = props => {
  const orderHistory = props.orderHistory;
  return (
    <>
      {orderHistory && orderHistory.length > 0 ? (
        <div>
          <table className="table table-bordered">
            <thead className="thead-light">
              <tr>
                <th scope="col">Gift Card</th>
                <th scope="col">Yoyo Point</th>
                <th scope="col">Friend</th>
              </tr>
            </thead>
            <tbody>
              {orderHistory.map((oH, index) => (
                <tr key={index}>
                  <td>
                    {oH.name}
                    <br />
                    Card Value: {oH.cardValue}
                  </td>
                  <td>{oH.yoyoPoint}</td>
                  <td>
                    {oH.friendName}
                    <br />
                    {oH.friendEmail}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default OrderHistory;
