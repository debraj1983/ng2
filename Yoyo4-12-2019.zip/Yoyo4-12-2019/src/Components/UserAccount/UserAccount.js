import React, { useState, useEffect } from 'react';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';

import { makeStyles } from '@material-ui/core/styles';

import UserProfile from './UserProfile';
import OrderHistory from './OrderHistory';
import TransactionHistory from './TransactionHistory';
import AddYoyoBalance from './AddYoyoBalance';

const useStyles = makeStyles({
  cardBlock: {
    margin: 0,
  },
  heading: {
    fontSize: '20px',
    fontWeight: 'bold',
  },
  card: {
    minWidth: 200,
    minHeight: 250,
    border: '1px solid #CCC',
    margin: '5px',
    height: '100%',
  },
});

const UserAccountView = props => {
  const [userData, setUserData] = useState({});
  const [orderHistory, setOrderHistory] = useState([]);
  const [transactionHistory, setTransactionHistory] = useState([]);
  useEffect(() => {
    setUserData(props.userData.loggedInData);
    setOrderHistory(props.order.orderHistory);
    setTransactionHistory(props.order.userTransactionHistory);
  }, [
    props.userData.loggedInData,
    props.order.orderHistory,
    props.order.transactionHistory,
    props.order.userTransactionHistory,
  ]);

  const classes = useStyles();

  return (
    <>
      <Grid container spacing={12}>
        <Grid item xs={12} sm={6} lg={6} xl={6} className={classes.cardBlock}>
          <Paper>
            <Card className={classes.card}>
              <CardHeader
                className={classes.heading}
                title="My Profile"
              ></CardHeader>
              <CardContent>
                <UserProfile userData={userData}></UserProfile>
              </CardContent>
            </Card>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} lg={6} xl={6} className={classes.cardBlock}>
          <Paper>
            <Card className={classes.card}>
              <CardHeader
                className={classes.heading}
                title="Add Yoyo Balance"
              ></CardHeader>
              <CardContent>
                <AddYoyoBalance
                  validateAndUpdateYoyo={props.validateAndUpdateYoyo}
                  addedStatus={props.addedStatus}
                  changeData={props.changeData}
                ></AddYoyoBalance>
              </CardContent>
            </Card>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} lg={6} xl={6} className={classes.cardBlock}>
          <Paper>
            <Card className={classes.card}>
              <CardHeader
                className={classes.heading}
                title="Transaction History"
              ></CardHeader>
              <CardContent>
                <TransactionHistory
                  transactionHistory={transactionHistory}
                ></TransactionHistory>
              </CardContent>
            </Card>
          </Paper>
        </Grid>
        <Grid item xs={12} sm={6} lg={6} xl={6} className={classes.cardBlock}>
          <Paper>
            <Card className={classes.card}>
              <CardHeader
                className={classes.heading}
                title="My Orders"
              ></CardHeader>
              <CardContent>
                <OrderHistory orderHistory={orderHistory}></OrderHistory>
              </CardContent>
            </Card>
          </Paper>
        </Grid>
      </Grid>
    </>
  );
};

export default UserAccountView;
