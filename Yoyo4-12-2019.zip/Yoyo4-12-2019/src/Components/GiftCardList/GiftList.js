import React from 'react';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import { makeStyles } from '@material-ui/core/styles';

import GiftCard from './GiftCard';

const useStyles = makeStyles({
  cardBlock: {
    margin: 0,
  },
});

const GiftList = props => {
  const classes = useStyles();
  return (
    <>
      <Grid container spacing={12}>
        {props.gifts &&
          props.gifts.length > 0 &&
          props.gifts.map((gift, index) => (
            <Grid
              item
              xs={12}
              sm={6}
              lg={4}
              xl={3}
              className={classes.cardBlock}
            >
              <Paper>
                <GiftCard
                  pos={index}
                  gift={gift}
                  key={`card${index}`}
                ></GiftCard>
              </Paper>
            </Grid>
          ))}
      </Grid>

      {props.gifts && props.gifts.length === 0 ? (
        <div className="w-100 mt-1 alert alert-danger" role="alert">
          No Gift Card Found
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default GiftList;
