import React from 'react';
import Button from '@material-ui/core/Button';
import Drawer from '@material-ui/core/Drawer';
import TuneIcon from '@material-ui/icons/Tune';
import { makeStyles } from '@material-ui/core/styles';

import Checkbox from './Checkbox';

const useStyles = makeStyles({
  btn: {
    color: '#FFF',
    backgroundColor: '#0e6470',
    marginLeft: '5px',
    '&:hover': {
      backgroundColor: '#0e6470',
    },
  },
  filterTitle: {
    paddingLeft: '10px',
    fontWeight: 'bold',
  },
  ulCls: {
    paddingLeft: '10px',
  },
  ulClsChild: {
    paddingLeft: '20px',
  },
});

const CardListFilter = props => {
  const classes = useStyles();
  const cat = props.categoryData;
  return (
    <>
      <Button
        className={classes.btn}
        onClick={props.toggleDrawer('left', true)}
      >
        <TuneIcon></TuneIcon> Filter Gift Cards
      </Button>
      <Drawer
        open={props.drawerState.left}
        onClose={props.toggleDrawer('left', false)}
      >
        <div className={classes.filterTitle}>Categories</div>
        <ul className={classes.ulCls}>
          {cat &&
            cat.length > 0 &&
            cat.map((c, index) => (
              <li key={`cat${c.id}_${index}`}>
                <Checkbox
                  id={c.id}
                  index={index}
                  subIndex="-1"
                  checked={c.checked}
                  isSelect={props.isSelectCategory}
                  label={c.name}
                  value={`${index}_-1`}
                />
                <ul className={classes.ulClsChild}>
                  {c.subCategory &&
                    c.subCategory.length &&
                    c.subCategory.map((sC, subIndex) => (
                      <li key={`cat${sC.id}_${index}_${subIndex}`}>
                        <Checkbox
                          id={sC.id}
                          index={index}
                          subIndex={subIndex}
                          checked={sC.checked}
                          isSelect={props.isSelectCategory}
                          label={sC.name}
                          value={`${index}_${subIndex}`}
                        />
                      </li>
                    ))}
                </ul>
              </li>
            ))}
        </ul>
        <div className={classes.filterTitle}>Price Range</div>
        <ul className={classes.ulCls}>
          {props.priceFilter.map((pF, index) => (
            <li key={`pricekey${index}`}>
              <Checkbox
                id={`id_${pF.id}`}
                index={index}
                checked={pF.checked}
                isSelect={props.isSelectPrice}
                label={`Price ${pF.startRange} - ${pF.endRange}`}
                value={`${pF.startRange}_${pF.endRange}`}
              />
            </li>
          ))}
        </ul>
        <div className={classes.filterTitle}>Dicount</div>
        <ul className={classes.ulCls}>
          {props.discoutFilter.map((pF, index) => (
            <li key={`pricekey${index}`}>
              <Checkbox
                id={`id_${pF.id}`}
                index={index}
                checked={pF.checked}
                isSelect={props.isDiscout}
                label={`${pF.discount}%`}
                value={pF.discount}
              />
            </li>
          ))}
        </ul>
      </Drawer>
    </>
  );
};

export default CardListFilter;
