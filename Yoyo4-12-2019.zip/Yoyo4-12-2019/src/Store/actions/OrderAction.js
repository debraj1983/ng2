import * as types from "../actionTypes";
import { postApiCall, getApiCall, putApiCall } from "../../ApiCall/apiCalls";
import { updateUserSuccessAction } from "./UserAction";
import storageUtility from "../../Utility/StorageUtility";

export const updateOrderSuccessAction = data => ({
  type: types.ORDER_PLACED,
  data
});

export const orderHistoryAction = data => ({
  type: types.USER_ORDER_HISTORY,
  data
});

export const orderTransactionAction = data => ({
  type: types.ORDER_TRANSACTION_HISTORY,
  data
});

export const userTransactionAction = data => ({
  type: types.USER_TRANSACTION_HISTORY,
  data
});

export const updateOrderAction = payload => {
  return function(dispatch, getState) {
    return postApiCall("UsersOrder", payload).then(data => {
      dispatch(updateOrderSuccessAction(data));
    });
  };
};

export const updateYoyoTransactionAction = payload => {
  return function(dispatch, getState) {
    return postApiCall("YoyoPaymentHistory", payload).then(data => {
      dispatch(orderTransactionAction(data));
    });
  };
};

export const getYoyoTransactionAction = id => {
  return function(dispatch, getState) {
    return getApiCall("YoyoPaymentHistory/?userId=" + id).then(data => {
      dispatch(userTransactionAction(data));
    });
  };
};

export const getOrderHistoryAction = id => {
  return function(dispatch, getState) {
    return getApiCall("UsersOrder/?userId=" + id).then(data => {
      dispatch(orderHistoryAction(data));
    });
  };
};

export const addYoyoBalanceAction = (id, payload) => {
  return function(dispatch, getState) {
    return putApiCall("Users/" + id, payload).then(data => {
      storageUtility.setLoggedInUserData(data);
      dispatch(updateUserSuccessAction(data));
    });
  };
};
