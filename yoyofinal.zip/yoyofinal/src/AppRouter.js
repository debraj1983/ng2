import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { makeStyles } from '@material-ui/core/styles';

import { RouteConfig } from './AppConstant';
import Header from './Components/Shared/Header';
import Footer from './Components/Shared/Footer';

const styles = makeStyles(theme => ({
  giftBodySection: {
    paddingTop: 80,
    paddingBottom: 80,
    [theme.breakpoints.down('sm')]: {
      paddingTop: 120,
    },
    [theme.breakpoints.down('xs')]: {
      paddingTop: 120,
    },
  },
}));

const AppRouter = props => {
  const classes = styles();
  return (
    <Router>
      <Header userData={props.loginData}></Header>
      <div className={classes.giftBodySection}>
        <Switch>
          {RouteConfig.map((config, index) => (
            <Route
              path={config.path}
              exact
              component={config.component}
              key={`route${index}`}
            />
          ))}
        </Switch>{' '}
      </div>
      <Footer userData={props.loginData}></Footer>
    </Router>
  );
};

export default AppRouter;

/*            <div key={index}>
{config.protected ? (
                <ProtectedRouter
                  path={config.path}
                  loggedIn={this.props.loginData}
                  component={config.component}
                  key={`protectedroute${index}`}
                />
              ) : ()}
            </div>*/
