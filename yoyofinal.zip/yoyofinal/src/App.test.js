import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { Provider as ReduxProdiver } from 'react-redux';
import configureStore from './Store/store';

it('renders without crashing', () => {
  const div = document.createElement('div');
  ReactDOM.render(
    <ReduxProdiver store={configureStore()}>
      <App />
    </ReduxProdiver>,
    div
  );
  ReactDOM.unmountComponentAtNode(div);
});
