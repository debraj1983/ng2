import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

const useStyles = makeStyles({
  root: {
    width: '90%',
    overflowX: 'hidden',
    margin: '0 auto',
  },
  table: {
    width: '100%',
  },
});
const OrderHistory = props => {
  const classes = useStyles();
  const orderHistory = props.orderHistory;
  return (
    <>
      {orderHistory && orderHistory.length > 0 ? (
        <div>
          <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Gift Card</TableCell>
                <TableCell>Yoyo Point</TableCell>
                <TableCell>Friend</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {orderHistory.map((oH, index) => (
                <TableRow key={index}>
                  <TableCell>
                    {oH.name}
                    <br />
                    Card Value: {oH.cardValue}
                  </TableCell>
                  <TableCell>{oH.yoyoPoint}</TableCell>
                  <TableCell>
                    {oH.friendName}
                    <br />
                    {oH.friendEmail}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default OrderHistory;
