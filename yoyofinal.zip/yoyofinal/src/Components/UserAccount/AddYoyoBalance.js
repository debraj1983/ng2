import React from 'react';
import { makeStyles } from '@material-ui/core/styles';

import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles({
  card: {
    maxWidth: 400,
    border: '1px solid #CCC',
    margin: '0 auto',
  },
  title: {
    fontSize: 14,
  },
  invalid: {
    color: '#F00',
  },
  success: { color: '#14380a' },
  btnCls: {
    backgroundColor: '#0e6470',
  },
});
const AddYoyoBalance = props => {
  const classes = useStyles();
  return (
    <>
      <form onSubmit={props.validateAndUpdateYoyo}>
        {props.addedStatus && props.addedStatus === 'invalid' ? (
          <div className={classes.invalid}>Invalid Code</div>
        ) : (
          <>
            {props.addedStatus && props.addedStatus === 'success' ? (
              <div className={classes.success}>Coupon Successfully Added</div>
            ) : (
              ''
            )}
          </>
        )}
        <TextField
          id="entercode"
          label="Enter Yoyo Code"
          variant="outlined"
          margin="dense"
          name="yoyocode"
          onChange={props.changeData}
          type="text"
          fullWidth={true}
        />
        <Button
          variant="contained"
          color="secondary"
          type="submit"
          className={classes.btnCls}
        >
          Add Balance
       </Button>
      </form>
    </>
  );
};

export default AddYoyoBalance;
