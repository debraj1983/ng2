import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Header = props => {
  const [yoyoBalance, setYoyoBalance] = useState('');
  const [isLoggedIn, serIsLoggedIn] = useState(false);
  useEffect(() => {
    if (
      props.userData &&
      props.userData.loggedInData &&
      props.userData.loggedInData.yoyoBalance
    ) {
      setYoyoBalance(props.userData.loggedInData.yoyoBalance);
      serIsLoggedIn(true);
    } else {
      serIsLoggedIn(false);
    }
  }, [props.userData]);
  return (
    <>
      <header
        className="header-bg position-fixed w-100 h100 p-2"
        style={{ zIndex: 10 }}
      >
        <div className="d-flex flex-row justify-content-between align-items-center">
          <div className="p-2 bd-highlight">
            <h5 className=" font-weight-bold font-20 text-white">YoyoGift</h5>
          </div>
          <div className="p-2 bd-highlight w-auto">
            <form onSubmit={props.doSearch}>
              <input
                placeholder="Search here"
                type="text"
                className="form-control search-txt float-left"
                name="search"
                onChange={props.changeData}
              />
              <button
                type="submit"
                className="btn btn-light search-btn float-left mr-2"
              >
                Search
              </button>
              &nbsp;
              <button
                type="button"
                className="btn btn-light search-btn  float-left"
                onClick={() => props.resetSearch()}
              >
                Reset
              </button>
            </form>
          </div>
          <div className="p-2 bd-highlight">
            <nav className="my-2 my-md-0 mr-md-3">
              <Link className="p-2 text-white" to="/gift-card-list">
                Gift Card List
              </Link>
              <Link className="p-2 text-white" to="/cart">
                Cart
              </Link>
              {!isLoggedIn ? (
                <Link className="p-2 text-white" to="/login">
                  Login
                </Link>
              ) : (
                <>
                  <Link className="p-2 text-white" to="/user-account">
                    My Account
                  </Link>
                  <Link className="p-2 text-white" to="/logout">
                    Logout
                  </Link>
                  <button type="button" className="btn btn-warning">
                    Yoyo Balance{' '}
                    <span className="badge badge-light">{yoyoBalance}</span>
                  </button>
                </>
              )}
            </nav>
          </div>
        </div>
      </header>
    </>
  );
};

export default Header;
