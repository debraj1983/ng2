import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { makeStyles } from '@material-ui/core/styles';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import withWidth from '@material-ui/core/withWidth';

import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Hidden from '@material-ui/core/Hidden';

import PersonIcon from '@material-ui/icons/Person';
import HomeIcon from '@material-ui/icons/Home';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import LockOpenIcon from '@material-ui/icons/LockOpen';
import MonetizationOnIcon from '@material-ui/icons/MonetizationOn';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import Button from '@material-ui/core/Button';

const useStyles = makeStyles(theme => ({
  appBar: {
    top: 'auto',
    bottom: 0,
  },
  yoyoBalColor: {
    color: '#FFF',
  },
  menuCenter: {
    textAlign: 'center',
  },
}));

const Footer = props => {
  const [yoyoBalance, setYoyoBalance] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  useEffect(() => {
    if (
      props.userData &&
      props.userData.loggedInData &&
      props.userData.loggedInData.yoyoBalance
    ) {
      setYoyoBalance(props.userData.loggedInData.yoyoBalance);
      setIsLoggedIn(true);
    } else {
      setIsLoggedIn(false);
    }
  }, [props.userData]);

  const classes = useStyles();
  return (
    <>
      <Hidden only={['xl', 'lg']}>
        <AppBar color="default" position="fixed" className={classes.appBar}>
          <Toolbar>
            <Grid container spacing={0}>
              <Grid item xs={12}>
                <Paper>
                  <div className={classes.menuCenter}>
                    <Link to="/gift-card-list">
                      <Button color="primary" className={classes.yoyoBalColor}>
                        <HomeIcon />
                      </Button>
                    </Link>
                    <Link to="/cart">
                      <Button color="primary" className={classes.yoyoBalColor}>
                        <ShoppingCartIcon />
                      </Button>
                    </Link>
                    {!isLoggedIn ? (
                      <Link to="/login">
                        <Button
                          color="primary"
                          className={classes.yoyoBalColor}
                        >
                          <LockOpenIcon />
                        </Button>
                      </Link>
                    ) : (
                      <>
                        <Link to="/user-account">
                          <Button
                            color="primary"
                            className={classes.yoyoBalColor}
                          >
                            <PersonIcon />
                          </Button>
                        </Link>{' '}
                        <Button
                          color="primary"
                          className={classes.yoyoBalColor}
                        >
                          <MonetizationOnIcon />
                          <span>{yoyoBalance}</span>
                        </Button>
                        <Link to="/logout">
                          <Button
                            color="primary"
                            className={classes.yoyoBalColor}
                          >
                            <ExitToAppIcon />
                          </Button>
                        </Link>
                      </>
                    )}
                  </div>
                </Paper>
              </Grid>
            </Grid>
          </Toolbar>
        </AppBar>
      </Hidden>
    </>
  );
};

Footer.propTypes = {
  width: PropTypes.oneOf(['lg', 'md', 'sm', 'xl', 'xs']).isRequired,
};

export default withWidth()(Footer);
