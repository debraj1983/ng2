import React, { useState, useEffect } from 'react';

import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  cardBlock: {
    margin: 0,
  },
  card: {
    minWidth: 200,
    border: '1px solid #CCC',
    margin: '5px',
    height: '100%',
  },
});
const PreviewOrderView = props => {
  const [orderItems, setOrderItems] = useState([]);
  useEffect(() => {
    setOrderItems(props.toPlaceOrder);
  }, [props.toPlaceOrder]);

  const classes = useStyles();
  return (
    <>
      <Grid container>
        {orderItems.map((item, index) => (
          <Grid
            item
            xs={12}
            sm={6}
            lg={4}
            xl={3}
            key={index.toString()}
            className={classes.cardBlock}
          >
            <Paper>
              <Card className={classes.card}>
                <CardHeader title="Yoyo gift card"></CardHeader>
                <CardContent>
                  <Typography variant="h5" color="textSecondary" gutterBottom>
                    {item.name}
                  </Typography>
                  <Typography variant="h6" color="textSecondary" gutterBottom>
                    {item.cardValue} INR
                  </Typography>
                  <p className="card-text">
                    Friend's Name: {item.friendName}
                    <br />
                    Friend's Email: {item.friendEmail}
                  </p>
                </CardContent>
              </Card>
            </Paper>
          </Grid>
        ))}
      </Grid>
      <div className="m-5">
        <div className="row">
          <Button
            variant="contained"
            color="secondary"
            onClick={() => props.submitOrder()}
          >
            Place Order
          </Button>
        </div>
      </div>
    </>
  );
};

export default PreviewOrderView;
