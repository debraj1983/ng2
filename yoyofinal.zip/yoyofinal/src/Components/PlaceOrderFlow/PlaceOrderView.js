import React, { useState, useEffect } from 'react';
import { Redirect } from 'react-router-dom';

import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import storageUtility from '../../Utility/StorageUtility';

const useStyles = makeStyles({
  root: {
    width: '90%',
    overflowX: 'hidden',
    margin: '0 auto',
  },
  table: {
    minWidth: 650,
  },
  pageHeding: {
    fontSize: '20px',
  },
  btnCls: {
    backgroundColor: '#0e6470',
  },
  warning: {
    backgroundColor: '#fabe46',
  },
});

const PlaceOrderView = props => {
  const [formElementData, setFormElementData] = useState([]);
  const [yoyoBalance, setYoyoBalance] = useState(0);
  const [previewOrder, setPreviewOrder] = useState(false);

  useEffect(() => {
    if (props.addedItems && props.addedItems.length > 0) {
      let modifiedCart = props.addedItems.map(item => {
        return { ...item, friendName: '', friendEmail: '' };
      });
      setFormElementData(modifiedCart);
    }

    if (
      props.userData &&
      props.userData.loggedInData &&
      props.userData.loggedInData.yoyoBalance
    ) {
      setYoyoBalance(props.userData.loggedInData.yoyoBalance);
    }
  }, [props.addedItems, props.userData]);

  const changeData = event => {
    const { name, value } = event.target;
    const splittedName = name.split('_');
    const cartObj = [...formElementData];
    cartObj[parseInt(splittedName[1])][splittedName[0]] = value;
    setFormElementData(cartObj);
  };

  const validateEmail = email => {
    if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
      return true;
    }
    return false;
  };

  const placeOrder = () => {
    const d = formElementData.find(
      elem => elem.friendName === '' || elem.friendEmail === ''
    );

    const isEmailValid = formElementData.find(
      elem => elem.friendEmail !== '' && !validateEmail(elem.friendEmail)
    );

    if (!d && !isEmailValid) {
      storageUtility.setToPlaceOrder(formElementData);
      setPreviewOrder(true);
    } else if (isEmailValid) {
      alert('Please enter valid email address');
    } else {
      alert('Please fillup the information');
    }
  };

  const getTotalCartValue = () => {
    let total = 0;
    formElementData.forEach(eachElem => {
      total += parseInt(eachElem.yoyoPoint);
    });
    return total;
  };

  const classes = useStyles();

  return (
    <div className={classes.root}>
      {previewOrder ? <Redirect to="/preview-order" /> : ''}
      <h4 className={classes.pageHeding}>Enter Details to Continue</h4>
      <Paper>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell width="25%">Item Details</TableCell>
              <TableCell>Friend Details</TableCell>
              <TableCell width="25%"></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {props.addedItems && props.addedItems.length > 0 ? (
              props.addedItems.map((item, index) => (
                <TableRow key={`itemsRow${index}`}>
                  <TableCell component="th" scope="row">
                    Name: {item.name}
                    <br />
                    Amount: {item.cardValue}
                    <br />
                    Yoyo: {item.yoyoPoint}
                  </TableCell>
                  <TableCell>
                    <div>
                      <TextField
                        label="Enter Friend's Name"
                        variant="outlined"
                        margin="dense"
                        name={`friendName_${index}`}
                        onChange={changeData}
                        type="text"
                        fullWidth={true}
                      />
                    </div>
                    <div>
                      <TextField
                        label="Enter Friend's Email"
                        variant="outlined"
                        margin="dense"
                        name={`friendEmail_${index}`}
                        onChange={changeData}
                        type="email"
                        fullWidth={true}
                      />
                    </div>
                  </TableCell>
                  <TableCell width="25%"></TableCell>
                </TableRow>
              ))
            ) : (
              <></>
            )}
          </TableBody>
        </Table>
      </Paper>

      {props.addedItems && props.addedItems.length > 0 ? (
        <>
          {' '}
          {getTotalCartValue() > yoyoBalance ? (
            <>
              <div className={classes.warning}>
                Your cart total is <strong>{getTotalCartValue()}</strong> which
                is more than your yoyo balance. Kindly back to your cart and
                modify your order.
              </div>
              <br />
              <Button
                variant="contained"
                color="secondary"
                onClick={() => props.navigateTo('/cart')}
              >
                Shop More
              </Button>
            </>
          ) : (
            <Button
              variant="contained"
              color="secondary"
              className={classes.btnCls}
              onClick={() => placeOrder()}
            >
              Continue
            </Button>
          )}
          &nbsp;&nbsp;
          <Button
            variant="contained"
            color="secondary"
            onClick={() => props.navigateTo('/gift-card-list')}
          >
            Shop More
          </Button>
        </>
      ) : (
        ''
      )}
    </div>
  );
};

export default PlaceOrderView;
