import React from 'react';
import Checkbox from '@material-ui/core/Checkbox';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  color: '#0e6470',
});

const YoyoCheckbox = props => {
  const classes = useStyles();
  return (
    <>
      <Checkbox
        key={`checkbox${[props.id, props.index, props.subIndex].join('_')}`}
        id={`id_checkbox${[props.id, props.index, props.subIndex].join('_')}`}
        type="checkbox"
        name="name[]"
        value={props.value}
        checked={props.checked}
        onChange={props.isSelect}
        className={classes.color}
      ></Checkbox>
      {/*}<input
        key={`checkbox${[props.id, props.index, props.subIndex].join('_')}`}
        id={`id_checkbox${[props.id, props.index, props.subIndex].join('_')}`}
        type="checkbox"
        name="name[]"
        value={props.value}
        checked={props.checked}
        onChange={props.isSelect}
  />{*/}
      <label
        htmlFor={`id_checkbox${[props.id, props.index, props.subIndex].join(
          '_'
        )}`}
      >
        {props.label}
      </label>
    </>
  );
};

export default YoyoCheckbox;
