import * as types from "../actionTypes";

export const searchTxtAction = data => ({
  type: types.SEARCH_TXT,
  data
});

export const resetSearchStoreAction = data => ({
  type: types.RESET_SEARCH,
  data
});
