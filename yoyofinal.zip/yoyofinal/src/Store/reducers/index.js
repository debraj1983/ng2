import { combineReducers } from "redux";
import loginData from "./Login";
import categories from "./Categories";
import giftcards from "./Gifts";
import order from "./Order";
import search from "./Search";

export default combineReducers({
  loginData,
  categories,
  giftcards,
  order,
  search
});
