import React from 'react';
import { connect } from 'react-redux';
import storageUtility from './Utility/StorageUtility';
import { loginSuccessAction } from './Store/actions/LoginAction';
import {
  searchTxtAction,
  resetSearchStoreAction,
} from './Store/actions/SearchAction';

import './App.css';
import AppRouter from './AppRouter';

class App extends React.Component {
  componentDidMount() {
    if (storageUtility.checkLoggedIn()) {
      this.props.setLoginDataToStore(storageUtility.getLoggedInUserData());
    }
  }

  render() {
    return (
      <>
        <AppRouter loginData={this.props.loginData}></AppRouter>
      </>
    );
  }
}

const mapStateToProps = state => ({
  ...state,
});

const mapDispatchToProps = dispatch => ({
  setLoginDataToStore: data => dispatch(loginSuccessAction(data)),
  setSearchTxtToStore: data => dispatch(searchTxtAction(data)),
  setResetSearchStore: data => dispatch(resetSearchStoreAction(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(App);
