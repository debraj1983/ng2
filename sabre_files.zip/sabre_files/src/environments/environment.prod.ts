export const environment = {
  production: true,
  proto: true
};
