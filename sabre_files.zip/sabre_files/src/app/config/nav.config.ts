export const SIDENAV = {
    ADMIN: [{
        label: 'Dashboard',
        url: '/admin/dashboard',
        icon: 'fas fa-fw fa-tachometer-alt',
        active: true
    }, {
        label: 'Immegrator List',
        url: '/admin/immegrator',
        icon: 'fas fa-cog',
        active: true
    }, {
        label: 'Add Immegrator',
        url: '/admin/add-immegrator',
        icon: 'fas fa-file-signature',
        active: true
    }, {
        label: 'Logout',
        url: '/logout',
        icon: 'fas fa-sign-out-alt',
        active: true
    }],
    IMMEGRATION: [{
            label: 'Dashboard',
            url: '/immegration/dashboard',
            icon: 'fas fa-fw fa-tachometer-alt',
            active: true
        }, {
            label: 'Verify Passport',
            url: '/immegration/verify-passport',
            icon: 'fas fa-fw fa-tachometer-alt',
            active: true
        }, {
          label: 'Add Passport',
          url: '/immegration/add-passport',
          icon: 'fas fa-fw fa-tachometer-alt',
          active: true
        }, {
          label: 'Visa Requests',
          url: '/immegration/visa-requests',
          icon: 'fas fa-fw fa-tachometer-alt',
          active: true
        }, {
          label: 'Req Travel History',
          url: '/immegration/request-travel-history',
          icon: 'fas fa-fw fa-tachometer-alt',
          active: true
        }, {
            label: 'Logout',
            url: '/logout',
            icon: 'fas fa-sign-out-alt',
            active: true
        }],
    TRAVELLER: [{
        label: 'Dashboard',
        url: '/traveller/dashboard',
        icon: 'fas fa-fw fa-tachometer-alt',
        active: true
    }, {
        label: 'Documents',
        url: '/traveller/documents',
        icon: 'fas fa-user-alt',
        active: true
    }, {
        label: 'Add Documents',
        url: '/traveller/add-documents',
        icon: 'fas fa-file-signature',
        active: true
    }, {
        label: 'Travel History Request',
        url: '/traveller/travel-history-req',
        icon: 'fas fa-file-upload',
        active: true
    }, {
        label: 'Visa Request',
        url: '/traveller/visa-req',
        icon: 'fas fa-hand-holding-usd',
        active: true
    }, {
        label: 'Help',
        url: '/traveller/under-construction',
        icon: 'fas fa-question-circle',
        active: false
    }, {
      label: 'Customer Care',
      url: '/traveller/under-construction',
      icon: 'fas fas fa-phone-alt',
      active: false
  }, {
        label: 'Logout',
        url: '/logout',
        icon: 'fas fa-sign-out-alt',
        active: true
    }]
};
