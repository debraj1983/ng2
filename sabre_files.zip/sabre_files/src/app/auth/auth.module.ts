import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { AuthRoutingModule } from './auth-routing.module';
import { COMPONENTS } from './components/index';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';


@NgModule({
  declarations: [
    ...COMPONENTS
  ],
  imports: [
    CommonModule,
    AuthRoutingModule,
    ReactiveFormsModule,
    NgxMyDatePickerModule.forRoot(),
  ]
})
export class AuthModule { }
