import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';

export const COMPONENTS = [
  LoginComponent,
  SignupComponent
];
