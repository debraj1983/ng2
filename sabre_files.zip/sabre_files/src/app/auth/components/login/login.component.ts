import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpCommonService } from '../../../services/http-common.service';
import { LoaderService } from '../../../loader/loader.service';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';
import { AC } from '../../../app.constant';
import { AppStorageService } from '../../../services/app-storage.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private httpCommonService: HttpCommonService,
    private loaderService: LoaderService,
    private authService: AuthService,
    private appStorageService: AppStorageService,
    private route: Router
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });

  }

  public userLogin(): void {
    const loginData: any = {
      Username: this.loginForm.value.username,
      Password: this.loginForm.value.password
    };
    this.loaderService.show();
    this.httpCommonService.doLoginService(loginData).subscribe(res => {
      if (res && res.status) {
        if (res.status.statusCode && res.status.statusCode === '200') {
          this.appStorageService.setData('details', res.data.detail);
          this.loaderService.hide();
          this.navigateToPage(res.data.detail.userType);
          this.authService.checkLoggedIN();
        }
        if (res.status.code && res.status.code === '401') {
          this.loaderService.hide();
          window.alert(res.status.message);
        }
      }
    });
  }

  private navigateToPage(to: any): void {
    switch (to) {
      case AC.ROLE.ADMIN:
          this.appStorageService.setData(AC.STORAGE_KEYS.ADMIN_LOGGEDIN, 1);
          this.route.navigateByUrl('/admin/immegrator');
          break;
      case AC.ROLE.IMMEGRATION:
          this.appStorageService.setData(AC.STORAGE_KEYS.IMMEGRATION_LOGGEDIN, 1);
          this.route.navigateByUrl('/immegration/dashboard');
          break;
      case AC.ROLE.TRAVELLER:
          this.appStorageService.setData(AC.STORAGE_KEYS.TRAVELLER_LOGGEDIN, 1);
          this.route.navigateByUrl('/traveller/documents');
          break;
      case AC.ROLE.AGENT:
          this.appStorageService.setData(AC.STORAGE_KEYS.AGENT_LOGGEDIN, 1);
          this.route.navigateByUrl('/agent/dashboard');
          break;
    }
  }

}
