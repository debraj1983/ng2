import { Component, OnInit } from '@angular/core';
import { INgxMyDpOptions, IMyDateModel } from 'ngx-mydatepicker';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpCommonService } from '../../../services/http-common.service';
import { LoaderService } from '../../../loader/loader.service';
import { Router } from '@angular/router';
import { AC } from '../../../app.constant';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {

  public myOptions: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd.mm.yyyy',
  };

  public signUpFormGroup: FormGroup;

  constructor(private fb: FormBuilder,
              private httpCommonService: HttpCommonService,
              private loaderService: LoaderService,
              private route: Router) { }

  ngOnInit() {
    this.signUpFormGroup = this.fb.group({
      userName: ['', [Validators.required]],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      password: ['', Validators.required],
      gender: ['', Validators.required],
      dob: ['', Validators.required]
    });
  }

  public doSignUp(): void {
    const signUpData: any = {
      Username: this.signUpFormGroup.value.userName,
      Firstname: this.signUpFormGroup.value.firstName,
      Lastname: this.signUpFormGroup.value.lastName,
      Password: this.signUpFormGroup.value.password,
      Gender: this.signUpFormGroup.value.gender,
      Dob: this.signUpFormGroup.value.dob.formatted,
      userType: AC.ROLE.TRAVELLER
    };

    this.loaderService.show();
    this.httpCommonService.doSignupService(signUpData).subscribe(res => {
      if (res && res.status) {
        if (res.status.statusCode && res.status.statusCode === '200') {
          window.alert('You have successfully registered. Please login to continue..');
          this.route.navigateByUrl('/auth');
          this.loaderService.hide();
        }
        if (res.status.code && res.status.code === '401') {
          this.loaderService.hide();
          window.alert(res.status.message);
        }
      }
    });

  }

}
