import { Component, OnInit } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { AppStorageService } from '../services/app-storage.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {

  constructor(private authService: AuthService,
              private appStorageService: AppStorageService,
              private route: Router) { }

  ngOnInit() {
    this.appStorageService.clearData();
    this.authService.checkLoggedIN();
    this.route.navigate(['/auth']);
  }

}
