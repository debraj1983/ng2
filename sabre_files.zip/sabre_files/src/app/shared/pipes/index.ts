import { RemoveSpacePipe } from './remove-space.pipe';
import { SafePipe } from './safe.pipe';
import { CheckFromArrayPipe } from './check-from-array.pipe';
import { AddBrPipe } from './add-br.pipe';

export const PIPES = [
    RemoveSpacePipe,
    SafePipe,
    CheckFromArrayPipe,
    AddBrPipe
]
