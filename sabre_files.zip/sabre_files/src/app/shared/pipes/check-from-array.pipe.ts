import { Pipe, PipeTransform } from '@angular/core';
import { CommonUtilityService } from '../../services/common-utility.service';

@Pipe({
  name: 'checkFromArray'
})
export class CheckFromArrayPipe implements PipeTransform {
  constructor(private commonUtilityService: CommonUtilityService) {}

  transform(array: any, elem: any): any {
    return (this.commonUtilityService.inArray(array, elem)) ? 'checked' : '';
  }

}
