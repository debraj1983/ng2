import { AddBrPipe } from './add-br.pipe';

describe('AddBrPipe', () => {
  it('create an instance', () => {
    const pipe = new AddBrPipe();
    expect(pipe).toBeTruthy();
  });
});
