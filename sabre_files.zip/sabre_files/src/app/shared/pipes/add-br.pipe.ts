import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'addBr'
})
export class AddBrPipe implements PipeTransform {

  transform(value: any): any {
    return value.replace(/ (?=[^ ]*$)/i, '<br />');
  }

}
