import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { UnderConstructionComponent } from './under-construction/under-construction.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { ModalPopupComponent } from './modal-popup/modal-popup.component';

export const COMPONENTS = [
    HeaderComponent,
    FooterComponent,
    SidenavComponent,
    UnderConstructionComponent,
    FileUploadComponent,
    ModalPopupComponent
];
