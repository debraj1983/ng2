import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-modal-popup',
  templateUrl: './modal-popup.component.html',
  styleUrls: ['./modal-popup.component.scss']
})
export class ModalPopupComponent implements OnInit {

  // pdf_binary, pdf_file, message, content
  @Input()
  public contentType: string;

  // large. medium, small
  @Input()
  public content: string;

  @Input()
  public modalSize: string;

  @Output()
  public closeModal: EventEmitter<any> = new EventEmitter();

  @Output()
  public rejectConsentModal: EventEmitter<any> = new EventEmitter();

  @Output()
  public acceptConcent: EventEmitter<any> = new EventEmitter();

  public html: string;

  constructor() { }

  ngOnInit() {
    if (!this.modalSize) {
      this.modalSize = 'large';
    }

    if (this.contentType === 'pdf_binary') {
      this.html = `<embed width="100%" height="100%" src="${this.content}" type="application/pdf" />`;
    } else if (this.contentType === 'pdf_file') {
      this.html = `<embed width="100%" height="100%" src="${this.content}" type="application/pdf" />`;
    }
  }

  public closeDialog(): void {
    this.closeModal.emit(false);
  }

  public acceptContent(): void {
    this.acceptConcent.emit(true);
  }

  public rejectConsent(): void {
    this.rejectConsentModal.emit(true);
  }
}


