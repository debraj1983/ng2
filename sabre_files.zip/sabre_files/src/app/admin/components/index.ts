import { DashboardComponent } from './dashboard/dashboard.component';
import { AdminComponent } from '../admin.component';
import { ImmegratorListComponent } from './immegrator-list/immegrator-list.component';
import { AddImmegratorComponent } from './add-immegrator/add-immegrator.component';


export const COMPONENTS = [
  DashboardComponent,
  AdminComponent,
  ImmegratorListComponent,
  AddImmegratorComponent
];
