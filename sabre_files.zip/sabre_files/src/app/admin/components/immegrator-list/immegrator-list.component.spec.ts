import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImmegratorListComponent } from './immegrator-list.component';

describe('ImmegratorListComponent', () => {
  let component: ImmegratorListComponent;
  let fixture: ComponentFixture<ImmegratorListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImmegratorListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmegratorListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
