import { Component, OnInit } from '@angular/core';
import { HttpCommonService } from '../../../services/http-common.service';
import { AC } from '../../../app.constant';


@Component({
  selector: 'app-immegrator-list',
  templateUrl: './immegrator-list.component.html',
  styleUrls: ['./immegrator-list.component.scss']
})
export class ImmegratorListComponent implements OnInit {
  public users: any;
  constructor(private httpCommonService: HttpCommonService) { }

  ngOnInit() {
    const payload = {
      userType: AC.ROLE.IMMEGRATION
    };
    this.httpCommonService.getUsers(payload).subscribe(res => {
      this.users = res.users;
    });

  }

}
