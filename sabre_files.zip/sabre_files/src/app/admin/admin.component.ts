import { Component, OnInit } from '@angular/core';
import { AC } from '../app.constant';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {

  public option: any;
  public menu: any;

  constructor() { }

  ngOnInit() {
    this.option = {
      cssClass: 'sidebar-all'
    };
    this.menu = AC.SIDENAV.ADMIN;
  }

}
