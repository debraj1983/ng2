import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AdminComponent } from './admin.component';
import { ImmegratorListComponent } from './components/immegrator-list/immegrator-list.component';
import { AddImmegratorComponent } from './components/add-immegrator/add-immegrator.component';


const routes: Routes = [{
  path: '',
  component: AdminComponent,
  children: [
    {path: 'dashboard', component: DashboardComponent},
    {path: 'immegrator', component: ImmegratorListComponent},
    {path: 'add-immegrator', component: AddImmegratorComponent}
  ]}, {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
