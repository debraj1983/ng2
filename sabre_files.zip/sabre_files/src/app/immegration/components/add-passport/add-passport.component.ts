import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-passport',
  templateUrl: './add-passport.component.html',
  styleUrls: ['./add-passport.component.scss']
})
export class AddPassportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
