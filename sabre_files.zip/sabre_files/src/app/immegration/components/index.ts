import { DashboardComponent } from './dashboard/dashboard.component';
import { VerifyPassportComponent } from './verify-passport/verify-passport.component';
import { AddPassportComponent } from './add-passport/add-passport.component';
import { VisaRequestsComponent } from './visa-requests/visa-requests.component';
import { RequestTravelHistoryComponent } from './request-travel-history/request-travel-history.component';
import { ImmegrationComponent } from '../immegration.component';


export const COMPONENTS = [
  DashboardComponent,
  VerifyPassportComponent,
  AddPassportComponent,
  VisaRequestsComponent,
  RequestTravelHistoryComponent,
  ImmegrationComponent
];
