import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-travel-history',
  templateUrl: './request-travel-history.component.html',
  styleUrls: ['./request-travel-history.component.scss']
})
export class RequestTravelHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
