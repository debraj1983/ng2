import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-verify-passport',
  templateUrl: './verify-passport.component.html',
  styleUrls: ['./verify-passport.component.scss']
})
export class VerifyPassportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
