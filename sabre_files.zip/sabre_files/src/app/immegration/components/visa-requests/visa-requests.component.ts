import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visa-requests',
  templateUrl: './visa-requests.component.html',
  styleUrls: ['./visa-requests.component.scss']
})
export class VisaRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
