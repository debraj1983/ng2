import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImmegrationComponent } from './immegration.component';

describe('ImmegrationComponent', () => {
  let component: ImmegrationComponent;
  let fixture: ComponentFixture<ImmegrationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImmegrationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImmegrationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
