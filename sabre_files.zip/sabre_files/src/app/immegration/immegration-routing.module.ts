import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './components/dashboard/dashboard.component';
import { VerifyPassportComponent } from './components/verify-passport/verify-passport.component';
import { AddPassportComponent } from './components/add-passport/add-passport.component';
import { VisaRequestsComponent } from './components/visa-requests/visa-requests.component';
import { RequestTravelHistoryComponent } from './components/request-travel-history/request-travel-history.component';
import { ImmegrationComponent } from './immegration.component';

const routes: Routes = [{
  path: '',
  component: ImmegrationComponent,
  children: [
    {path: 'dashboard', component: DashboardComponent},
    {path: 'verify-passport', component: VerifyPassportComponent},
    {path: 'add-passport', component: AddPassportComponent},
    {path: 'visa-requests', component: VisaRequestsComponent},
    {path: 'request-travel-history', component: RequestTravelHistoryComponent}
  ]}, {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  }];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ImmegrationRoutingModule { }
