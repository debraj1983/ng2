import { Component, OnInit } from '@angular/core';
import { AC } from '../app.constant';
@Component({
  selector: 'app-immegration',
  templateUrl: './immegration.component.html',
  styleUrls: ['./immegration.component.scss']
})
export class ImmegrationComponent implements OnInit {

  public option: any;
  public menu: any;

  constructor() { }

  ngOnInit() {
    this.option = {
      cssClass: 'sidebar-all'
    };
    this.menu = AC.SIDENAV.IMMEGRATION;
  }
}
