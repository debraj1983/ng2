import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { COMPONENTS } from './components/index';
import { ImmegrationRoutingModule } from './immegration-routing.module';
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    SharedModule,
    ImmegrationRoutingModule
  ]
})
export class ImmegrationModule { }
