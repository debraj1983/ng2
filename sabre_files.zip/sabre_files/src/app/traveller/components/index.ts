import { DashboardComponent } from './dashboard/dashboard.component';
import { DocumentListComponent } from './document-list/document-list.component';
import { AddDocumentComponent } from './add-document/add-document.component';
import { VisaReqComponent } from './visa-req/visa-req.component';
import { TravelHistoryReqComponent } from './travel-history-req/travel-history-req.component';
import { TravellerComponent } from '../traveller.component';


export const COMPONENTS = [
  DashboardComponent,
  DocumentListComponent,
  AddDocumentComponent,
  VisaReqComponent,
  TravelHistoryReqComponent,
  TravellerComponent
];
