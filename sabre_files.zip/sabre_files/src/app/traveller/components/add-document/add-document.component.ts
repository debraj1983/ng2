import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpCommonService } from '../../../services/http-common.service';
import { LoaderService } from '../../../loader/loader.service';
import { Router } from '@angular/router';
import { AppStorageService } from '../../../services/app-storage.service';

import { AC } from '../../../app.constant';


@Component({
  selector: 'app-add-document',
  templateUrl: './add-document.component.html',
  styleUrls: ['./add-document.component.scss']
})
export class AddDocumentComponent implements OnInit {

  public uplaodDocumentFormGroup: FormGroup;
  public fileData: any;
  public docCategory: any = AC.DOCUMENT_TYPE;

  constructor(private fb: FormBuilder,
              private httpCommonService: HttpCommonService,
              private loaderService: LoaderService,
              private appStorageService: AppStorageService,
              private route: Router) { }

  ngOnInit() {
    this.uplaodDocumentFormGroup = this.fb.group({
      category: ['', [Validators.required]]
    });
  }

  uploadedFileContent(e): void {
    this.fileData = e;
  }

  uploadDoc(): void {
    if (this.uplaodDocumentFormGroup.value.category === '') {
      window.alert('Select document type');
    } else {
      const user = this.appStorageService.getData('details');
      const payload = {
        docCategory: this.uplaodDocumentFormGroup.value.category,
        fileData: this.fileData.fileContent,
        Username: user.Username
      };

      this.httpCommonService.saveDocuments(payload).subscribe(res => {
        if (res && res.status === 'success') {
          window.alert('Document successfully uploaded');
          this.route.navigateByUrl('/traveller/documents');
        }
      });
    }


  }

}
