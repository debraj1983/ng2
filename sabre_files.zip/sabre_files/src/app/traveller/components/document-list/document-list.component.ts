import { Component, OnInit } from '@angular/core';
import { HttpCommonService } from '../../../services/http-common.service';
import { AppStorageService } from '../../../services/app-storage.service';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.scss']
})
export class DocumentListComponent implements OnInit {
  public isPreview: boolean;
  public content: any;
  public documents: any;
  constructor(private httpCommonService: HttpCommonService,
              private appStorageService: AppStorageService) { }

  ngOnInit() {
    const user = this.appStorageService.getData('details');
    const payload = {
      Username: user.Username
    };
    this.httpCommonService.getDocuments(payload).subscribe(res => {
      this.documents = (res.documents) ? res.documents : [];
    });
  }

  public getContent(pos: any): void {
    this.isPreview = true;
    this.content = this.documents[pos].fileData;
  }

  public closeModal(isClose: boolean): void {
    this.isPreview = isClose;
  }

}
