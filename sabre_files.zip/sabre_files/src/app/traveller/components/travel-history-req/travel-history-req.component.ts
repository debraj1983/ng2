import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-travel-history-req',
  templateUrl: './travel-history-req.component.html',
  styleUrls: ['./travel-history-req.component.scss']
})
export class TravelHistoryReqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
