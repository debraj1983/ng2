import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelHistoryReqComponent } from './travel-history-req.component';

describe('TravelHistoryReqComponent', () => {
  let component: TravelHistoryReqComponent;
  let fixture: ComponentFixture<TravelHistoryReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TravelHistoryReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TravelHistoryReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
