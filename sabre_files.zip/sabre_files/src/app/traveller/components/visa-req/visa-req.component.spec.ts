import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VisaReqComponent } from './visa-req.component';

describe('VisaReqComponent', () => {
  let component: VisaReqComponent;
  let fixture: ComponentFixture<VisaReqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisaReqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VisaReqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
