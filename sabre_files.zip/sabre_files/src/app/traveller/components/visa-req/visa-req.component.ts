import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visa-req',
  templateUrl: './visa-req.component.html',
  styleUrls: ['./visa-req.component.scss']
})
export class VisaReqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
