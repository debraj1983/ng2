import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TravellerComponent } from './traveller.component';
import { DocumentListComponent } from './components/document-list/document-list.component';
import { AddDocumentComponent } from './components/add-document/add-document.component';
import { TravelHistoryReqComponent } from './components/travel-history-req/travel-history-req.component';
import { VisaReqComponent } from './components/visa-req/visa-req.component';

const routes: Routes = [{
  path: '',
  component: TravellerComponent,
  children: [
    {path: 'dashboard', component: DashboardComponent},
    {path: 'documents', component: DocumentListComponent},
    {path: 'add-documents', component: AddDocumentComponent},
    {path: 'travel-history-req', component: TravelHistoryReqComponent},
    {path: 'visa-req', component: VisaReqComponent}
  ]}, {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TravellerRoutingModule { }
