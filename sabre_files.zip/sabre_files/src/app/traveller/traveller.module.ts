import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { COMPONENTS } from './components/index';
import { TravellerRoutingModule } from './traveller-routing.module';
import { SharedModule } from '../shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    TravellerRoutingModule,
    SharedModule,
    ReactiveFormsModule
  ]
})
export class TravellerModule { }
