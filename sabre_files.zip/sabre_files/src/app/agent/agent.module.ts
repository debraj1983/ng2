import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { COMPONENTS } from './components/index';
import { AgentRoutingModule } from './agent-routing.module';


@NgModule({
  declarations: [...COMPONENTS],
  imports: [
    CommonModule,
    AgentRoutingModule
  ]
})
export class AgentModule { }
