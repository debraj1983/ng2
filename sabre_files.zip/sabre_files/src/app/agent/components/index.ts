import { DashboardComponent } from './dashboard/dashboard.component';


export const COMPONENTS = [
  DashboardComponent
];
