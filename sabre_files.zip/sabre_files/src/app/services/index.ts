import { AppStorageService } from './app-storage.service';
import { GuardService } from './guard.service';
import { AuthService } from './auth.service';
import { CommonUtilityService } from './common-utility.service';
import { LoaderService } from '../loader/loader.service';
import { FileService } from './file.service';
import { HttpService } from './http.service';
import { HttpCommonService } from './http-common.service';
import { PROTO } from './prototype/index';

export const SERVICES = [
    AppStorageService,
    GuardService,
    AuthService,
    CommonUtilityService,
    LoaderService,
    FileService,
    HttpService,
    HttpCommonService,
    ...PROTO
];
