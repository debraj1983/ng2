import { Injectable } from '@angular/core';
import { LoaderService } from '../loader/loader.service';
@Injectable({
  providedIn: 'root'
})
export class FileService {

  public content: any;

  public stepWiseRecords: any = [];

  constructor(private loaderService: LoaderService) { }

  // Below method will call once user select a file
  onFileChanged(fileList: any) {
    const self = this;
    const reader = new FileReader();
    if (fileList && fileList.length > 0) {
      const file = fileList[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        self.content = reader.result;
        self.loaderService.hide();
      };
    }
  }

  getFileContent(): any {
    return this.content;
  }

  removeDataFromContent(): any {
    this.content = undefined;
  }

  public pushStepsWiseRecords(record: any): void {
    // Check if the record exists
    let isExists = false;
    let pos = 0;
    if (this.stepWiseRecords && this.stepWiseRecords.length > 0) {
      for (const s of this.stepWiseRecords) {
        if (s.fileFor === record.fileFor) {
          isExists = true;
          break;
        }
        pos++;
      }
    }

    if (isExists) {
      this.stepWiseRecords[pos] = record;
    } else {
      this.stepWiseRecords.push(record);
    }
  }

  public getAddedRecords(fileFor: string): any {
    if (this.stepWiseRecords && this.stepWiseRecords.length > 0) {
      for (const s of this.stepWiseRecords) {
        if (s.fileFor === fileFor) {
          return s;
        }
      }
    }
    return undefined;
  }
}
