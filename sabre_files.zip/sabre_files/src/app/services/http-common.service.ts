import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { PrototypeService } from './prototype/prototype.service';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class HttpCommonService {

  constructor(private httpService: HttpService,
              private prototypeService: PrototypeService) { }

  doLoginService(payload): Observable<any> {
    if (environment.proto) {
      return this.prototypeService.doLogin(payload);
    } else {
      return this.httpService.makeCall(environment.serviceUrl.login, payload);
    }
  }

  doSignupService(payload): Observable<any> {
    if (environment.proto) {
      return this.prototypeService.doSignUp(payload);
    } else {
      return this.httpService.makeCall(environment.serviceUrl.signUp, payload);
    }
  }

  public getUsers(payload: any): Observable<any> {
    if (environment.proto) {
      return this.prototypeService.getUsers(payload);
    } else {
      return this.httpService.makeCall(environment.serviceUrl.getUser, payload);
    }
  }

  public getDocuments(payload: any): Observable<any> {
    if (environment.proto) {
      return this.prototypeService.getDocuments(payload);
    } else {
      return this.httpService.makeCall(environment.serviceUrl.getDocuments, payload);
    }
  }

  public saveDocuments(payload: any): Observable<any> {
    if (environment.proto) {
      return this.prototypeService.saveDocuments(payload);
    } else {
      return this.httpService.makeCall(environment.serviceUrl.saveDocuments, payload);
    }
  }
}
