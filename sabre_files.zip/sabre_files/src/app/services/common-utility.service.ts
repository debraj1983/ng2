import { Injectable } from '@angular/core';
import { AppStorageService } from './app-storage.service';
import { AC } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class CommonUtilityService {

  constructor(private appStorageService: AppStorageService) { }

  public inArray(arr: any, elem: any): boolean {
    let isExists = false;
    if (arr && arr.length > 0) {
      for (const a of arr) {
        if (a === elem) {
          isExists = true;
          break;
        }
      }
    }
    return isExists;
  }

  public removeEmementFromArray(arr: any, elem: any): any {
    if (this.inArray(arr, elem)) {
      const newArray = [];
      for (const a of arr) {
        if (a !== elem) {
          newArray.push(a);
        }
      }
      return newArray;
    }
    return arr;
  }

  public removeSpaceFromString(str: string): string {
    return str.replace(/\s/g, '');
  }
}
