import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
  })
};

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }

  public makeCall(url: string, payload?: any): Observable<any> {
    if (payload) {
      return this.http.post(url, payload, httpOptions);
    } else {
      return this.http.get(url);
    }
  }

}
