import { TestBed } from '@angular/core/testing';

import { PrototypeAllService } from './prototype-all.service';

describe('PrototypeAllService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrototypeAllService = TestBed.get(PrototypeAllService);
    expect(service).toBeTruthy();
  });
});
