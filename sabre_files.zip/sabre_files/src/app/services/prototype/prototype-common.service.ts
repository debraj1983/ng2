import { Injectable } from '@angular/core';
import { PROTO_CONST } from './proto-constant';
import { AppStorageService } from '../app-storage.service';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PrototypeCommonService {

  constructor(private appStorageService: AppStorageService) { }

  public checkAndSetDataInLocalStorage(): void {
    let data = this.getProtoDataFromLocal();
    if (!data) {
      data = {
                'userdata': [],
                'travellersdocuments': {}
              };
      this.setProtoDataToLocal(data);
    }
  }

   // Check User Exists
   public checkUserExists(payload: any, data: any): boolean {
    let isExists = false;
    if (data && data.length > 0) {
      for (const d of data) {
        if (d.Username === payload.Username) {
          isExists = true;
          break;
        }
      }
    }
    return isExists;
  }


  public getProtoData(type: string): any {
    const data = this.getProtoDataFromLocal();
    return data[type];
  }

  public setProtoData(toSave: any, type: string): any {
    const data = this.getProtoDataFromLocal();
    data[type] = toSave;
    this.setProtoDataToLocal(data);
  }

  private getProtoDataFromLocal(): any {
    let protoData = this.appStorageService.getData('protoData', 'local');
    if (!protoData) {
        protoData = {
          'userdata': [],
          'travellersdocuments': {}
        };
        this.setProtoDataToLocal(protoData);
    }
    return protoData;
  }
  private setProtoDataToLocal(data: any): void {
    this.appStorageService.setData('protoData', data, 'local');
  }
}
