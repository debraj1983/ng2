import { Injectable } from '@angular/core';
import { PrototypeCommonService } from './prototype-common.service';
import { Observable, of } from 'rxjs';
import { PROTO_CONST } from './proto-constant';
import { AC } from '../../app.constant';
@Injectable({
  providedIn: 'root'
})
export class PrototypeAuthService {

  constructor(private prototypeCommonService: PrototypeCommonService) { }

  public doSignUp(payload: any): Observable<any> {
    const data = this.prototypeCommonService.getProtoData(PROTO_CONST.USERDATA);
    if (data && data.length === 0) {
      payload['userType'] = AC.ROLE.ADMIN;
    }
    const isExists = this.prototypeCommonService.checkUserExists(payload, data);
    if (!isExists) {
      payload['id'] = Date.now();
      data.push(payload);
      this.prototypeCommonService.setProtoData(data, PROTO_CONST.USERDATA);
      return of({
            'data': {},
            'status': {
                'message': 'User registered successfully!!',
                'statusCode': '200'
            },
            'err': {}
        });
    }
    return of({
      'data': {},
      'status': {
          'message': 'User exists in our system',
          'code': '401'
      },
      'err': {}
    });
  }

  public doLogin(payload: any): Observable<any> {
    const data = this.prototypeCommonService.getProtoData(PROTO_CONST.USERDATA);
    const isExists = this.prototypeCommonService.checkUserExists(payload, data);
    if (isExists) {
      const user = data.find((d: any) => (d.Username === payload.Username));
      return of({
        'data': {
          'id': Date.now(),
          'detail': user
        },
        'status': {
            'message': 'User successfully logged in',
            'statusCode': '200'
        },
        'err': {}
      });
    } else {
      return of({
        'data': {},
        'status': {
            'message': 'User doesn\'t exists in our system',
            'code': '401'
        },
        'err': {}
      });
    }
  }
}
