import { Injectable } from '@angular/core';
import { PrototypeCommonService } from './prototype-common.service';
import { PrototypeAuthService } from './prototype-auth.service';
import { PrototypeAllService } from './prototype-all.service';


import { Observable, of } from 'rxjs';
import { AC } from '../../app.constant';

@Injectable({
  providedIn: 'root'
})
export class PrototypeService {

  constructor(private prototypeAuthService: PrototypeAuthService,
              private prototypeCommonService: PrototypeCommonService,
              private prototypeAllService: PrototypeAllService) { }

  public checkAndSetDataInLocalStorage(): void {
    this.prototypeCommonService.checkAndSetDataInLocalStorage();
  }

  // Method for sign up
  public doSignUp(payload: any): Observable<any> {
   return this.prototypeAuthService.doSignUp(payload);
  }

  // Method for merchant login
  public doLogin(payload: any): Observable<any> {
    return this.prototypeAuthService.doLogin(payload);
  }

  public getUsers(payload: any): Observable<any> {
    return this.prototypeAllService.getUsers(payload);
  }

  public getDocuments(payload: any): Observable<any> {
    return this.prototypeAllService.getDocuments(payload);
  }

  public saveDocuments(payload: any): Observable<any> {
    return this.prototypeAllService.saveDocuments(payload);
  }


}
