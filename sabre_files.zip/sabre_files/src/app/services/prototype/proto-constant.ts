export const PROTO_CONST = {
  USERDATA: 'userdata',
  TRAVELLERSDOCUMENT: 'travellersdocuments'
};
