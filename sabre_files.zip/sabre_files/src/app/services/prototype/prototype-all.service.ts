import { Injectable } from '@angular/core';
import { PrototypeCommonService } from './prototype-common.service';
import { Observable, of } from 'rxjs';
import { PROTO_CONST } from './proto-constant';
import { AC } from '../../app.constant';

@Injectable({
  providedIn: 'root'
})
export class PrototypeAllService {

  constructor(private prototypeCommonService: PrototypeCommonService) { }

  public getUsers(payload): Observable<any> {
    const data = this.prototypeCommonService.getProtoData(PROTO_CONST.USERDATA);
    const filterd = data.filter( (d: any) => d.userType === payload.userType);
    return of({
      users: filterd
    });
  }

  public getDocuments(payload): Observable<any> {
    const data = this.prototypeCommonService.getProtoData(PROTO_CONST.TRAVELLERSDOCUMENT);
    const filterd = data[payload.Username]
    return of({
      documents: filterd
    });
  }

  public saveDocuments(payload): Observable<any> {
    const data = this.prototypeCommonService.getProtoData(PROTO_CONST.TRAVELLERSDOCUMENT);
    if (data && data[payload.Username] && data[payload.Username].length > 0) {

      const pos = data[payload.Username].findIndex( f => f.docCategory === payload.docCategory);
      if (pos > -1) {
        data[payload.Username][pos].fileData = payload.fileData;
      } else {
        data[payload.Username].push({
          fileData: payload.fileData,
          docCategory: payload.docCategory
        });
      }
    } else {
      data[payload.Username] = [];
      data[payload.Username].push({
        fileData: payload.fileData,
        docCategory: payload.docCategory
      });
    }
    this.prototypeCommonService.setProtoData(data, PROTO_CONST.TRAVELLERSDOCUMENT);

    return of({
      status: 'success'
    });
  }

}
