import { PrototypeService } from './prototype.service';
import { PrototypeCommonService } from './prototype-common.service';
import { PrototypeAuthService } from './prototype-auth.service';
import { PrototypeAllService } from './prototype-all.service';

export const PROTO = [
  PrototypeService,
  PrototypeCommonService,
  PrototypeAuthService,
  PrototypeAllService
];
