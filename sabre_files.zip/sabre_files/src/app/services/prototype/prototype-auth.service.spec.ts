import { TestBed } from '@angular/core/testing';

import { PrototypeAuthService } from './prototype-auth.service';

describe('PrototypeAuthService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrototypeAuthService = TestBed.get(PrototypeAuthService);
    expect(service).toBeTruthy();
  });
});
