import { TestBed } from '@angular/core/testing';

import { PrototypeCommonService } from './prototype-common.service';

describe('PrototypeCommonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PrototypeCommonService = TestBed.get(PrototypeCommonService);
    expect(service).toBeTruthy();
  });
});
