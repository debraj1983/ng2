import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardService } from './services/guard.service';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [{
  path: '',
  loadChildren: './auth/auth.module#AuthModule'
}, {
  path: 'auth',
  loadChildren: './auth/auth.module#AuthModule'
}, {
  path: 'admin',
  loadChildren: './admin/admin.module#AdminModule',
  canLoad: [GuardService]
 }, {
  path: 'immegration',
  loadChildren: './immegration/immegration.module#ImmegrationModule',
  canLoad: [GuardService]
 }, {
  path: 'traveller',
  loadChildren: './traveller/traveller.module#TravellerModule',
  canLoad: [GuardService]
 }, {
  path: 'agent',
  loadChildren: './agent/agent.module#AgentModule',
  canLoad: [GuardService]
 }, {
   path: 'logout',
   component: LogoutComponent
 }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
