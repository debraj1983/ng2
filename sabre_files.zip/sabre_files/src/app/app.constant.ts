import { SIDENAV } from './config/nav.config';

export const AC = {
    ROLE: {
        ADMIN: 'admin',
        IMMEGRATION: 'IMMEGRATION',
        TRAVELLER: 'TRAVELLER',
        AGENT: 'AGENT'
    },
    STORAGE_KEYS: {
      ADMIN_LOGGEDIN: 'ADMIN_LOGGEDIN',
      IMMEGRATION_LOGGEDIN: 'IMMEGRATION_LOGGEDIN',
      TRAVELLER_LOGGEDIN: 'TRAVELLER_LOGGEDIN',
      AGENT_LOGGEDIN: 'AGENT_LOGGEDIN'
    },
    DOCUMENT_TYPE: [
      {
        key: 'PASSPORT',
        value: 'Passport'
      }, {
        key: 'AADHAR',
        value: 'Aadhar Card'
      }, {
        key: 'VOTER',
        value: 'Voter Card'
      }, {
        key: 'PAN',
        value: 'PAN Card'
      }],
    SIDENAV: SIDENAV
};
