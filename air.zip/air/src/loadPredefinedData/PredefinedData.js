const PredefinedData = {
  users: [
    { userId: "staff1", password: "asd", role: "checkin" },
    { userId: "staff2", password: "asd", role: "inflight" },
    { userId: "admin", password: "asd", role: "admin" }
  ],
  seats: {
    rows: 30,
    seat_sequence: ["A", "B", "C", "D", "E", "F"]
  },
  colorCode: {
    checkedIdSeat: "#083e70",
    availableSeat: "#8fb6db",
    checkedInWithWheelChair: "#991c39",
    checkedInWithMeal: "#077034",
    checkedInWithMealAndWheelChair: "#076d70"
  },
  totalPassenger: 180,
  passengerNamePrefix: "Passenger", // Passenger 1A, Passenger 1B...
  flightDetails: [
    {
      flightNo: "6E-713",
      airlinesName: "Indigo",
      fromTo: "BLR-CCU",
      departureTime: "16:00",
      arrivalTime: "18:45",
      // passengers: {},
      seats: {}
    },
    {
      flightNo: "6E-2135",
      airlinesName: "Indigo",
      fromTo: "BLR-DEL",
      departureTime: "13:40",
      arrivalTime: "16:25",
      // passengers: {},
      seats: {}
    }
  ]
};

/*
{
    '1': {
        'A': {
            checkedId: true/false,
            hasWheelChair: true / false
            hasMealOption: true / false
            hasInfant: true / false
            mealType: 'veg/nonveg',
            passengerName: 'Passenger 1'
        },
        'B': {

        }
    }
}
*/

export default PredefinedData;
