import PredefinedData from "./PredefinedData";
import dataStorage from "../Utility/AppStorage";
import APP_CONSTANT from "../Constants";
const LoadData = () => {
  LoadUserData();
  LoadFlightDetails();
};

function LoadUserData() {
  dataStorage.setData(APP_CONSTANT.STORAGE_KEYS.USERS, PredefinedData.users);
}

function LoadFlightDetails() {
  const fD = PredefinedData.flightDetails;
  const modifiedFd = fD.map(element => {
    const seat = GetSeatsObject();
    element["seats"] = seat;
    return element;
  });
  dataStorage.setData(APP_CONSTANT.STORAGE_KEYS.FLIGHT_DETAILS, modifiedFd);
}

function GetSeatsObject() {
  const seatData = PredefinedData.seats;
  const seatObj = {};
  let c = 1;
  for (let i = 1; i <= seatData.rows; i++) {
    seatObj[i] = {};
    seatData.seat_sequence.forEach(element => {
      const checkedIn = GetRandomValue([true, false]);
      const hasMealOption = GetRandomValue([true, false]);
      seatObj[i][element] = {
        checkedIn: checkedIn,
        hasWheelChair: checkedIn ? GetRandomValue([true, false]) : false,
        hasMealOption: checkedIn ? hasMealOption : false,
        hasInfant: checkedIn ? GetRandomValue([true, false]) : false,
        mealType:
          checkedIn && hasMealOption ? GetRandomValue(["veg", "nonveg"]) : "",
        passengerName: checkedIn ? `Passenger ${c}` : ""
      };
      c++;
    });
  }
  return seatObj;
}

function GetRandomValue(Items) {
  return Items[Math.floor(Math.random() * Items.length)];
}

export default LoadData;
