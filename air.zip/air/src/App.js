import React from "react";
import { Route, Link, BrowserRouter as Router } from "react-router-dom";

import logo from "./logo.svg";
import "./App.scss";

import Admin from "./Admin/Admin";
import Checkin from "./Checkin/Checkin";
import Inflight from "./Inflight/Inflight";

function App() {
  return (
    <Router>
      <div>
        <nav>
          <ul className="nav">
            <li>
              <Link to="/admin">Admin</Link>
            </li>
            <li>
              <Link to="/checkin">Check In</Link>
            </li>
            <li>
              <Link to="/inflight">In Flight</Link>
            </li>
          </ul>
        </nav>

        <div className="clear"></div>
        <Route path="/admin" component={Admin} />
        <Route path="/checkin" component={Checkin} />
        <Route path="/inflight" component={Inflight} />
      </div>
    </Router>
  );
}

export default App;
