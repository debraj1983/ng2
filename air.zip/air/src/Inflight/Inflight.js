import React from "react";
import "./Inflight.scss";

function Inflight() {
  return <div>Inflight Works</div>;
}

export default Inflight;
