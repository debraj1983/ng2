const STORAGE_KEY = "AIRLINES";
const dataStorage = {
  setData: (key, data) => {
    let addedData = window.localStorage.getItem(STORAGE_KEY);
    if (!addedData) {
      addedData = {};
      addedData[key] = data;
    } else {
      addedData = JSON.parse(addedData);
      addedData[key] = data;
    }

    console.log(addedData);

    const toSave = JSON.stringify(addedData);
    window.localStorage.setItem(STORAGE_KEY, toSave);
  },
  getData: key => {
    let data = window.localStorage.getItem(STORAGE_KEY);
    data = JSON.parse(data);
    return data && data[key] ? data[key] : null;
  },
  setDataInObject: (key, subkey, data) => {
    const keyData = dataStorage.getData(key);
    keyData[subkey] = data;
    dataStorage.setData(key, keyData);
  }
};

export default dataStorage;
