import * as types from "../actionTypes";
import { postApiCall, getApiCall } from "../../ApiCall/apiCalls";

export const updateOrderSuccessAction = data => ({
  type: types.ORDER_PLACED,
  data
});

export const orderHistoryAction = data => ({
  type: types.USER_ORDER_HISTORY,
  data
});

export const orderTransactionAction = data => ({
  type: types.USER_TRANSACTION_HISTORY,
  data
});

export const updateOrderAction = payload => {
  return function(dispatch, getState) {
    return postApiCall("UsersOrder", payload).then(data => {
      dispatch(updateOrderSuccessAction(data));
    });
  };
};

export const updateYoyoTransactionAction = id => {
  return function(dispatch, getState) {
    return getApiCall("YoyoPaymentHistory/?userId=" + id).then(data => {
      dispatch(orderTransactionAction(data));
    });
  };
};

export const getOrderHistoryAction = id => {
  return function(dispatch, getState) {
    return getApiCall("UsersOrder/?userId=" + id).then(data => {
      dispatch(orderHistoryAction(data));
    });
  };
};
