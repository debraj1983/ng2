import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.ORDER_PLACED:
      return {
        ...state,
        orderPlaced: {
          numberOfOrder:
            state && state.orderPlaced && state.orderPlaced.numberOfOrder
              ? state.orderPlaced.numberOfOrder + 1
              : 1,
          usedYoyo:
            state && state.orderPlaced && state.orderPlaced.usedYoyo
              ? state.orderPlaced.usedYoyo + action.data.yoyoPoint
              : action.data.yoyoPoint
        }
      };
    case types.USER_ORDER_HISTORY:
      return {
        ...state,
        orderHistory: action.data
      };
    case types.USER_TRANSACTION_HISTORY:
      return {
        ...state,
        transactionHistory: action.data
      };
    default:
      return state;
  }
};
