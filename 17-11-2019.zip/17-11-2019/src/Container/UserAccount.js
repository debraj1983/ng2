import React from "react";
import { connect } from "react-redux";
import storageUtility from "../Utility/StorageUtility";
import {
  getOrderHistoryAction,
  updateYoyoTransactionAction
} from "../Store/actions/OrderAction";

import UserAccountView from "../Components/UserAccount/UserAccount";

class UserAccount extends React.Component {
  componentDidMount() {
    const user = storageUtility.getLoggedInUserData();
    this.props.getOrderHistory(user.id);
    this.props.getTransactionHistory(user.id);
  }

  render() {
    return (
      <UserAccountView
        userData={this.props.loginData}
        order={this.props.order}
      ></UserAccountView>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  getOrderHistory: id => dispatch(getOrderHistoryAction(id)),
  getTransactionHistory: id => dispatch(updateYoyoTransactionAction(id))
});

export default connect(mapStateToProps, mapDispatchToProps)(UserAccount);
