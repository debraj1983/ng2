import React from "react";
import { connect } from "react-redux";
import storageUtility from "../Utility/StorageUtility";

import PlaceOrderView from "../Components/PlaceOrderFlow/PlaceOrderView";

class PlaceOrder extends React.Component {
  render() {
    return (
      <PlaceOrderView
        addedItems={storageUtility.getCartData()}
        userData={this.props.loginData}
      ></PlaceOrderView>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = null;
/*
const mapDispatchToProps = dispatch => ({
  getGiftCards: () => dispatch(getGiftCardListAction())
});*/

export default connect(mapStateToProps, mapDispatchToProps)(PlaceOrder);
