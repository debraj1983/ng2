import React, { useState, useEffect } from "react";
import CardListFilter from "./CardListFilter";
import GiftList from "./GiftList";
import { PriceFilter } from "../../AppConstant";

const GiftCardListMain = props => {
  const [categories, setCategories] = useState([]);
  const [gifts, setGifts] = useState(null);
  const [priceFilter, setPriceFilter] = useState(PriceFilter);
  useEffect(() => {
    setCategories(props.categories.data);
    setGifts(props.giftcards.data);
  }, [props.categories.data, props.giftcards.data]);

  const isSelectCategory = event => {
    const toModify = [...categories]; // Assign all the category values

    const { value, checked } = event.target; // Get value and checked attribute from checkbox
    const [catPos, subCatPos] = value.split("_");
    const catIndex = parseInt(catPos);
    if (subCatPos === "-1") {
      toModify[catIndex]["checked"] = checked;
      let subCat = toModify[catIndex].subCategory.map(sC => {
        sC["checked"] = checked;
        return sC;
      });
      toModify[catIndex].subCategory = [...subCat];
    } else {
      const subCatIndex = parseInt(subCatPos);
      toModify[catIndex].subCategory[subCatIndex]["checked"] = checked;
      const isAllChecked = toModify[catIndex].subCategory.find(
        elem => elem.checked === false
      );
      if (!isAllChecked) {
        toModify[catIndex]["checked"] = true;
      } else {
        toModify[catIndex]["checked"] = false;
      }
    }
    setCategories(toModify);
    filterGiftsFn();
  };

  const isSelectPrice = event => {
    const { value, checked } = event.target;
    const toModify = [...priceFilter];

    let modifiedPriceFilter = toModify.map(price => {
      if (price.startRange + "_" + price.endRange === value)
        price["checked"] = checked;
      return price;
    });

    setPriceFilter(modifiedPriceFilter);
    filterGiftsFn();
  };

  const filterGiftsFn = () => {
    let hasFilterOptions = false;

    // Check any category selected or not
    const subCatIds = [];
    categories.forEach(element => {
      element.subCategory.forEach(elem => {
        if (elem.checked) {
          subCatIds.push(elem.id);
        }
      });
    });

    // Check any price range selected or not
    let toFilter = priceFilter.filter(price => price.checked === true);

    let filteredGifts = [];
    if (subCatIds.length > 0 && toFilter.length > 0) {
      filteredGifts = props.giftcards.data.filter(
        gift =>
          subCatIds.includes(gift.subCatId) &&
          toFilter.find(tF => {
            const { startRange, endRange, ...rest } = tF;
            return gift.yoyoPoint >= startRange && gift.yoyoPoint <= endRange;
          })
      );
      hasFilterOptions = true;
    } else if (subCatIds.length > 0) {
      filteredGifts = props.giftcards.data.filter(gift =>
        subCatIds.includes(gift.subCatId)
      );
      hasFilterOptions = true;
    } else if (toFilter.length > 0) {
      filteredGifts = props.giftcards.data.filter(gift => {
        return toFilter.find(tF => {
          const { startRange, endRange } = tF;
          return gift.yoyoPoint >= startRange && gift.yoyoPoint <= endRange;
        });
      });
      hasFilterOptions = true;
    }

    if (hasFilterOptions) {
      setGifts(filteredGifts);
    } else {
      setGifts(props.giftcards.data);
    }
  };

  return (
    <>
      <div className="text-left">
        <div className="d-flex flex-row row">
          <div className="col-lg-3 col-md-4 col-sm-12 pl-5">
            <CardListFilter
              categoryData={categories}
              priceFilter={priceFilter}
              isSelectCategory={isSelectCategory}
              isSelectPrice={isSelectPrice}
            ></CardListFilter>
          </div>
          <div className="col-lg-9 col-md-8 col-sm-12">
            <GiftList gifts={gifts}></GiftList>
          </div>
        </div>
      </div>
    </>
  );
};

export default GiftCardListMain;
