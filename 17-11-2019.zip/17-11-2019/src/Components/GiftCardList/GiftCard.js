import React from "react";
import { Link } from "react-router-dom";

const GiftCard = props => {
  return (
    <div
      className="col-lg-3 col-md-4 col-sm-12 mb-3"
      key={`giftcard${props.pos}`}
    >
      <div className="card">
        <div className="card-header">{props.gift.cardName}</div>
        <div className="card-body">
          <p>{props.gift.cardDescription}</p>
          <p>Yoyo - {props.gift.yoyoPoint}</p>
          <div className="text-center">
            <Link
              to={`/gift-card-details/${props.gift.id}`}
              className="btn btn-info btn-sm"
            >
              View Details
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GiftCard;
