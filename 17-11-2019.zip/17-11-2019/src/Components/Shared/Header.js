import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
const Header = props => {
  const [yoyoBalance, setYoyoBalance] = useState("");
  const [isLoggedIn, serIsLoggedIn] = useState(false);
  useEffect(() => {
    if (
      props.userData &&
      props.userData.loggedInData &&
      props.userData.loggedInData.yoyoBalance
    ) {
      setYoyoBalance(props.userData.loggedInData.yoyoBalance);
      serIsLoggedIn(true);
    } else {
      serIsLoggedIn(false);
    }
  }, [props.userData]);
  return (
    <>
      <header>
        <div className="d-flex flex-column flex-md-row align-items-center p-3 px-md-4 mb-3 bg-white border-bottom shadow-sm">
          <h5 className="my-0 mr-md-auto font-weight-normal">Yoyo Gift</h5>
          <nav className="my-2 my-md-0 mr-md-3">
            <Link className="p-2 text-dark" to="/">
              Home
            </Link>
            <Link className="p-2 text-dark" to="/gift-card-list">
              Gift Card List
            </Link>
            <Link className="p-2 text-dark" to="/cart">
              Cart
            </Link>
            {!isLoggedIn ? (
              <Link className="p-2 text-dark" to="/login">
                Login
              </Link>
            ) : (
              <>
                <Link className="p-2 text-dark" to="/user-account">
                  My Account
                </Link>
                <Link className="p-2 text-dark" to="/logout">
                  Logout
                </Link>
                <button type="button" className="btn btn-warning">
                  Yoyo Balance{" "}
                  <span className="badge badge-light">{yoyoBalance}</span>
                </button>
              </>
            )}
          </nav>
        </div>
      </header>
    </>
  );
};

export default Header;

/*
<nav className="navbar navbar-expand-md navbar-dark bg-dark">
          <div className="collapse navbar-collapse" id="navbarCollapse">
            <ul className="navbar-nav">
              <li className="nav-item">
                <Link className="nav-link" to="/gift-card-list">
                  Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/gift-card-list">
                  Gift Card List
                </Link>
              </li>
            </ul>

            {yoyoBalance ? (
              <span style={{ color: "#FFF", marginRight: "20px" }}>
                Yoyo Balance: {yoyoBalance}
              </span>
            ) : (
              ""
            )}

            <form className="form-inline mt-2 mt-md-0">
              <input
                className="form-control mr-sm-2"
                type="text"
                placeholder="Search"
                aria-label="Search"
              />
              <button
                className="btn btn-outline-success my-2 my-sm-0"
                type="submit"
              >
                Search
              </button>
            </form>

            <div className="float-right">
              <Link to="/cart">Basket</Link>
            </div>
          </div>
        </nav>*/
