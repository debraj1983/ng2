import * as types from "../actionTypes";
import { getApiCall } from "../../ApiCall/apiCalls";
import storageUtility from "../../Utility/StorageUtility";

export const loginSuccessAction = data => ({
  type: types.LOGIN_SUCCESS,
  data
});

export const loginFailedAction = data => ({
  type: types.LOGIN_FAILED,
  data
});

export const doLoginAction = payload => {
  return function(dispatch, getState) {
    return getApiCall("Users").then(data => {
      const user = data.find(
        elem =>
          elem.emailId === payload.loginId && elem.password === payload.password
      );
      if (user) {
        const uData = {
          ...user,
          loggedId: true
        };
        storageUtility.setLoggedIn();
        storageUtility.setLoggedInUserData(uData);
        dispatch(loginSuccessAction(uData));
      } else {
        dispatch(loginFailedAction({ loginFailed: true }));
      }
    });
  };
};
