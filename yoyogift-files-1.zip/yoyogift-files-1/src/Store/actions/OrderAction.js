import * as types from "../actionTypes";
import { postApiCall } from "../../ApiCall/apiCalls";

export const updateOrderSuccessAction = data => ({
  type: types.ORDER_PLACED,
  data
});

export const updateOrderAction = payload => {
  return function(dispatch, getState) {
    return postApiCall("UsersOrder", payload).then(data => {
      dispatch(updateOrderSuccessAction(data));
    });
  };
};

export const updateYoyoTransactionAction = payload => {
  return function(dispatch, getState) {
    return postApiCall("YoyoPaymentHistory", payload).then(data => {
      console.log(data);
    });
  };
};
