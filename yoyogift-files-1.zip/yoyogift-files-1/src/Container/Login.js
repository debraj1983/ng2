import React from "react";
import { connect } from "react-redux";
import { doLoginAction } from "../Store/actions/LoginAction";
import LoginForm from "../Components/Login/LoginForm";
import storageUtility from "../Utility/StorageUtility";
import { withRouter } from "react-router-dom";

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loginId: "",
      password: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
  }

  handleLogin(event) {
    event.preventDefault();
    const payload = this.state;
    this.props.doLoginAction(payload);
  }

  handleChange(event) {
    const { name, value } = event.target;
    this.setState({ ...this.state, [name]: value });
  }

  checkLoginFailed() {
    return (
      this.props.loginData &&
      this.props.loginData.loggedInData &&
      this.props.loginData.loggedInData.loginFailed
    );
  }

  checkLoggedIn() {
    if (
      storageUtility.checkLoggedIn() ||
      (this.props.loginData &&
        this.props.loginData.loggedInData &&
        this.props.loginData.loggedInData.loggedIn)
    ) {
      return true;
    }
    return false;
  }

  render() {
    return (
      <div className="container">
        {!this.checkLoggedIn() ? (
          <LoginForm
            doLogin={this.handleLogin}
            changeData={this.handleChange}
            loginFailed={this.checkLoginFailed()}
          />
        ) : (
          this.props.history.push(
            storageUtility.getRedirectTo()
              ? storageUtility.getRedirectTo()
              : "/user-account"
          )
        )}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  doLoginAction: payload => dispatch(doLoginAction(payload))
});

export default connect(mapStateToProps, mapDispatchToProps)(Login);
