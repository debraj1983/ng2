import GiftCardList from "./GiftCardList";
import GiftCardDetails from "./GiftCardDetails";
import Cart from "./Cart";
import Login from "./Login";
import PlaceOrder from "./PlaceOrder";
import PreviewOrder from "./PreviewOrder";
import UserAccount from "./UserAccount";
import OrderSuccess from "./OrderSuccess";

export default {
  GiftCardList,
  GiftCardDetails,
  Cart,
  Login,
  PlaceOrder,
  PreviewOrder,
  UserAccount,
  OrderSuccess
};
