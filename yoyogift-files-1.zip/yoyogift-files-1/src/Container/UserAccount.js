import React from "react";

class UserAccount extends React.Component {
  render() {
    return <div>UserAccount Components Work</div>;
  }
}

export default UserAccount;
