import ComponentList from "./Container";

const {
  GiftCardList,
  GiftCardDetails,
  Cart,
  Login,
  PlaceOrder,
  PreviewOrder,
  UserAccount,
  OrderSuccess
} = ComponentList;

const RouteConfig = [
  {
    path: "/",
    label: "Gift card",
    component: GiftCardList
  },
  {
    path: "/gift-card-list",
    label: "Gift card",
    component: GiftCardList
  },
  {
    path: "/gift-card-details/:id",
    label: "Gift card details",
    component: GiftCardDetails
  },
  {
    path: "/cart",
    label: "Cart",
    component: Cart
  },
  {
    path: "/login",
    label: "Login",
    component: Login
  },
  {
    path: "/place-order",
    label: "Place Order",
    component: PlaceOrder
  },
  {
    path: "/preview-order",
    label: "Preview Order",
    component: PreviewOrder
  },
  {
    path: "/user-account",
    label: "User Account",
    component: UserAccount
  },
  {
    path: "/order-success",
    label: "Order Success",
    component: OrderSuccess
  }
];

export default RouteConfig;
