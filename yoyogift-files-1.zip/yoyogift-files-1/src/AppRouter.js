import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { connect } from "react-redux";

import RouteConfig from "./AppConstant";
import Header from "./Components/Shared/Header";
import storageUtility from "./Utility/StorageUtility";
import { loginSuccessAction } from "./Store/actions/LoginAction";

class AppRouter extends React.Component {
  componentDidMount() {
    if (storageUtility.checkLoggedIn()) {
      this.props.setLoginDataToStore(storageUtility.getLoggedInUserData());
    }
  }

  render() {
    return (
      <Router>
        <Header userData={this.props.loginData}></Header>
        <Switch>
          {RouteConfig.map((config, index) => (
            <Route
              path={config.path}
              exact
              component={config.component}
              key={`route${index}`}
            />
          ))}
        </Switch>
      </Router>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  setLoginDataToStore: data => dispatch(loginSuccessAction(data))
});

export default connect(mapStateToProps, mapDispatchToProps)(AppRouter);
