import storage from "./AppStorage";

const STORAGE_KEYS = {
  LOGGEDIN: "loggedIn",
  LOGGEDIN_USER_DETAILS: "loggedInUserDetails",
  CART: "cart",
  REDIRECT_TO: "redirect_to",
  TO_PLACE_ORDER: "toPlaceOrder"
};

const storageUtility = {
  checkLoggedIn: () => storage.getData(STORAGE_KEYS.LOGGEDIN, "session"),
  getLoggedInUserData: () =>
    storage.getData(STORAGE_KEYS.LOGGEDIN_USER_DETAILS, "session"),
  setLoggedIn: () => storage.setData(STORAGE_KEYS.LOGGEDIN, true, "session"),
  setLoggedInUserData: data =>
    storage.setData(STORAGE_KEYS.LOGGEDIN_USER_DETAILS, data, "session"),
  doLogout: () => storage.clearData("session"),
  getCartData: () => storage.getData(STORAGE_KEYS.CART, "session"),
  setCartData: data => storage.setData(STORAGE_KEYS.CART, data, "session"),
  setRedirectTo: data =>
    storage.setData(STORAGE_KEYS.REDIRECT_TO, data, "session"),
  getRedirectTo: () => storage.getData(STORAGE_KEYS.REDIRECT_TO, "session"),
  setToPlaceOrder: data =>
    storage.setData(STORAGE_KEYS.TO_PLACE_ORDER, data, "session"),
  getToPlaceOrder: () => storage.getData(STORAGE_KEYS.TO_PLACE_ORDER, "session")
};

export default storageUtility;
