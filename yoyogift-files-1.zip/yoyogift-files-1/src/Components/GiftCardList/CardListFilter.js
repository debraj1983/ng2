import React from "react";

const CardListFilter = props => {
  const cat = props.categoryData;
  console.log("----->", cat);
  return (
    <div>
      <ul>
        {cat &&
          cat.length > 0 &&
          cat.map((c, index) => (
            <li key={`cat${c.id}_${index}`}>
              <input
                key={`checkbox${c.id}_${c.index}`}
                type="checkbox"
                name="selectedcat[]"
                value={`${index}_-1`}
                checked={c.checked}
                onChange={props.isSelectCategory}
              />{" "}
              {c.name}
              <ul>
                {c.subCategory &&
                  c.subCategory.length &&
                  c.subCategory.map((sC, subIndex) => (
                    <li key={`cat${sC.id}_${c.index}_${subIndex}`}>
                      <input
                        key={`checkbox${sC.id}_${c.index}_${subIndex}`}
                        type="checkbox"
                        name="selectedsubcat[]"
                        value={`${index}_${subIndex}`}
                        checked={sC.checked}
                        onChange={props.isSelectCategory}
                      />{" "}
                      {sC.name}
                    </li>
                  ))}
              </ul>
            </li>
          ))}
      </ul>
    </div>
  );
};

export default CardListFilter;
