import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import storageUtility from "../../Utility/StorageUtility";

const CartView = props => {
  const [cartItems, setCartItem] = useState([]);
  useEffect(() => {
    if (props.cartItems && props.cartItems.length > 0) {
      setCartItem(props.cartItems);
    }
  }, [props.cartItems]);

  const getTotalCartValue = () => {
    let total = 0;
    cartItems.forEach(eachElem => {
      total += parseInt(eachElem.yoyoPoint);
    });
    return total;
  };

  const removeItemCart = pos => {
    const items = cartItems.filter((item, index) => index !== pos);
    setCartItem(items);
    storageUtility.setCartData(items);
  };

  return (
    <div className="w-75 mx-auto">
      <h4>Shopping Cart</h4>
      <table className="table">
        <thead className="thead-light">
          <tr>
            <th scope="col">Item ID</th>
            <th scope="col">Item Name</th>
            <th scope="col">Price </th>
            <th scope="col">Yoyo Value</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          {cartItems && cartItems.length > 0 ? (
            cartItems.map((item, index) => (
              <tr key={`itemsRow${index}`}>
                <td>{item.cardId}</td>
                <td>{item.name}</td>
                <td>{item.cardValue}</td>
                <td>{item.yoyoPoint}</td>
                <td>
                  <input
                    type="button"
                    value="X"
                    className="btn btn-danger btn-sm"
                    onClick={() => removeItemCart(index)}
                  />
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="alert alert-danger">
                No item added in cart
              </td>
            </tr>
          )}
        </tbody>
      </table>
      {cartItems && cartItems.length > 0 ? (
        <>
          <input
            type="button"
            value="Place Order"
            className="btn btn-info btn-sm"
            onClick={() => props.checkAndNavigate()}
          />
          &nbsp;&nbsp;
          <Link to="/gift-card-list" className="btn btn-info btn-sm">
            Shop More
          </Link>
          <span className="float-right">
            Cart Total: {getTotalCartValue()} Yoyo
          </span>
        </>
      ) : (
        <Link to="/gift-card-list" className="btn btn-info btn-sm">
          Shop More
        </Link>
      )}
    </div>
  );
};

export default CartView;
