var config = {
  editorBg: {
    blockId: "droppable",
    gap: 10,
    strokeColor: "#e2e2e2",
  },
  draggableImages: [
    "https://editor-statics.s3.ap-south-1.amazonaws.com/Image1.png",
    "https://editor-statics.s3.ap-south-1.amazonaws.com/Image2.png",
  ],
};
