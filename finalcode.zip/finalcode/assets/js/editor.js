(function (option, Base64) {
  var fn = {
    setEditorBackground: function () {
      var editorID = option.editorBg.blockId;
      var width = document.getElementById(editorID).offsetWidth;
      var height = document.getElementById(editorID).offsetHeight;
      var gap = option.editorBg.gap;
      var strokeColor = option.editorBg.strokeColor;

      var svg =
        '<svg width="' +
        width +
        '" height="' +
        height +
        '" xmlns="http://www.w3.org/2000/svg">';
      for (var x = 0; x <= height; x += gap) {
        svg +=
          '<line x1="0" x2="' +
          width +
          '" y1="' +
          x +
          '" y2="' +
          x +
          '" stroke="' +
          strokeColor +
          '" stroke-width=".5" />';
      }
      for (var y = 0; y <= width; y += gap) {
        svg +=
          '<line x1="' +
          y +
          '" x2="' +
          y +
          '" y1="0" y2="' +
          height +
          '" stroke="' +
          strokeColor +
          '" stroke-width=".5" />';
      }
      svg += "</svg>";
      document.getElementById(editorID).style.backgroundImage =
        "url('data:image/svg+xml;base64," + Base64.encode(svg) + "')";
    },
    init: function () {
      this.setEditorBackground();
    },
  };

  fn.init();
})(config, Base64);
