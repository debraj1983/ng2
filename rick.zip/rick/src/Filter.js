import React from "react";

/*import List from "@material-ui/core/List";
import ListSubheader from "@material-ui/core/ListSubheader";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Checkbox from "@material-ui/core/Checkbox";*/
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import FormControl from "@material-ui/core/FormControl";
import FormLabel from "@material-ui/core/FormLabel";

import filterCriteria from "./Constant";

/*
const Filter = props => {
  return (
    <>
      {filterCriteria.map((fC, index) => (
        <List
          key={`List${index}`}
          subheader={
            <ListSubheader component="div" id="nested-list-subheader">
              {fC.title}
            </ListSubheader>
          }
        >
          {fC.items.map(item => {
            const labelId = `checkbox-list-label-${item.value}`;

            return (
              <ListItem key={item.value} dense button>
                <Checkbox
                  value={`${item.value}-${fC.queryParam}`}
                  onChange={props.isChecked}
                />
                <ListItemText id={labelId} primary={item.text} />
              </ListItem>
            );
          })}
        </List>
      ))}
    </>
  );
};*/

const Filter = props => {
  return (
    <>
      {filterCriteria.map((fC, index) => (
        <FormControl component="fieldset" key={`List${index}`}>
          <FormLabel component="legend">{fC.title}</FormLabel>
          <RadioGroup
            aria-label="gender"
            name="gender1"
            onChange={props.isChecked}
          >
            {fC.items.map(item => {
              const labelId = `checkbox-list-label-${item.value}`;
              return (
                <FormControlLabel
                  key={item.value}
                  value={`${item.value}-${fC.queryParam}`}
                  control={<Radio />}
                  label={item.text}
                  id={labelId}
                />
              );
            })}
          </RadioGroup>
        </FormControl>
      ))}
    </>
  );
};

export default Filter;
