import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { IonicAlertService } from '../../services/ionic-alert.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.page.html',
  styleUrls: ['./signup.page.scss'],
})
export class SignupPage implements OnInit {

  public signupForm: FormGroup;
  public signedUp: boolean;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private ionicAlertService: IonicAlertService,
    private router: Router
  ) { }

  ngOnInit() {
    this.signupForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      confirmpassword: ['', Validators.required]
    });
  }


  public userSignUp(): void {
    const payload = {
      username: this.signupForm.value.username,
      password: this.signupForm.value.password
    };
    this.authService.doSignUp(payload).then(data => {
      if (data) {
        this.ionicAlertService.createAlert({
          message: 'Thanks for joining with us. Please login to continue.',
          buttons: [
            {
              text: 'Continue',
              handler: () => {
                this.router.navigateByUrl('/login');
              }
            }
          ]
        });
      }
    }, error => {
      console.log(error);
    });

  }
}
