export const STORAGE_CONST = {
    user: {username: '', password: ''},
    loggedIn: '0',
    skymilePoints: 10000,
    edgePoints: 5000,
    flights: [{
        flightName: 'Flight 1',
        departureTime: '9:00',
        arrivalTime: '11:30',
        fare: '3500',
        skymilePt: '350'
    }, {
        flightName: 'Flight 2',
        departureTime: '13:00',
        arrivalTime: '15:30',
        fare: '5000',
        skymilePt: '500'
    }, {
        flightName: 'Flight 3',
        departureTime: '16:00',
        arrivalTime: '18:30',
        fare: '4500',
        skymilePt: '450'
    }, {
        flightName: 'Flight 4',
        departureTime: '17:00',
        arrivalTime: '19:30',
        fare: '6500',
        skymilePt: '650'
    }],
    travelHistory: [
        {
            pnr: 'DA234',
            travelDate: '09/11/2019'
        },
        {
            pnr: 'DA543',
            travelDate: '10/29/2019'
        },
        {
            pnr: 'DA268',
            travelDate: '11/23/2019'
        },
        {
            pnr: 'DA098',
            travelDate: '12/31/2019'
        },
        {
            pnr: 'DA276',
            travelDate: '02/13/2020'
        }
    ],
    bookingDetails: []
};
