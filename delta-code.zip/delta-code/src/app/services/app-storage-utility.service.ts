import { SESSION_STORAGE } from 'ngx-webstorage-service';
import { Injectable } from '@angular/core';
import { AppStorageService } from './app-storage.service';
import { STORAGE_CONST } from '../data';

export const STORAGE_TYPE = {
  SESSION: 'session',
  LOCAL: 'local'
};

@Injectable({
  providedIn: 'root'
})
export class AppStorageUtilityService {

  constructor(private appStorageService: AppStorageService) { }

  public checkUserLoggedIn(): boolean {
    const loggedIn = this.appStorageService.getData('loggedIn', STORAGE_TYPE.LOCAL);
    return (loggedIn && loggedIn.toString() === '1') ? true : false;
  }

  public doSignUpUtility(payload): any {
    const updatedStorageData = {...STORAGE_CONST, user: {...payload}};
    return this.appStorageService.clearAndSetDataInStorage(updatedStorageData, STORAGE_TYPE.LOCAL);
  }

  public doSignInUtility(payload): any {
    const user = this.appStorageService.getData('user', STORAGE_TYPE.LOCAL);
    if (user.username === payload.username && user.password === payload.password) {
      this.appStorageService.setData('loggedIn', '1', STORAGE_TYPE.LOCAL);
      return true;
    } else {
      return false;
    }
  }

  public gerUsername(): string {
    const user = this.appStorageService.getData('user', STORAGE_TYPE.LOCAL);
    return (user && user.username) ? user.username : '';
  }

  public getSkyAndEdgePt(): any {
    const skymilePoints = this.appStorageService.getData('skymilePoints', STORAGE_TYPE.LOCAL);
    const edgePoints = this.appStorageService.getData('edgePoints', STORAGE_TYPE.LOCAL);
    const travelHistory = this.appStorageService.getData('travelHistory', STORAGE_TYPE.LOCAL);
    return { skymilePoints, edgePoints, travelHistory };
  }
}
