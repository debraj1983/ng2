import { Component, OnInit } from '@angular/core';
import { AppStorageUtilityService } from '../../../services/app-storage-utility.service';

@Component({
  selector: 'app-loggedin-header',
  templateUrl: './loggedin-header.component.html',
  styleUrls: ['./loggedin-header.component.scss'],
})
export class LoggedinHeaderComponent implements OnInit {

  public welcomeTxt: string;

  constructor(private appStorageUtilityService: AppStorageUtilityService) { }

  ngOnInit() {
    this.welcomeTxt = this.appStorageUtilityService.gerUsername();
    this.welcomeTxt = (this.welcomeTxt) ? 'Welcome ' + this.welcomeTxt : '';
  }
}
