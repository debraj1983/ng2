import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-flight-search-oneway',
  templateUrl: './flight-search-oneway.component.html',
  styleUrls: ['./flight-search-oneway.component.scss'],
})
export class FlightSearchOnewayComponent implements OnInit {

  @Output()
  public doSearch: EventEmitter<any> = new EventEmitter();

  public source: string;
  public destination: string;
  public travelDate: any;
  public noOfPassenger: number;
  public today: string;

  public sourceList: string[];
  public destList: string[];

  constructor() { }

  ngOnInit() {
    this.noOfPassenger = 1;
    this.today = this.getToday();
    this.sourceList = this.getSource();
    this.destList = this.getDestination();
    console.log(this.sourceList);
  }

  public addRemovePassenger(op): void {
    if (op === 'add') {
      this.noOfPassenger++;
    } else {
     if (this.noOfPassenger > 1) {
      this.noOfPassenger--;
     }
    }
  }

  public doSearchFn() {
    this.doSearch.emit(true);
  }

  private getToday() {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); // January is 0!
    const yyyy = today.getFullYear();
// console.log(dd,mm,yyyy);
    return `${yyyy}-${mm}-${dd}`;
  }

  private getSource() {
    const sources = [];
    for (let i = 1; i <= 10; i++) {
      sources.push('Source ' + i);
    }
    return sources;
  }

  private getDestination() {
    const destination = [];
    for (let i = 1; i <= 10; i++) {
      destination.push('Destination ' + i);
    }
    return destination;
  }
}
