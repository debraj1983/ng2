import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserPage } from './user.page';

const routes: Routes = [
  {
    path: 'user',
    component: UserPage,
    children: [
      {
        path: 'mydelta',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../mydelta/mydelta.module').then(m => m.MydeltaPageModule)
          }
        ]
      },
      {
        path: 'book',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../book/book.module').then(m => m.BookPageModule)
          }
        ]
      },
      {
        path: 'today',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../today/today.module').then(m => m.TodayPageModule)
          }
        ]
      },
      {
        path: 'feed',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../feed/feed.module').then(m => m.FeedPageModule)
          }
        ]
      },
      {
        path: 'more',
        children: [
          {
            path: '',
            loadChildren: () =>
              import('../more/more.module').then(m => m.MorePageModule)
          }
        ]
      },
      {
        path: '',
        redirectTo: '/user/book',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/user/book',
    pathMatch: 'full'
  }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserPageRoutingModule {}
