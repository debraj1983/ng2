import { Component, OnInit } from '@angular/core';

import {} from '../../services/app-storage-utility.service';
@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.page.html',
  styleUrls: ['./search-result.page.scss'],
})
export class SearchResultPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
