import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { MydeltaPageRoutingModule } from './mydelta-routing.module';

import { MydeltaPage } from './mydelta.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    MydeltaPageRoutingModule
  ],
  declarations: [MydeltaPage]
})
export class MydeltaPageModule {}
