import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MydeltaPage } from './mydelta.page';

const routes: Routes = [
  {
    path: '',
    component: MydeltaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MydeltaPageRoutingModule {}
