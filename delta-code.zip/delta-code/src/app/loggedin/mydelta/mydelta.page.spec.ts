import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { MydeltaPage } from './mydelta.page';

describe('MydeltaPage', () => {
  let component: MydeltaPage;
  let fixture: ComponentFixture<MydeltaPage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MydeltaPage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(MydeltaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
