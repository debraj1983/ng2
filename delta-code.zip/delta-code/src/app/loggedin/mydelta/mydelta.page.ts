import { Component, OnInit } from '@angular/core';
import { AppStorageUtilityService } from '../../services/app-storage-utility.service';
@Component({
  selector: 'app-mydelta',
  templateUrl: './mydelta.page.html',
  styleUrls: ['./mydelta.page.scss'],
})
export class MydeltaPage implements OnInit {
  public pageData;
  constructor(private appStorageUtilityService: AppStorageUtilityService) { }

  ngOnInit() {
    this.pageData = this.appStorageUtilityService.getSkyAndEdgePt();
    console.log(this.pageData);
  }

}
