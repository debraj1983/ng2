import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-passenger-info',
  templateUrl: './passenger-info.page.html',
  styleUrls: ['./passenger-info.page.scss'],
})
export class PassengerInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
