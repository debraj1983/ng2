import ComponentList from './Container';

const {
  GiftCardList,
  GiftCardDetails,
  Cart,
  Login,
  PlaceOrder,
  PreviewOrder,
  UserAccount,
  OrderSuccess,
  Logout,
} = ComponentList;

export const RouteConfig = [
  {
    path: '/',
    label: 'Gift card',
    component: GiftCardList,
    protected: false,
  },
  {
    path: '/gift-card-list',
    label: 'Gift card',
    component: GiftCardList,
    protected: false,
  },
  {
    path: '/gift-card-details/:id',
    label: 'Gift card details',
    component: GiftCardDetails,
    protected: false,
  },
  {
    path: '/cart',
    label: 'Cart',
    component: Cart,
    protected: false,
  },
  {
    path: '/login',
    label: 'Login',
    component: Login,
    protected: false,
  },
  {
    path: '/logout',
    label: 'Logout',
    component: Logout,
    protected: true,
  },
  {
    path: '/add-information',
    label: 'Add Information',
    component: PlaceOrder,
    protected: true,
  },
  {
    path: '/preview-order',
    label: 'Preview Order',
    component: PreviewOrder,
    protected: true,
  },
  {
    path: '/user-account',
    label: 'User Account',
    component: UserAccount,
    protected: true,
  },
  {
    path: '/order-success',
    label: 'Order Success',
    component: OrderSuccess,
    protected: true,
  },
];
export const PriceFilter = [
  {
    id: 1,
    startRange: 0,
    endRange: 500,
    checked: false,
  },
  {
    id: 2,
    startRange: 501,
    endRange: 1000,
    checked: false,
  },
  {
    id: 1,
    startRange: 1001,
    endRange: 1500,
    checked: false,
  },
  {
    id: 1,
    startRange: 1501,
    endRange: 2000,
    checked: false,
  },
];

export const DiscoutFilter = [
  {
    id: 1,
    discount: 10,
    checked: false,
  },
  {
    id: 2,
    discount: 20,
    checked: false,
  },
  {
    id: 3,
    discount: 30,
    checked: false,
  },
];

export const YoyoRedeemCode = [
  {
    code: 'YOYO2000',
    yoyoBal: 2000,
  },
  {
    code: 'YOYO5000',
    yoyoBal: 5000,
  },
  {
    code: 'YOYO10000',
    yoyoBal: 10000,
  },
];
