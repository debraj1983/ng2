const STORAGE_KEY = 'YOYOGIFT';
const dataStorage = {
  storageObj: storage => {
    let storeApiObj = window.localStorage;
    if (storage && storage === 'session') {
      storeApiObj = window.sessionStorage;
    }
    return storeApiObj;
  },
  setData: (key, data, storage) => {
    let addedData = dataStorage.storageObj(storage).getItem(STORAGE_KEY);
    if (!addedData) {
      addedData = {};
      addedData[key] = data;
    } else {
      addedData = JSON.parse(addedData);
      addedData[key] = data;
    }

    const toSave = JSON.stringify(addedData);
    dataStorage.storageObj(storage).setItem(STORAGE_KEY, toSave);
  },
  getData: (key, storage) => {
    let data = dataStorage.storageObj(storage).getItem(STORAGE_KEY);
    data = JSON.parse(data);
    return data && data[key] ? data[key] : null;
  },
  setDataInObject: (key, subkey, data, storage) => {
    const keyData = dataStorage.getData(key, storage);
    keyData[subkey] = data;
    dataStorage.setData(key, keyData, storage);
  },
  clearData: storage => {
    dataStorage.storageObj(storage).clear();
  },
};

export default dataStorage;
