export const CommonUtility = {
  getFormattedCatObj: categories => {
    let modifiedCatObj = [];
    if (categories && categories.length > 0) {
      let modifiedObj = [];
      modifiedObj = categories.filter(cat => {
        if (cat.parentId === 0) {
          cat['checked'] = false;
          return cat;
        }
      });
      modifiedCatObj = modifiedObj.map(mO => {
        let subCategory = [];
        subCategory = categories.filter(cat => {
          if (cat.parentId > 0 && cat.parentId === mO.id) {
            cat['checked'] = false;
            return cat;
          }
        });
        return { ...mO, subCategory };
      });
    }
    return modifiedCatObj;
  },
};
