import React from 'react';

class OrderSuccess extends React.Component {
  render() {
    return <div className="success-message">Order Successfully Placed</div>;
  }
}

export default OrderSuccess;
