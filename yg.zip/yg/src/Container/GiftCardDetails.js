import React from 'react';
import { connect } from 'react-redux';
import { withRouter } from 'react-router-dom';

import { getGiftCardListAction } from '../Store/actions/GiftCardAction';
import GiftCardDetailsView from '../Components/GiftCardDetails/GiftCardDetailsView';

import storageUtility from '../Utility/StorageUtility';

class GiftCardDetails extends React.Component {
  constructor(props) {
    super(props);
    this.addToCart = this.addToCart.bind(this);
    this.navigateToCart = this.navigateToCart.bind(this);
    this.state = {
      itemAddedToCart: this.checkItemAddedInCart(props.match.params.id),
    };
  }
  componentDidMount() {
    this.props.getGiftCards();
  }

  // Check Data and add to cart
  addToCart(giftObj) {
    let cartObj = storageUtility.getCartData();
    if (!cartObj) {
      cartObj = [];
      cartObj.push(giftObj);
    } else {
      const isAdded =
        cartObj &&
        cartObj.length > 0 &&
        cartObj.find(obj => obj.cardId === giftObj.cardId);
      if (!isAdded) {
        cartObj.push(giftObj);
      }
    }
    storageUtility.setCartData(cartObj);
    this.setState(() => {
      return { itemAddedToCart: true };
    });
  }

  checkItemAddedInCart(id) {
    let cartObj = storageUtility.getCartData();
    const isAdded =
      cartObj &&
      cartObj.length > 0 &&
      cartObj.find(obj => obj.cardId.toString() === id);
    return isAdded ? true : false;
  }

  navigateToCart() {
    this.props.history.push('/cart');
    // this.props.history.push('/cart');
  }

  render() {
    return (
      <GiftCardDetailsView
        gifts={this.props.giftcards}
        params={this.props.match.params}
        addToCart={this.addToCart}
        itemAddedToCart={this.state.itemAddedToCart}
        navigateToCart={this.navigateToCart}
      ></GiftCardDetailsView>
    );
  }
}

const mapStateToProps = state => ({
  ...state,
});

const mapDispatchToProps = dispatch => ({
  getGiftCards: () => dispatch(getGiftCardListAction()),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(GiftCardDetails));
