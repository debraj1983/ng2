import React from 'react';
import { withRouter } from 'react-router-dom';
import { connect } from 'react-redux';
import storageUtility from '../Utility/StorageUtility';

import PlaceOrderView from '../Components/PlaceOrderFlow/PlaceOrderView';

class PlaceOrder extends React.Component {
  constructor(props) {
    super(props);
    this.navigateTo = this.navigateTo.bind(this);
  }

  navigateTo(url) {
    this.props.history.push(url);
  }

  render() {
    return (
      <PlaceOrderView
        addedItems={storageUtility.getCartData()}
        userData={this.props.loginData}
        navigateTo={this.navigateTo}
      ></PlaceOrderView>
    );
  }
}

const mapStateToProps = state => ({
  ...state,
});

const mapDispatchToProps = null;
/*
const mapDispatchToProps = dispatch => ({
  getGiftCards: () => dispatch(getGiftCardListAction())
});*/

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(withRouter(PlaceOrder));
