import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import TypoGraphy from '@material-ui/core/TypoGraphy';
import withWidth from '@material-ui/core/withWidth';

import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';
import Hidden from '@material-ui/core/Hidden';
import { fade, makeStyles } from '@material-ui/core/styles';
import InputBase from '@material-ui/core/InputBase';
import Input from '@material-ui/core/Input';

import Button from '@material-ui/core/Button';
import SearchIcon from '@material-ui/icons/Search';

import Navbar from './Navbar';

const useStyles = makeStyles(theme => ({
  search: {
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: fade(theme.palette.common.white, 0.15),
    '&:hover': {
      backgroundColor: fade(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    marginTop: 15,
    width: 'max-content',
  },
  searchIcon: {
    width: theme.spacing(7),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    alignItems: 'center',
    justifyContent: 'center',
    right: 0,
  },
  inputRoot: {
    color: '#FFF',
  },
  inputInput: {
    padding: theme.spacing(1, 7, 1, 1),
    transition: theme.transitions.create('width'),
    width: '100%',
  },
}));

const Header = props => {
  console.log(props);
  const [yoyoBalance, setYoyoBalance] = useState('');
  const [isLoggedIn, serIsLoggedIn] = useState(false);
  useEffect(() => {
    if (
      props.userData &&
      props.userData.loggedInData &&
      props.userData.loggedInData.yoyoBalance
    ) {
      setYoyoBalance(props.userData.loggedInData.yoyoBalance);
      serIsLoggedIn(true);
    } else {
      serIsLoggedIn(false);
    }
  }, [props.userData]);

  const classes = useStyles();
  return (
    <>
      <AppBar color="default">
        <Toolbar>
          <Grid container spacing={0}>
            <Grid item xs={12} sm={12} md={4} lg={2} xl={2}>
              <Paper>
                <TypoGraphy variant="h4" color="inherit">
                  YoyoGift
                </TypoGraphy>
              </Paper>
            </Grid>
            <Grid item xs={12} sm={12} md={8} lg={4} xl={4}>
              <Paper>
                <form action="/gift-card-list/" method="GET">
                  <div className={classes.search}>
                    <InputBase
                      placeholder="Search…"
                      classes={{
                        root: classes.inputRoot,
                        input: classes.inputInput,
                      }}
                      inputProps={{ 'aria-label': 'search', name: 'q' }}
                    />
                    <Input type="hidden" name="op" value="search" />

                    <Button type="submit">
                      <SearchIcon />
                    </Button>
                  </div>
                </form>
              </Paper>
            </Grid>
            <Hidden only={['xs', 'sm', 'md']}>
              <Grid item xs={6}>
                <Paper>
                  <Navbar
                    isLoggedIn={isLoggedIn}
                    yoyoBalance={yoyoBalance}
                  ></Navbar>
                </Paper>
              </Grid>
            </Hidden>
          </Grid>
        </Toolbar>
      </AppBar>
    </>
  );
};

Header.propTypes = {
  width: PropTypes.oneOf(['lg', 'md', 'sm', 'xl', 'xs']).isRequired,
};

export default withWidth()(Header);

/*
<header
        className="header-bg position-fixed w-100 h100 p-2"
        style={{ zIndex: 10 }}
      >
        <div className="d-flex flex-row justify-content-between align-items-center">
          <div className="p-2 bd-highlight">
            <h5 className=" font-weight-bold font-20 text-white">YoyoGift</h5>
          </div>
          <div className="p-2 bd-highlight w-auto">
            <form onSubmit={props.doSearch}>
              <input
                placeholder="Search here"
                type="text"
                className="form-control search-txt float-left"
                name="search"
                onChange={props.changeData}
              />
              <button
                type="submit"
                className="btn btn-light search-btn float-left mr-2"
              >
                Search
              </button>
              &nbsp;
              <button
                type="button"
                className="btn btn-light search-btn  float-left"
                onClick={() => props.resetSearch()}
              >
                Reset
              </button>
            </form>
          </div>
          <div className="p-2 bd-highlight">
            <nav className="my-2 my-md-0 mr-md-3">
              <Link className="p-2 text-white" to="/gift-card-list">
                Gift Card List
              </Link>
              <Link className="p-2 text-white" to="/cart">
                Cart
              </Link>
              {!isLoggedIn ? (
                <Link className="p-2 text-white" to="/login">
                  Login
                </Link>
              ) : (
                <>
                  <Link className="p-2 text-white" to="/user-account">
                    My Account
                  </Link>
                  <Link className="p-2 text-white" to="/logout">
                    Logout
                  </Link>
                  <button type="button" className="btn btn-warning">
                    Yoyo Balance{' '}
                    <span className="badge badge-light">{yoyoBalance}</span>
                  </button>
                </>
              )}
            </nav>
          </div>
        </div>
      </header>*/
