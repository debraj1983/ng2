import React, { useState, useEffect } from 'react';
import CardListFilter from './CardListFilter';
import GiftList from './GiftList';
import { PriceFilter, DiscoutFilter } from '../../AppConstant';

const GiftCardListMain = props => {
  // States
  const [categories, setCategories] = useState([]);
  const [gifts, setGifts] = useState(null);
  const [priceFilter, setPriceFilter] = useState(PriceFilter);
  const [discoutFilter, setDiscoutFilter] = useState(DiscoutFilter);

  const [drawerState, setDrawerState] = useState({
    top: false,
  });

  const toggleDrawer = (side, open) => event => {
    if (
      event.type === 'keydown' &&
      (event.key === 'Tab' || event.key === 'Shift')
    ) {
      return;
    }

    setDrawerState({ [side]: open });
  };

  // Effects
  useEffect(() => {
    setCategories(props.categories.data);
    setGifts(props.giftcards.data);
  }, [props.categories.data, props.giftcards.data]);

  // Changing value of "checked" in category array
  const isSelectCategory = event => {
    const toModify = [...categories]; // Assign all the category values

    const { value, checked } = event.target; // Get value and checked attribute from checkbox
    const [catPos, subCatPos] = value.split('_');
    const catIndex = parseInt(catPos);
    if (subCatPos === '-1') {
      toModify[catIndex]['checked'] = checked;
      let subCat = toModify[catIndex].subCategory.map(sC => {
        sC['checked'] = checked;
        return sC;
      });
      toModify[catIndex].subCategory = [...subCat];
    } else {
      const subCatIndex = parseInt(subCatPos);
      toModify[catIndex].subCategory[subCatIndex]['checked'] = checked;
      const isAllChecked = toModify[catIndex].subCategory.find(
        elem => elem.checked === false
      );
      if (!isAllChecked) {
        toModify[catIndex]['checked'] = true;
      } else {
        toModify[catIndex]['checked'] = false;
      }
    }
    setCategories(toModify);
    filterGiftsFn();
  };

  // Changing value of "checked" in priceFilter array
  const isSelectPrice = event => {
    const { value, checked } = event.target;
    const toModify = [...priceFilter];

    let modifiedPriceFilter = toModify.map(price => {
      if (price.startRange + '_' + price.endRange === value)
        price['checked'] = checked;
      return price;
    });

    setPriceFilter(modifiedPriceFilter);
    filterGiftsFn();
  };

  // Changing value of "checked" in priceFilter array
  const isDiscout = event => {
    const { value, checked } = event.target;
    const toModify = [...discoutFilter];

    let modifiedDiscoutFilter = toModify.map(disc => {
      if (disc.discount === parseInt(value)) {
        disc['checked'] = checked;
      }
      return disc;
    });

    setDiscoutFilter(modifiedDiscoutFilter);
    filterGiftsFn();
  };

  const checkFilterSatisfied = (needToFilter, gift) => {
    let hasTrue = true;
    needToFilter.forEach(elem => {
      if (!elem.condition(gift)) {
        hasTrue = false;
      }
    });
    return hasTrue;
  };

  const filterGiftsFn = () => {
    let hasFilterOptions = false;

    // Check any category selected or not
    const subCatIds = [];
    categories.forEach(element => {
      element.subCategory.forEach(elem => {
        if (elem.checked) {
          subCatIds.push(elem.id);
        }
      });
    });

    // Check any price range selected or not
    let toFilter = priceFilter.filter(price => price.checked === true);

    // Check any discount selected or not
    let toDiscountFilter = discoutFilter.filter(disc => disc.checked === true);

    let needToFilter = [];
    if (subCatIds.length > 0) {
      needToFilter.push({
        filter: 'category',
        condition: gift => subCatIds.includes(gift.subCatId),
      });
    }

    if (toFilter.length > 0) {
      needToFilter.push({
        filter: 'price',
        condition: gift =>
          toFilter.find(tF => {
            const { startRange, endRange } = tF;
            return gift.yoyoPoint >= startRange && gift.yoyoPoint <= endRange;
          }),
      });
    }

    if (toDiscountFilter.length > 0) {
      needToFilter.push({
        filter: 'discount',
        condition: gift =>
          toDiscountFilter.find(tDF => {
            return gift.discount === tDF.discount;
          }),
      });
    }

    let filteredGifts = [...props.giftcards.data];
    if (needToFilter.length > 0) {
      // Final code
      filteredGifts = filteredGifts.filter(gift =>
        checkFilterSatisfied(needToFilter, gift)
      );
      hasFilterOptions = true;
    }

    if (hasFilterOptions) {
      setGifts(filteredGifts);
    } else {
      setGifts(props.giftcards.data);
    }
  };

  return (
    <>
      <CardListFilter
        toggleDrawer={toggleDrawer}
        drawerState={drawerState}
        categoryData={categories}
        priceFilter={priceFilter}
        discoutFilter={discoutFilter}
        isSelectCategory={isSelectCategory}
        isSelectPrice={isSelectPrice}
        isDiscout={isDiscout}
      ></CardListFilter>
      <div>
        <GiftList
          gifts={gifts}
          changeData={props.changeData}
          doSearch={props.doSearch}
        ></GiftList>
      </div>
    </>
  );
};

export default GiftCardListMain;
