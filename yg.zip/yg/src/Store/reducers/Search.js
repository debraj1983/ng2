import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.SEARCH_TXT:
      return { ...state, data: action.data };
    case types.RESET_SEARCH:
      return { ...state, reset: action.data };
    default:
      return state;
  }
};
