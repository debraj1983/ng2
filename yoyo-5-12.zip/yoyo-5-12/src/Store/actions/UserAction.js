import * as types from '../actionTypes';
import { putApiCall } from '../../ApiCall/apiCalls';
import storageUtility from '../../Utility/StorageUtility';

export const updateUserSuccessAction = data => ({
  type: types.USER_UPDATE_SUCCESS,
  data,
});

export const updateUserAction = (payload, id) => {
  return function(dispatch, getState) {
    return putApiCall('Users/' + id, payload).then(data => {
      storageUtility.setLoggedInUserData(data);
      dispatch(updateUserSuccessAction(data));
    });
  };
};
