import * as types from '../actionTypes';
import { getApiCall } from '../../ApiCall/apiCalls';

export const getGiftCardSuccessAction = data => ({
  type: types.GET_GIFT_CARDS,
  data,
});

export const getGiftCardListAction = () => {
  return function(dispatch, getState) {
    return getApiCall('GiftCards').then(data => {
      if (data && data.length > 0) {
        dispatch(getGiftCardSuccessAction(data));
      }
    });
  };
};

export const getGiftCardSearchAction = q => {
  return function(dispatch, getState) {
    return getApiCall('GiftCards?q=' + q).then(data => {
      if (data) {
        dispatch(getGiftCardSuccessAction(data));
      }
    });
  };
};
