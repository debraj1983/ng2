import React from 'react';

import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';

const useStyles = makeStyles({
  root: {
    width: '90%',
    overflowX: 'hidden',
    margin: '0 auto',
  },
  table: {
    width: '100%',
  },
});

const TransactionHistory = props => {
  const classes = useStyles();
  const transactionHistory = props.transactionHistory;
  const unitTimeToDate = unixTimestamp => {
    const date = new Date(unixTimestamp);
    return `${date.getDate()}-${date.getMonth() +
      1}-${date.getFullYear()} ${date.getHours()}: ${date.getMinutes()}: ${date.getSeconds()}`;
  };
  return (
    <>
      {transactionHistory && transactionHistory.length > 0 ? (
        <div>
          <Table className={classes.table} aria-label="simple table">
            <TableHead>
              <TableRow>
                <TableCell>Transaction Date</TableCell>
                <TableCell>Yoyo Point</TableCell>
                <TableCell>Type</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {transactionHistory.map((tH, index) => (
                <TableRow key={`itemsRow${index}`}>
                  <TableCell>{unitTimeToDate(tH.createdAt)}</TableCell>
                  <TableCell>{tH.amount}</TableCell>
                  <TableCell>{tH.transactionType}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        ''
      )}
    </>
  );
};

export default TransactionHistory;
