import React from 'react';
import { makeStyles } from '@material-ui/core/styles';

import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';
const useStyles = makeStyles({
  listCls: {
    padding: 0,
  },
  listTitleCls: {
    margin: 0,
  },
});

const UserProfile = props => {
  const classes = useStyles();
  const userData = props.userData;
  return (
    <>
      {userData ? (
        <List>
          <ListItem className={classes.listCls}>
            <ListItemText
              className={classes.listTitleCls}
              primary={`Name - ${userData.firstName} ${userData.lastName}`}
            />
          </ListItem>
          <ListItem className={classes.listCls}>
            <ListItemText
              className={classes.listTitleCls}
              primary={`Email Id - ${userData.emailId}`}
            />
          </ListItem>
          {userData && userData.address ? (
            <>
              <ListItem className={classes.listCls}>
                <ListItemText
                  className={classes.listTitleCls}
                  primary={`Address 1 - ${userData.address.address1}`}
                />
              </ListItem>
              <ListItem className={classes.listCls}>
                <ListItemText
                  className={classes.listTitleCls}
                  primary={`Address 2 - ${userData.address.address2}`}
                />
              </ListItem>
              <ListItem className={classes.listCls}>
                <ListItemText
                  className={classes.listTitleCls}
                  primary={`City - ${userData.address.city}`}
                />
              </ListItem>
              <ListItem className={classes.listCls}>
                <ListItemText
                  className={classes.listTitleCls}
                  primary={`State - ${userData.address.state}`}
                />
              </ListItem>
              <ListItem className={classes.listCls}>
                <ListItemText
                  className={classes.listTitleCls}
                  primary={`Zip - ${userData.address.zip}`}
                />
              </ListItem>
            </>
          ) : (
            ''
          )}
        </List>
      ) : (
        ''
      )}
    </>
  );
};

export default UserProfile;
