import { Component, OnInit } from '@angular/core';
import { AgencyService } from '../../service/agency.service';
import { LoaderService } from '../../../loader/loader.service';

@Component({
  selector: 'app-agency-home',
  templateUrl: './agency-home.component.html',
  styleUrls: ['./agency-home.component.scss']
})
export class AgencyHomeComponent implements OnInit {
  public requests: any;
  public hasRequest: any;

  constructor(private agencyService: AgencyService,
              private loaderService: LoaderService) { }

  ngOnInit() {
    this.hasRequest = false;
    this.loaderService.show();
    this.agencyService.getRequests().subscribe(res => {
      this.requests = (res.data && res.data.length > 0) ? res.data : null;
      this.hasRequest = true;
      this.loaderService.hide();
    });
  }

}
