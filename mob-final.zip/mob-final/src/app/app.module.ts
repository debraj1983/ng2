import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';

import { SharedModule } from './shared/shared.module';
import { StorageServiceModule } from 'ngx-webstorage-service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { SERVICES } from './services/index';
import { METERIAL } from './meterial-modules';
import { LogoutComponent } from './logout/logout.component';
import { LoaderComponent } from './loader/loader.component';

@NgModule({
  declarations: [
    AppComponent,
    LogoutComponent,
    LoaderComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    SharedModule,
    StorageServiceModule,
    ...METERIAL
  ],
  providers: [...SERVICES],
  bootstrap: [AppComponent]
})
export class AppModule { }
