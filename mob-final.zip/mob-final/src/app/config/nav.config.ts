export const SIDENAV = {
    BANK: [{
        label: 'Dashboard',
        url: '/bank/dashboard',
        icon: 'fas fa-fw fa-tachometer-alt',
        active: true
    }, {
        label: 'Settings',
        url: '/bank/settings',
        icon: 'fas fa-cog',
        active: true
    }, {
        label: 'Request',
        url: '/bank/request',
        icon: 'fas fa-file-signature',
        active: false
    }, {
        label: 'Profile',
        url: '/bank/under-construction',
        icon: 'fas fa-user-alt',
        active: true
    }, {
        label: 'Offers',
        url: '/bank/under-construction',
        icon: 'fas fa-hand-holding-usd',
        active: true
    }, {
        label: 'Help',
        url: '/bank/under-construction',
        icon: 'fas fa-question-circle',
        active: true
    }, {
      label: 'Customer Care',
      url: '/bank/under-construction',
      icon: 'fas fas fa-phone-alt',
      active: true
  }, {
        label: 'Logout',
        url: '/logout',
        icon: 'fas fa-sign-out-alt',
        active: true
    }],
    AGENCY: [{
            label: 'Dashboard',
            url: '/agency/dashboard',
            icon: 'fas fa-fw fa-tachometer-alt',
            active: true
        }, {
            label: 'Request',
            url: '/agency/request',
            icon: 'fas fa-file-signature',
            active: false
        }, {
            label: 'Profile',
            url: '/agency/under-construction',
            icon: 'fas fa-user-alt',
            active: true
        }, {
            label: 'Offers',
            url: '/agency/under-construction',
            icon: 'fas fa-hand-holding-usd',
            active: true
        }, {
            label: 'Help',
            url: '/agency/under-construction',
            icon: 'fas fa-question-circle',
            active: true
        }, {
          label: 'Customer Care',
          url: '/agency/under-construction',
          icon: 'fas fas fa-phone-alt',
          active: true
      }, {
            label: 'Logout',
            url: '/logout',
            icon: 'fas fa-sign-out-alt',
            active: true
        }],
    MERCHANT: [{
        label: 'Dashboard',
        url: '/merchant/dashboard',
        icon: 'fas fa-fw fa-tachometer-alt',
        active: true
    }, {
        label: 'Profile',
        url: '/merchant/under-construction',
        icon: 'fas fa-user-alt',
        active: true
    }, {
        label: 'Request',
        url: '/merchant/request',
        icon: 'fas fa-file-signature',
        active: false
    }, {
        label: 'New Request',
        url: '/merchant/upload',
        icon: 'fas fa-file-upload',
        active: false
    }, {
        label: 'Offers',
        url: '/merchant/under-construction',
        icon: 'fas fa-hand-holding-usd',
        active: true
    }, {
        label: 'Help',
        url: '/merchant/under-construction',
        icon: 'fas fa-question-circle',
        active: true
    }, {
      label: 'Customer Care',
      url: '/merchant/under-construction',
      icon: 'fas fas fa-phone-alt',
      active: true
  }, {
        label: 'Logout',
        url: '/logout',
        icon: 'fas fa-sign-out-alt',
        active: true
    }]
};
