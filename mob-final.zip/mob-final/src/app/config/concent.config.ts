export const CONCENT = `<p>We care about your data privacy.
 This platform uses the information that you provide to contact you about relevant content, products, and services.</p>
<p>Our <a href="javascript: void(0);">Privacy Policy</a> and <a href="javascript: void(0);">Terms of Service</a>
will help you understand that you are in control of your data on this platform.</p>`;
