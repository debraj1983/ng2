export const PREFILLED_DATA = {
    LOGIN: {
        MERCHANT: {
            UNIQUE_ID: 'Merchant1',
            PASSWORD: '321'
        },
        AGENCY: {
            UNIQUE_ID: 'VerificationAgency1',
            PASSWORD: '321'
        },
        BANK: {
            UNIQUE_ID: 'AcquiringBank1',
            PASSWORD: '321'
        }
    },
    SIGNUP: {
        MERCHANT: {
            UNIQUE_ID: 'Merchant1',
            PASSWORD: '321',
            NAME: 'Merchant 1',
            DATE: '01.08.2019',
            EMAIL: 'merchant1@email.com',
            CATEGORY: ''
        },
        AGENCY: {
            UNIQUE_ID: 'VerificationAgency1',
            NAME: 'Verification Agency 1',
            DOAMIN: 'verificationAgency1.com',
            EMAIL: 'verificationAgency1@email.com',
            PASSWORD: '321'
        },
        BANK: {
            UNIQUE_ID: 'AcquiringBank1',
            NAME: 'Processor/Acquiring Bank1',
            DOAMIN: 'acquiringBank1.com',
            EMAIL: 'acquiringBank1@email.com',
            PASSWORD: '321'
        }
    }
};