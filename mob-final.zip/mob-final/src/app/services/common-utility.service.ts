import { Injectable } from '@angular/core';
import { AppStorageService } from './app-storage.service';
import { AC } from '../app.constant';

@Injectable({
  providedIn: 'root'
})
export class CommonUtilityService {

  constructor(private appStorageService: AppStorageService) { }

  public inArray(arr: any, elem: any): boolean {
    let isExists = false;
    if (arr && arr.length > 0) {
      for (const a of arr) {
        if (a === elem) {
          isExists = true;
          break;
        }
      }
    }
    return isExists;
  }

  public removeEmementFromArray(arr: any, elem: any): any {
    if (this.inArray(arr, elem)) {
      const newArray = [];
      for (const a of arr) {
        if (a !== elem) {
          newArray.push(a);
        }
      }
      return newArray;
    }
    return arr;
  }

  public removeSpaceFromString(str: string): string {
    return str.replace(/\s/g, '');
  }

  public getLocalDocKey(bankId?: string, merchantId?: string): string {
    const ld = this.appStorageService.getData(AC.STORAGE_KEYS.USER_DETAILS);
    merchantId = (!merchantId) ? ld._id : merchantId;
    bankId = (!bankId) ? ld.uniqueId : bankId;
    return bankId + '_' + merchantId;
  }

  public getCatNamesFromSettings(): any {
    const settings = this.appStorageService.getData(AC.STORAGE_KEYS.SAVED_SETTINGS, 'local');
    const allCat = AC.SIGNUP_CATEGORY;

    const catPos = [];
    if (settings && settings.length > 0) {
      for (const s of settings) {
        const subS = s.split('_');
        if (catPos.length === 0) {
          catPos.push(subS[0]);
        } else {
          if (!this.inArray(catPos, subS[0])) {
            catPos.push(subS[0]);
          }
        }
      }
    }


    const configuredCat = [];
    const pendingConfiguredCat = [];
    let pos = 0;
    for (const p of allCat) {
      if (this.inArray(catPos, pos.toString())) {
        configuredCat.push(p);
      } else {
        pendingConfiguredCat.push(p);
      }
      pos++;
    }
    return {
      configured_cat: configuredCat,
      pending_configuredCat: pendingConfiguredCat
    };
  }

  public getCatName(catObj: any): any {
    const cat = [];
    if (catObj && catObj.length > 0) {
      for (const c of catObj) {
        cat.push('<i class="fas fa-angle-double-right"></i>&nbsp;' + c.catLabel);
      }
    }
    return cat;
  }
}
