import { AppStorageService } from './app-storage.service';
import { GuardService } from './guard.service';
import { LoginService } from './login.service';
import { AuthService } from './auth.service';
import { CommonUtilityService } from './common-utility.service';
import { LoaderService } from '../loader/loader.service';
import { FileService } from './file.service';

export const SERVICES = [
    AppStorageService,
    GuardService,
    LoginService,
    AuthService,
    CommonUtilityService,
    LoaderService,
    FileService
];