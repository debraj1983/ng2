import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppStorageService } from '../../services/app-storage.service';

export const endPoints = {
  bankRequest: environment.apiUrls.bankRequest,
  bankGetHistory: environment.apiUrls.bankGetHistory,
  bankSetrules: environment.apiUrls.bankSetrules,
  bankUpdatestatus: environment.apiUrls.bankUpdatestatus
};

@Injectable({
  providedIn: 'root'
})
export class BankService {

  constructor(private http: HttpClient,
    private appStorageService: AppStorageService) {}


  public getBankRequest(): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.http.get(endPoints.bankRequest, httpOptions);
  }

  public postSetRules(payload: any): Observable<any> {
    console.log(payload);
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.bankSetrules, payload, httpOptions);
  }

  public postBankGetHistory(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.bankGetHistory, payload, httpOptions);
  }

  public postUpdatestatus(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.bankUpdatestatus, payload, httpOptions);
  }


  private getHttpOption(): any {
    return {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + this.appStorageService.getData('token')
      })
    };
  }

  private callLoginService(url: string, payload: any, httpOptions: any): Observable<any> {
    if (environment.production) {
      return this.http.post(url, payload, httpOptions);
    } else {
      return this.http.get(url);
    }
  }
}
