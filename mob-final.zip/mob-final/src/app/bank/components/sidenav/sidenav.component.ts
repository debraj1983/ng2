import { Component, OnInit } from '@angular/core';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-bank-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  public option: any;
  public menu: any

  constructor() { }

  ngOnInit() {
    this.option = {
      cssClass: 'sidebar-bank'
    };
    this.menu = AC.SIDENAV.BANK;
  }

}
