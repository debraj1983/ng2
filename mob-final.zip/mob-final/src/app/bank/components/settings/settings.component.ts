import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AC } from '../../../app.constant';
import { CommonUtilityService } from '../../../services/common-utility.service';
import { BankService } from '../../service/bank.service';
import { AppStorageService } from '../../../services/app-storage.service';
import { LoaderService } from '../../../loader/loader.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  public merchantCategory: any = AC.SIGNUP_CATEGORY;
  public documentType: any = AC.DOCUMENT_TYPE;
  public docUnderCat: any = [];
  public subPayload: any = [];
  public isDisplaySuccessMessgae: boolean;
  public message: string;

  constructor(private commonUtilityService: CommonUtilityService,
              private bankService: BankService,
              private appStorageService: AppStorageService,
              private loaderService: LoaderService,
              private router: Router) { }

  ngOnInit() {
    this.isDisplaySuccessMessgae = false;
    this.message = 'You have successfully configured the merchant category';
    this.defaultChecked();
  }


  public bankSettings(): void {
    console.log();
  }


  public submitForm(): void {
    this.docUnderCat.sort();
    for (const dUC of this.docUnderCat) {
      const eA = dUC.split('_');
      const catName = this.merchantCategory[eA[0]].catName;
      // let docName = this.documentType[eA[1]];
      const docName = this.merchantCategory[eA[0]].docOption[eA[1]];
      if (this.subPayload.length === 0) {
        const obj = {
          name: catName,
          docList: [docName]
        };
        this.subPayload.push(obj);
      } else {
        let hasCat = false;
        for (const sp of this.subPayload) {
          if (sp.name === catName) {
            if (!this.commonUtilityService.inArray(sp.docList, docName)) {
              sp.docList.push(docName);
            }
            hasCat = true;
          }
        }
        if (!hasCat) {
          const obj = {
            name: catName,
            docList: [docName]
          };
          this.subPayload.push(obj);
        }
      }
    }
    if (this.subPayload.length > 0) {
      const payload = {
        category: this.subPayload
      };
      this.loaderService.show();
      this.bankService.postSetRules(payload).subscribe(res => {
          if (res.status && res.status.statusCode === '200') {
              this.appStorageService.setData(AC.STORAGE_KEYS.CATEGORY_CONFIGURED, '1', 'local');
              this.appStorageService.setData(AC.STORAGE_KEYS.SAVED_SETTINGS, this.docUnderCat, 'local');
              const cC = this.commonUtilityService.getCatNamesFromSettings();
              const conCatName = this.commonUtilityService.getCatName(cC.configured_cat);
              this.loaderService.hide();
              this.isDisplaySuccessMessgae = true;
              this.message = `You have successfully configured the merchant ${(conCatName.length > 1) ? 'categories' : 'category'}:
                              <br /><div style="text-align: left !improtant;">${conCatName.join('<br />')}</div>`;
          }
      });
    }
  }

  public managePos(isChecked, i, j): void {
    const elem = i + '_' + j;
    if (isChecked && !this.commonUtilityService.inArray(this.docUnderCat, elem)) {
      this.docUnderCat.push(elem);
    } else if (!isChecked && this.commonUtilityService.inArray(this.docUnderCat, elem)) {
      this.docUnderCat = this.commonUtilityService.removeEmementFromArray(this.docUnderCat, elem);
    }
  }

  public closeModal(event): void {
    this.router.navigateByUrl('/bank/request');
  }

  private defaultChecked(): void {
    const selectedCat = this.appStorageService.getData(AC.STORAGE_KEYS.SAVED_SETTINGS, 'local');

    if (selectedCat && selectedCat.length > 0) {
      this.docUnderCat = [...selectedCat];
    } else {
      /*if (this.merchantCategory && this.merchantCategory.length > 0) {
        for (let i = 0; i < this.merchantCategory.length; i++) {
          for (let j = 0; j < this.merchantCategory[i].docOption.length; j++) {
            this.docUnderCat.push(i + '_' + j);
          }
        }
      }*/
    }

  }

}
