import { RemoveSpacePipe } from './remove-space.pipe';

describe('RemoveSpacePipe', () => {
  it('create an instance', () => {
    const pipe = new RemoveSpacePipe();
    expect(pipe).toBeTruthy();
  });
});
