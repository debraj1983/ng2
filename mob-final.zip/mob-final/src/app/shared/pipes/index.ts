import { RemoveSpacePipe } from './remove-space.pipe';
import { SafePipe } from './safe.pipe';
import { CheckFromArrayPipe } from './check-from-array.pipe';

export const PIPES = [
    RemoveSpacePipe,
    SafePipe,
    CheckFromArrayPipe
]