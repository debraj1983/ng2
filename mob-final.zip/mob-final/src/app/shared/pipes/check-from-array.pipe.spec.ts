import { CheckFromArrayPipe } from './check-from-array.pipe';

describe('CheckFromArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new CheckFromArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
