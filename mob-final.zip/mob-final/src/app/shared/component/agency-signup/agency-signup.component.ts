import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-agency-signup',
  templateUrl: './agency-signup.component.html',
  styleUrls: ['./agency-signup.component.scss']
})
export class AgencySignupComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public backToLogin: EventEmitter<any> = new EventEmitter();

  @Output()
  public agencySignUpDataObj: EventEmitter<any> = new EventEmitter();

  public agencySignUpForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.agencySignUpForm = this.fb.group({
      uniqueId: [this.options.signUpPrefilled.uniqueId, [Validators.required]],
      name: [this.options.signUpPrefilled.name, Validators.required],
      password: [this.options.signUpPrefilled.password, Validators.required],
      domainName: [this.options.signUpPrefilled.domain, Validators.required],
      email: [this.options.signUpPrefilled.email, Validators.required]
    });
  }

  public agencySignUp(): void {
    const agencySignUpSata: any = {
      uniqueId: this.agencySignUpForm.value.uniqueId,
      fullName: this.agencySignUpForm.value.name,
      password: this.agencySignUpForm.value.password,
      domainName: this.agencySignUpForm.value.domainName,
      emailId: this.agencySignUpForm.value.email,
      role: AC.ROLE.AGENCY
    };
    this.agencySignUpDataObj.emit(agencySignUpSata);
  }

  public backToLoginView(): void {
    this.backToLogin.emit();
  }
}
