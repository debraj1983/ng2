import { Component, OnInit, Input } from '@angular/core';

export interface ModalConfig {
  state: boolean;
  header: boolean;
  footer: boolean;
  size: string;
}

@Component({
  selector: 'app-mob-popup',
  templateUrl: './mob-popup.component.html',
  styleUrls: ['./mob-popup.component.scss']
})
export class MobPopupComponent implements OnInit {

  @Input()
  public modalConfig: ModalConfig;

  @Input()
  public header: string;

  constructor() { }

  ngOnInit() {

  }

}
