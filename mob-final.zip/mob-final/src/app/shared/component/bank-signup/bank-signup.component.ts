import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-bank-signup',
  templateUrl: './bank-signup.component.html',
  styleUrls: ['./bank-signup.component.scss']
})
export class BankSignupComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public backToLogin: EventEmitter<any> = new EventEmitter();

  @Output()
  public bankSignUpDataObj: EventEmitter<any> = new EventEmitter();

  public bankSignUpForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.bankSignUpForm = this.fb.group({
      uniqueId: [this.options.signUpPrefilled.uniqueId, [Validators.required]],
      name: [this.options.signUpPrefilled.name, Validators.required],
      password: [this.options.signUpPrefilled.password, Validators.required],
      domainName: [this.options.signUpPrefilled.domain, Validators.required],
      email: [this.options.signUpPrefilled.email, Validators.required]
    });
  }

  public bankSignUp(): void {
    const bankSignUpSata: any = {
      uniqueId: this.bankSignUpForm.value.uniqueId,
      fullName: this.bankSignUpForm.value.name,
      password: this.bankSignUpForm.value.password,
      domainName: this.bankSignUpForm.value.domainName,
      emailId: this.bankSignUpForm.value.email,
      role: AC.ROLE.BANK
    };
    this.bankSignUpDataObj.emit(bankSignUpSata);
  }

  public backToLoginView(): void {
    this.backToLogin.emit();
  }

}
