import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { LoginService } from '../services/login.service';
import { AppStorageService } from '../../services/app-storage.service';
import { AuthService } from '../../services/auth.service';
import { LoaderService } from '../../loader/loader.service';
import { Router } from '@angular/router';
import { AC } from '../../app.constant';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public bankLoginOption: any;
  public agencyLoginOption: any;
  public merchantLoginOption: any;

  public isBankSignUp: boolean;
  public isAgencySignUp: boolean;
  public isMerchantSignUp: boolean;

  public message: string;
  public showModal: boolean;

  @ViewChild('bankLoginModalID', {static: false}) bankLoginModalID: ElementRef;
  @ViewChild('agencyLoginModalID', {static: false}) agencyLoginModalID: ElementRef;
  @ViewChild('merchantLoginModalID', {static: false}) merchantLoginModalID: ElementRef;


  constructor(private loginService: LoginService,
              private route: Router,
              private appStorageService: AppStorageService,
              private authService: AuthService,
              private loaderService: LoaderService) { }

  public ngOnInit() {
    this.initiateSignUp();
    this.bankLoginOption = {
      loginFor: 'bank',
      btnClass: 'bank-login-btn',
      linkClass: 'bank-sign-up',
      prefilled: {
        uniqueId: AC.PREFILLED_DATA.LOGIN.BANK.UNIQUE_ID,
        password: AC.PREFILLED_DATA.LOGIN.BANK.PASSWORD
      },
      signUpPrefilled: {
        uniqueId: AC.PREFILLED_DATA.SIGNUP.BANK.UNIQUE_ID,
        password: AC.PREFILLED_DATA.SIGNUP.BANK.PASSWORD,
        name: AC.PREFILLED_DATA.SIGNUP.BANK.NAME,
        domain: AC.PREFILLED_DATA.SIGNUP.BANK.DOAMIN,
        email: AC.PREFILLED_DATA.SIGNUP.BANK.EMAIL
      }
    };
    this.agencyLoginOption = {
      loginFor: 'agency',
      btnClass: 'agency-login-btn',
      linkClass: 'agency-sign-up',
      prefilled: {
        uniqueId: AC.PREFILLED_DATA.LOGIN.AGENCY.UNIQUE_ID,
        password: AC.PREFILLED_DATA.LOGIN.AGENCY.PASSWORD
      },
      signUpPrefilled: {
        uniqueId: AC.PREFILLED_DATA.SIGNUP.AGENCY.UNIQUE_ID,
        password: AC.PREFILLED_DATA.SIGNUP.AGENCY.PASSWORD,
        name: AC.PREFILLED_DATA.SIGNUP.AGENCY.NAME,
        domain: AC.PREFILLED_DATA.SIGNUP.AGENCY.DOAMIN,
        email: AC.PREFILLED_DATA.SIGNUP.AGENCY.EMAIL,
      }
    };
    this.merchantLoginOption = {
      loginFor: 'merchant',
      btnClass: 'merchant-login-btn',
      linkClass: 'merchant-sign-up',
      prefilled: {
        uniqueId: AC.PREFILLED_DATA.LOGIN.MERCHANT.UNIQUE_ID,
        password: AC.PREFILLED_DATA.LOGIN.MERCHANT.PASSWORD
      },
      signUpPrefilled: {
        uniqueId: AC.PREFILLED_DATA.SIGNUP.MERCHANT.UNIQUE_ID,
        password: AC.PREFILLED_DATA.SIGNUP.MERCHANT.PASSWORD,
        name: AC.PREFILLED_DATA.SIGNUP.MERCHANT.NAME,
        date: AC.PREFILLED_DATA.SIGNUP.MERCHANT.DATE,
        email: AC.PREFILLED_DATA.SIGNUP.MERCHANT.EMAIL,
        category: AC.PREFILLED_DATA.SIGNUP.MERCHANT.CATEGORY
      }
    };
  }

  public getLoginInfo(event): void {
    this.loaderService.show();
    this.loginService.decideAndCallLoginService(event.LoginFor, event.Username, event.Password).subscribe(res => {
      if (res && res.status && res.status.statusCode === '200') {
        if (res.data && res.data.token) {
          this.appStorageService.setData('token', res.data.token);
          this.appStorageService.setData('details', res.data.detail);
          this.loaderService.hide();
          this.navigateToPage(event.LoginFor);
          this.authService.checkLoggedIN();
        }
      } else if (res && res.status && res.status.code === '401') {
        this.loaderService.hide();
        this.showModal = true;
        this.message = res.status.message;
      }
    }, error => {
      this.errorWithModal();
    });


  }


  public setSignUpInfo(loginFor: string): void {
    this.initiateSignUp();
    switch (loginFor) {
      case 'bank':
          this.isBankSignUp = true;
          break;
      case 'agency':
          this.isAgencySignUp = true;
          break;
      case 'merchant':
          this.isMerchantSignUp = true;
          break;
    }
  }

  public backToLoginView(): void {
    this.initiateSignUp();
  }

  public doBankSignUp(payload: any): void {
    this.loaderService.show();
    this.loginService.doSignUp(payload).subscribe( data => {
      this.handleSignup(data);
    }, error => {
      this.errorWithModal();
    });
  }

  public doAgencySignUp(payload: any): void {
    this.loaderService.show();
    this.loginService.doSignUp(payload).subscribe( data => {
      this.handleSignup(data);
    }, error => {
      this.errorWithModal();
    });
  }

  public doMerchantSignUp(payload: any): void {
    this.loaderService.show();
    this.loginService.doSignUp(payload).subscribe( data => {
      this.handleSignup(data);
    }, error => {
      this.errorWithModal();
    });
  }

  public handleSignup(res: any): void {
    this.loaderService.hide();
    if (res && res.status && res.status.statusCode === '200') {
      this.initiateSignUp();
    } else if (res && res.status && res.status.code === '401') {
      this.showModal = true;
      this.message = res.status.message;
    }
  }


  public closeModal(event): void {
    this.showModal = false;
  }

  public showModalOptions(event): void {
    this.showModal = event.showModal;
    this.message = event.message;
  }


  private initiateSignUp(): void {
    this.isBankSignUp = false;
    this.isAgencySignUp = false;
    this.isMerchantSignUp = false;
    this.showModal = false;
  }

  private navigateToPage(to: any): void {
    switch (to) {
      case 'bank':
        this.appStorageService.setData(AC.STORAGE_KEYS.BANK_LOGGED_IN, 1);
        this.bankLoginModalID.nativeElement.click();
        this.route.navigateByUrl('/bank/dashboard');
        break;
    case 'agency':
        this.appStorageService.setData(AC.STORAGE_KEYS.AGENCY_LOGGED_IN, 1);
        this.agencyLoginModalID.nativeElement.click();
        this.route.navigateByUrl('/agency/dashboard');
        break;
    case 'merchant':
        this.appStorageService.setData(AC.STORAGE_KEYS.MERCHANT_LOGGED_IN, 1);
        this.merchantLoginModalID.nativeElement.click();
        this.route.navigateByUrl('/merchant/dashboard');
        break;
    }
  }

  private errorWithModal(): void {
    this.loaderService.hide();
      this.showModal = true;
      this.message = 'We are facing some technical issue. Please try again later..';
  }

}
