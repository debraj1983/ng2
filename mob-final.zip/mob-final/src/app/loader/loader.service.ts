import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class LoaderService {

  public isShowLoader: boolean;

  public showLoaderEmitter: Observable<boolean>; 
  private _showLoader: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);

  constructor() { 
    this.showLoaderEmitter = this._showLoader.asObservable(); 
  }

  public show(): void {
    this._showLoader.next(true);
  }

  public hide(): void {
    this._showLoader.next(false);
  }


}
