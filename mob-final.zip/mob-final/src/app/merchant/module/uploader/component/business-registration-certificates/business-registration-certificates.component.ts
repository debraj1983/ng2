import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FileService } from '../../../../../services/file.service';

@Component({
  selector: 'app-business-registration-certificates',
  templateUrl: './business-registration-certificates.component.html',
  styleUrls: ['./business-registration-certificates.component.scss']
})
export class BusinessRegistrationCertificatesComponent implements OnInit {

  public isDocumentSelected: boolean;
  public isPreview: boolean;
  public content: string;
  public fileData: any;

  @Output()
  public uploadedFileOption: EventEmitter<any> = new EventEmitter();

  @Output()
  public prevStep: EventEmitter<any> = new EventEmitter();

  @Input()
  public fileFor: string;

  constructor(private fileService: FileService) { }

  ngOnInit() {
  }

  public uploadAndContinue(): void {
    const fileObj = {
      fileName: this.fileData.name,
      fileType: this.fileData.type,
      fileFor: this.fileFor,
      content: this.content
    };
    // Pushing file related data in a global object
    this.fileService.pushStepsWiseRecords({
      fileFor: this.fileFor,
      fileData: this.fileData,
      content: this.content
    });
    this.uploadedFileOption.emit(fileObj);
  }

  public uploadedFileContent(event: any): void {
    this.fileData = event.fileData;
    this.content = event.fileContent;
    if (this.fileData) {
      this.isDocumentSelected = true;
    } else {
      this.isDocumentSelected = false;
    }
  }

  public previousStep(): void {
    this.prevStep.emit();
  }

}
