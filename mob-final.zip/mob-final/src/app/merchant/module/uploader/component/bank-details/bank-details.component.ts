import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FileService } from '../../../../../services/file.service';
import { AC } from '../../../../../app.constant';

@Component({
  selector: 'app-bank-details',
  templateUrl: './bank-details.component.html',
  styleUrls: ['./bank-details.component.scss']
})
export class BankDetailsComponent implements OnInit {

  public isDocumentSelected: boolean;
  public isConcentModal: boolean;
  public isConcentAccepted: boolean;
  public isConcentRejected: boolean;
  public content: string;
  public fileData: any;
  public concentContent: string;
  public isSelectedApproverBank: boolean;

  @Output()
  public uploadedFileOption: EventEmitter<any> = new EventEmitter();

  @Output()
  public prevStep: EventEmitter<any> = new EventEmitter();

  @Input()
  public fileFor: string;

  constructor(private fileService: FileService) { }

  ngOnInit() {

  }

 public provideConcent(): void {
    this.concentContent = AC.CONCENT;
    this.isConcentModal = true;
  }

  public acceptConcent(isAccept): void {
    this.isConcentAccepted = isAccept;
    this.isConcentRejected = false;
    this.closeModal(false);
  }

  public rejectConsent(isReject): void {
    this.isConcentRejected = isReject;
    this.closeModal(false);
  }


  public closeModal(isClose: boolean): void {
    this.isConcentModal = isClose;
  }

  public uploadAndContinue(): void {
    const fileObj = {
      fileName: this.fileData.name,
      fileType: this.fileData.type,
      fileFor: this.fileFor,
      content: this.content
    };
    // Pushing file related data in a global object
    this.fileService.pushStepsWiseRecords({
      fileFor: this.fileFor,
      fileData: this.fileData,
      content: this.content
    });
    this.uploadedFileOption.emit(fileObj);
  }

  public selectedBank(v: any): void {
    if (v !== '') {
      this.isSelectedApproverBank = true;
    } else {
      this.isSelectedApproverBank = false;
    }
  }

  public uploadedFileContent(event: any): void {
    this.fileData = event.fileData;
    this.content = event.fileContent;
    if (this.fileData) {
      this.isDocumentSelected = true;
    } else {
      this.isDocumentSelected = false;
    }
  }

  public previousStep(): void {
    this.prevStep.emit();
  }
}
