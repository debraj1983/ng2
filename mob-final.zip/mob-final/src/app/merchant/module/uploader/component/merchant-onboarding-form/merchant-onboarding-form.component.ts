import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FileService } from '../../../../../services/file.service';

@Component({
  selector: 'app-merchant-onboarding-form',
  templateUrl: './merchant-onboarding-form.component.html',
  styleUrls: ['./merchant-onboarding-form.component.scss']
})
export class MerchantOnboardingFormComponent implements OnInit {
  public isDocumentSelected: boolean;

  public isPreview: boolean;

  public isDownloadablePdf: boolean;
  public isOnlineFormPdf: boolean;

  public content: string;
  public downloadableFilePath = './assets/DownloadForm.pdf';

  public fileData: any;

  @Output()
  public uploadedFileOption: EventEmitter<any> = new EventEmitter();

  @Output()
  public prevStep: EventEmitter<any> = new EventEmitter();

  @Input()
  public fileFor: string;


  constructor(private fileService: FileService) { }

  ngOnInit() {
  }

  public closeModal(isClose: boolean): void {
    this.isDownloadablePdf = isClose;
    this.isOnlineFormPdf = isClose;
  }

  public uploadAndContinue(): void {
    const fileObj = {
      fileName: this.fileData.name,
      fileType: this.fileData.type,
      fileFor: this.fileFor,
      content: this.content
    };

    // Pushing file related data in a global object
    this.fileService.pushStepsWiseRecords({
      fileFor: this.fileFor,
      fileData: this.fileData,
      content: this.content
    });
    this.uploadedFileOption.emit(fileObj);
  }

  public downloadAndPrint(): void {
    this.isDownloadablePdf = true;
  }

  public openOnlineForm(): void {
    this.isOnlineFormPdf = true;
  }

  public uploadedFileContent(event: any): void {
    this.fileData = event.fileData;
    this.content = event.fileContent;
    if (this.fileData) {
      this.isDocumentSelected = true;
    } else {
      this.isDocumentSelected = false;
    }
  }

  public previousStep(): void {
    this.prevStep.emit();
  }
}
