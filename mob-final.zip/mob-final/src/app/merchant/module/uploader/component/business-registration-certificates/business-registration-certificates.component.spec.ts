import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessRegistrationCertificatesComponent } from './business-registration-certificates.component';

describe('BusinessRegistrationCertificatesComponent', () => {
  let component: BusinessRegistrationCertificatesComponent;
  let fixture: ComponentFixture<BusinessRegistrationCertificatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessRegistrationCertificatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessRegistrationCertificatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
