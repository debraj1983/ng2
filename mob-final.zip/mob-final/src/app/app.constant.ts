import { SIDENAV } from './config/nav.config';
import { CONCENT } from './config/concent.config';
import { PREFILLED_DATA } from './config/prefilled.data';
import { STATIC_TEXT } from './config/static.text';
import { TXN_ID } from './config/txnid.config';

export const AC = {
    ROLE: {
        BANK: 'Bank',
        AGENCY: 'NOCA',
        MERCHANT: 'Merchant'
    },
    CATEGORY: [{ // Merchant type
        catName: 'MCC1',
        catLabel: 'Passenger Railways',
    }, {
        catName: 'MCC2',
        catLabel: 'Ambulance Services',
    }/*, {
        catName: 'MCC3',
        catLabel: 'Taxicabs and Limousine',
    }*/],
    SETTINGS_CATEGORY: [{ // Merchant type
        catName: '5200',
        catLabel: 'Merchant Category 1',
    }, {
        catName: 'MCC2',
        catLabel: 'Ambulance Services',
    }/*, {
        catName: 'MCC3',
        catLabel: 'Taxicabs and Limousine',
    }*/],
    SIGNUP_CATEGORY: [{
        catName: 'MCC1',
        catLabel: 'Department Stores',
        catCode: '5311',
        docOption: [
            'Business Registration Certificate',
            'Merchant On-boarding Form',
            'Bank details'
        ]}, {
        catName: 'MCC2',
        catLabel: 'Home Supply Warehouse Stores',
        catCode: '5200',
        docOption: [
            'Certificate of Incorporation',
            'Share Certificare',
            'IRS Form',
            'Operating Agreement'
        ]}, {
        catName: 'MCC3',
        catLabel: 'Miscellaneous General Merchandise Stores',
        catCode: '5399',
        docOption: [
            'Lorem Ipsum is simply dummy text op 1',
            'Lorem Ipsum is simply dummy text op 2',
            'Lorem Ipsum is simply dummy text op 3'
        ]}, {
        catName: 'MCC4',
        catLabel: 'Grocery Stores, Supermarkets',
        catCode: '5411',
        docOption: [
            'Lorem Ipsum is simply dummy text op 1',
            'Lorem Ipsum is simply dummy text op 2',
            'Lorem Ipsum is simply dummy text op 3'
        ]
    }],
    DOCUMENT_TYPE: [
        'Business Registration Certificate',
        'Merchant On-boarding Form',
        'Bank Details Documents'
    ],
    DOCUMENT_NEED_TO_PUSH_LOCAL: [
        'Merchant On-boarding Form',
        'Bank Details Documents'
    ],
    DOCUMENT_NEED_TO_SEND_TO_SERVICE: [
        'Business Registration Certificate'
    ],
    DEFAULT_APPROVED: 'Bank Details Documents',
    DOCUMENT_CAN_ACCEPT_BY_BANK: 'Merchant On-boarding Form',
    DOC_STATUS: {
        PENDING: 'PENDING',
        ACCEPTED: 'APPROVED',
        REJECTED: 'REJECTED'
    },
    DOC_STATUS_LABEL: {
        PENDING: 'Pending',
        APPROVED: 'Verified',
        REJECTED: 'Rejected'
    },
    DOC_STATUS_LABEL_MERCHANT: {
        PENDING: 'In Progress',
        APPROVED: 'Completed',
        REJECTED: 'Rejected',
        PFB: 'Pending from Processor / Acquiring Bank 1'
    },
    DOC_STATUS_LABEL_AGENCY: {
        PENDING: 'Verification Pending',
        APPROVED: 'Verified',
        REJECTED: 'Rejected'
    },
    DOC_STATUS_ICON: {
        PENDING: 'fa-clock',
        PFB: 'fa-clock',
        APPROVED: 'fa-check-circle',
        REJECTED: 'fa-times-circle'
    },
    STORAGE_KEYS: {
        UPLOADED_DOCUMENTS: 'uploadedDocuments',
        BANK_LOGGED_IN: 'bankLoggedIn',
        AGENCY_LOGGED_IN: 'agencyLoggedIn',
        MERCHANT_LOGGED_IN: 'merchantLoggedIn',
        CATEGORY_CONFIGURED: 'merchantCategoryConfigured',
        SAVED_SETTINGS: 'savedSettings',
        USER_DETAILS: 'details'
    },
    PREFILLED_DATA: PREFILLED_DATA,
    SIDENAV: SIDENAV,
    CONCENT: CONCENT,
    STATIC_TEXT: STATIC_TEXT,
    TXN_ID: TXN_ID,
    DOCUMENT_UPLOAD_STEPS: [{
        'stepName': 'Select bank to start',
        'isActive': true
    }, {
        'stepName': 'Upload Documents',
        'isActive': false
    }, {
        'stepName': 'Finish Journey',
        'isActive': false
    }],
    BANKNAME: {
        'AcquirerBank1': 'Processor/Acquiring Bank1'
    }
};





// Merchant or organization registered successfully!!

//Request submitted successfully!!

/*
Home Supply Warehouse Stores
Department Stores
Miscellaneous General Merchandise Stores
Grocery Stores, Supermarkets

Certificate of Incorporation
Share Certificare
IRS Form
Operating Agreement
*/
