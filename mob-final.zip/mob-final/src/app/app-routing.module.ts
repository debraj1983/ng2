import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { GuardService } from './services/guard.service';
import { LogoutComponent } from './logout/logout.component';

const routes: Routes = [
  {
    path: '',
    loadChildren: './auth/auth.module#AuthModule'
  }, {
    path: 'auth',
    loadChildren: './auth/auth.module#AuthModule'
  }, {
    path: 'bank',
    loadChildren: './bank/bank.module#BankModule',
    canLoad: [GuardService]
   }, {
    path: 'agency',
    loadChildren: './agency/agency.module#AgencyModule',
    canLoad: [GuardService]
   }, {
    path: 'merchant',
    loadChildren: './merchant/merchant.module#MerchantModule',
    canLoad: [GuardService]
   }, {
     path: 'logout',
     component: LogoutComponent
   }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
