
const protocal = 'http://';
const ip = '104.211.89.242';
const port = '51099';
const domain = `${protocal}${ip}:${port}/merchant-onboarding-services/apis/`;
const loginApi = `${domain}app/login`;
export const environment = {
  production: true,
  apiUrls: {
    login: {
      bankLogin: loginApi,
      agentLogin: loginApi,
      merchantLogin: loginApi
    },
    signUp: `${domain}app/signup`,
    merchantRequestsList: `${domain}merchant/requests`,
    merchantGetBank: `${domain}merchant/getbanks`,
    merchantGetDocForRequest: `${domain}merchant/getdocforrequest`,
    merchantSubmitRequest: `${domain}merchant/submitrequest`,
    merchantGetHistory: `${domain}merchant/getHistory`,
    bankRequest: `${domain}bank/requests`,
    bankSetrules: `${domain}bank/setrules`,
    bankGetHistory: `${domain}bank/getHistory`,
    bankUpdatestatus: `${domain}bank/updatestatus`,
    agencyRequest: `${domain}noca/requests`,
    agencySubmitAction: `${domain}noca/submitaction`,
    agencyGetHistory: `${domain}noca/getHistory`,
  }
};