import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.LOGIN_SUCCESS:
      return { ...state, loggedInData: action.data };
      break;
    case types.LOGIN_FAILED:
      return { ...state, loggedInData: action.data };
      break;
    default:
      return state;
  }
};
