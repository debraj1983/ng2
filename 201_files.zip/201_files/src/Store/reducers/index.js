import { combineReducers } from "redux";
import loginData from "./reducer";

export default combineReducers({ loginData });
