import React from "react";
import { connect } from "react-redux";

class Users extends React.Component {
  constructor(props) {
    super(props);
    const { userData } = props;
    this.userData = userData;
  }

  isAdmin = () =>
    this.userData.role === "admin" && this.userData.type === "admin";

  isCheckin = () =>
    this.userData.role === "staff" && this.userData.type === "checkin";

  isInflight = () =>
    this.userData.role === "staff" && this.userData.type === "inflight";

  render() {
    return (
      <div>
        {this.isAdmin() ? (
          <div>Admin User</div>
        ) : this.isCheckin() ? (
          <div> Checkin User </div>
        ) : (
          <div> In flight User </div>
        )}
      </div>
    );
  }
}

export default Users;
