import React from "react";
import { connect } from "react-redux";
import { doLoginAction } from "../Store/actions/LoginAction";
import LoginForm from "./LoginForm";

class Login extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      loginId: "",
      password: ""
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleLogin = this.handleLogin.bind(this);
  }

  handleLogin(event) {
    event.preventDefault();
    const payload = this.state;
    this.props.doLoginAction(payload);
  }

  handleChange(event) {
    const { name, value } = event.target;
    if (name === "loginId") {
      this.setState({ loginId: value, password: this.state.password });
    }
    if (name === "password") {
      this.setState({ loginId: this.state.loginId, password: value });
    }
  }

  checkLoginFailed() {
    return (
      this.props.loginData &&
      this.props.loginData.loggedInData &&
      this.props.loginData.loggedInData.loginFailed
    );
  }

  render() {
    console.log(this.props);
    return (
      <div className="container">
        <LoginForm
          doLogin={this.handleLogin}
          changeData={this.handleChange}
          loginFailed={this.checkLoginFailed()}
        />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  doLoginAction: payload => dispatch(doLoginAction(payload))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Login);
