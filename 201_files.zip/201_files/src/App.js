import React from "react";
import "./App.scss";
import utility from "./Utility/StorageUtility";
import { connect } from "react-redux";
import Login from "./Login/Login";
import Users from "./Users/Users";

class App extends React.Component {
  constructor(props) {
    super(props);
  }

  checkLoggedIn = () => {
    if (
      utility.checkLoggedIn() ||
      (this.props.loginData &&
        this.props.loginData.loggedInData &&
        this.props.loginData.loggedInData.loggedIn)
    ) {
      return true;
    }
    return false;
  };

  getLoggedInUserData = () => {
    return (
      utility.getLoggedInUserData() ||
      this.props.loginData.loggedInData.loggedIn
    );
  };

  render() {
    return (
      <div className="App">
        {this.checkLoggedIn() ? (
          <Users userData={this.getLoggedInUserData()} />
        ) : (
          <Login />
        )}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  loginData: state.loginData
});

export default connect(
  mapStateToProps,
  null
)(App);
