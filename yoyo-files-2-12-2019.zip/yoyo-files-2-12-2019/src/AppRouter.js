import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { connect } from 'react-redux';

import { RouteConfig } from './AppConstant';
import Header from './Header';
import storageUtility from './Utility/StorageUtility';
import { loginSuccessAction } from './Store/actions/LoginAction';
import {
  searchTxtAction,
  resetSearchStoreAction,
} from './Store/actions/SearchAction';

class AppRouter extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTxt: '',
    };
    this.changeData = this.changeData.bind(this);
    this.doSearch = this.doSearch.bind(this);
    this.resetSearch = this.resetSearch.bind(this);
  }

  componentDidMount() {
    if (storageUtility.checkLoggedIn()) {
      this.props.setLoginDataToStore(storageUtility.getLoggedInUserData());
    }
  }

  changeData(event) {
    const { value } = event.target;
    this.setState({ searchTxt: value });
  }

  doSearch(event) {
    event.preventDefault();
    const q = this.state.searchTxt;
    this.props.setResetSearchStore(false);
    this.props.setSearchTxtToStore(q);
  }
  resetSearch(event) {
    this.props.setResetSearchStore(true);
    this.setState({ searchTxt: '' });
  }
  render() {
    return (
      <Router>
        <Header
          userData={this.props.loginData}
          changeData={this.changeData}
          doSearch={this.doSearch}
          resetSearch={this.resetSearch}
        ></Header>{' '}
        <div className="gift-body-section">
          <Switch>
            {RouteConfig.map((config, index) => (
              <Route
                path={config.path}
                exact
                component={config.component}
                key={`route${index}`}
              />
            ))}
          </Switch>{' '}
        </div>
      </Router>
    );
  }
}

const mapStateToProps = state => ({
  ...state,
});

const mapDispatchToProps = dispatch => ({
  setLoginDataToStore: data => dispatch(loginSuccessAction(data)),
  setSearchTxtToStore: data => dispatch(searchTxtAction(data)),
  setResetSearchStore: data => dispatch(resetSearchStoreAction(data)),
});

export default connect(mapStateToProps, mapDispatchToProps)(AppRouter);

/*            <div key={index}>
{config.protected ? (
                <ProtectedRouter
                  path={config.path}
                  loggedIn={this.props.loginData}
                  component={config.component}
                  key={`protectedroute${index}`}
                />
              ) : ()}
            </div>*/
