import * as types from '../actionTypes';
import { CommonUtility } from '../../Utility/CommonUtility';

export default (state = {}, action) => {
  switch (action.type) {
    case types.GET_CATEGORIES:
      return { ...state, data: CommonUtility.getFormattedCatObj(action.data) };
    default:
      return state;
  }
};
