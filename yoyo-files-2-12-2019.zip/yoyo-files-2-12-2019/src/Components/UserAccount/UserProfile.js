import React from "react";

const UserProfile = props => {
  const userData = props.userData;
  return (
    <>
      {userData ? (
        <>
          <strong>Name:</strong> {`${userData.firstName} ${userData.lastName}`}
          <br />
          <strong>Email Id:</strong> {userData.emailId}
          {userData && userData.address ? (
            <div>
              <strong>Address 1:</strong> {userData.address.address1}
              <br />
              <strong>Address 2:</strong> {userData.address.address2}
              <br />
              <strong>City:</strong> {userData.address.city}
              <br />
              <strong>State:</strong> {userData.address.state}
              <br />
              <strong>Zip:</strong> {userData.address.zip}
            </div>
          ) : (
            ""
          )}
        </>
      ) : (
        ""
      )}
    </>
  );
};

export default UserProfile;
