import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';

import storageUtility from '../../Utility/StorageUtility';

const useStyles = makeStyles({
  root: {
    width: '90%',
    overflowX: 'hidden',
    margin: '0 auto',
  },
  table: {
    minWidth: 650,
  },
  pageHeding: {
    fontSize: '20px',
  },
  btnCls: {
    backgroundColor: '#0e6470',
  },
});

const CartView = props => {
  const [cartItems, setCartItem] = useState([]);
  useEffect(() => {
    if (props.cartItems && props.cartItems.length > 0) {
      setCartItem(props.cartItems);
    }
  }, [props.cartItems]);

  const getTotalCartValue = () => {
    let total = 0;
    cartItems.forEach(eachElem => {
      total += parseInt(eachElem.yoyoPoint);
    });
    return total;
  };

  const removeItemCart = pos => {
    const items = cartItems.filter((item, index) => index !== pos);
    setCartItem(items);
    storageUtility.setCartData(items);
  };

  const classes = useStyles();

  return (
    <div className={classes.root}>
      <h4 className={classes.pageHeding}>Shopping Cart</h4>
      <Paper>
        <Table className={classes.table} aria-label="simple table">
          <TableHead>
            <TableRow>
              <TableCell>Item ID</TableCell>
              <TableCell>Item Name</TableCell>
              <TableCell>Price</TableCell>
              <TableCell>Yoyo Point</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {cartItems && cartItems.length > 0 ? (
              cartItems.map((item, index) => (
                <TableRow key={`itemsRow${index}`}>
                  <TableCell component="th" scope="row">
                    {item.cardId}
                  </TableCell>
                  <TableCell>{item.name}</TableCell>
                  <TableCell>{item.cardValue}</TableCell>
                  <TableCell>{item.yoyoPoint}</TableCell>
                  <TableCell>
                    <Button
                      variant="contained"
                      color="secondary"
                      onClick={() => removeItemCart(index)}
                      size="small"
                    >
                      X
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <>No item added in cart</>
            )}
          </TableBody>
        </Table>
      </Paper>
      {cartItems && cartItems.length > 0 ? (
        <>
          <Button
            variant="contained"
            color="secondary"
            className={classes.btnCls}
            onClick={() => props.checkAndNavigate()}
          >
            Continue
          </Button>
          &nbsp;&nbsp;
          <Button
            variant="contained"
            color="secondary"
            onClick={() => props.navigateToShopMore()}
          >
            Shop More
          </Button>
          &nbsp;&nbsp;
          <span className="float-right">
            Cart Total: {getTotalCartValue()} Yoyo
          </span>
        </>
      ) : (
        <Button
          variant="contained"
          color="secondary"
          onClick={() => props.navigateToShopMore()}
        >
          Shop More
        </Button>
      )}
    </div>
  );
};

export default CartView;
