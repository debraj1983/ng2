import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardHeader from '@material-ui/core/CardHeader';
import TextField from '@material-ui/core/TextField';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles({
  card: {
    maxWidth: 400,
    border: '1px solid #CCC',
    margin: '0 auto',
  },
  title: {
    fontSize: 14,
  },
  invalid: {
    color: '#F00',
  },
  btnCls: {
    backgroundColor: '#0e6470',
  },
});

const LoginForm = props => {
  const classes = useStyles();
  return (
    <>
      <Card className={classes.card}>
        <CardHeader title="Login" />
        <CardContent>
          {props.loginFailed ? (
            <Typography color="textSecondary" className={classes.invalid}>
              Invalid Username or Password
            </Typography>
          ) : (
            ''
          )}
          <form onSubmit={props.doLogin}>
            <div>
              <TextField
                id="loginId"
                label="Login ID"
                variant="outlined"
                margin="dense"
                name="loginId"
                onChange={props.changeData}
                type="text"
                fullWidth="true"
              />
            </div>
            <div>
              <TextField
                id="password"
                label="Password"
                variant="outlined"
                margin="dense"
                name="password"
                onChange={props.changeData}
                type="password"
                fullWidth="true"
              />
            </div>
            <Button
              variant="contained"
              color="secondary"
              type="submit"
              className={classes.btnCls}
            >
              Login
            </Button>
          </form>
        </CardContent>
      </Card>
    </>
  );
};

export default LoginForm;
