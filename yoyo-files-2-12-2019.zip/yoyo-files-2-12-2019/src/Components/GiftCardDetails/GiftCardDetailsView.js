import React, { useState, useEffect } from 'react';

import Rating from '@material-ui/lab/Rating';
import Grid from '@material-ui/core/Grid';
import Card from '@material-ui/core/Card';
import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';

import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  cardBlock: {
    padding: '10px',
    paddingLeft: '20px',
  },
  commentsBlock: {
    marginBottom: '10px',
    border: '1px solid #CCC',
  },
  btn: {
    color: '#FFF',
    backgroundColor: '#0e6470',
    textDecoration: 'none',
    display: 'inline-block',
    padding: '6px 16px',
  },
  btnCls: {
    backgroundColor: '#0e6470',
  },
});

const GiftCardDetailsView = props => {
  const classes = useStyles();
  const [giftCard, setGiftCard] = useState({});
  useEffect(() => {
    const card =
      props.gifts &&
      props.gifts.data &&
      props.gifts.data.find(g => g.id.toString() === props.params.id);
    if (card) {
      setGiftCard(card);
    }
  }, [props.gifts, props.params.id]);
  return (
    <Grid container spacing={12}>
      {giftCard ? (
        <Card className={classes.cardBlock}>
          <Box component="fieldset" borderColor="transparent">
            <h3>{giftCard.cardName}</h3>
            {giftCard.cardDescription}
            <br />
            Card Value - Rs {giftCard.cardValue}/-
            <br />
            {giftCard.discount > 0 ? (
              <>
                <p>
                  Yoyo Points -{' '}
                  <span
                    style={{ textDecoration: 'line-through' }}
                    className="text-danger"
                  >
                    {giftCard.actualYoyoPoint}
                  </span>
                  <br />
                  Discount - {giftCard.discount}%
                  <br />
                  Discounted Yoyo Points - {giftCard.yoyoPoint}
                </p>
              </>
            ) : (
              <p>Yoyo Points - {giftCard.yoyoPoint}</p>
            )}
            <br />
            <Typography component="legend">Avg Rating:</Typography>
            <Rating
              name="read-only"
              value={giftCard.avgRating}
              size="small"
              readOnly
            ></Rating>
          </Box>{' '}
          <p>
            {props.itemAddedToCart ? (
              <>
                <Button variant="contained" color="secondary">
                  Added to Cart
                </Button>
                &nbsp;&nbsp;
                <Button
                  variant="contained"
                  color="secondary"
                  onClick={() => props.navigateToCart()}
                >
                  Cart
                </Button>
              </>
            ) : (
              <Button
                variant="contained"
                color="secondary"
                className={classes.btn}
                onClick={() =>
                  props.addToCart({
                    cardId: giftCard.id,
                    name: giftCard.cardName,
                    cardValue: giftCard.cardValue,
                    yoyoPoint: giftCard.yoyoPoint,
                  })
                }
              >
                Add to Cart
              </Button>
            )}
          </p>
          {giftCard.ratingComments && giftCard.ratingComments.length > 0 ? (
            <div>
              <h5>Reviews:</h5>
              {giftCard.ratingComments.map((rC, index) => (
                <Card key={`review_${index}`} className={classes.commentsBlock}>
                  <div className="card-body">
                    Rating: {rC.rating}
                    <br />
                    {rC.comments}
                    <br />
                    Posted By - {rC.postedBy}
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            ''
          )}
        </Card>
      ) : (
        ''
      )}
    </Grid>
  );
};

export default GiftCardDetailsView;
