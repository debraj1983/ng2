import React from 'react';
import { Link } from 'react-router-dom';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles({
  card: {
    minWidth: 200,
    border: '1px solid #CCC',
    margin: '5px',
    height: '100%',
  },
  btn: {
    color: '#FFF',
    backgroundColor: '#0e6470',
    textDecoration: 'none',
    display: 'inline-block',
    padding: '10px',
  },
  actualPrice: {
    color: '#FF0000',
    textDecoration: 'line-through',
  },
  discount: {
    color: '#FF0000',
    fontSize: '16px',
    fontWeight: 'bold',
  },
});
const GiftCard = props => {
  const classes = useStyles();
  return (
    <>
      <Card className={classes.card} key={`giftcard${props.pos}`}>
        <CardContent>
          <Typography variant="h5" color="textSecondary" gutterBottom>
            {props.gift.cardName}
          </Typography>
          <Typography>{props.gift.cardDescription}</Typography>
          <Typography color="textSecondary">
            {props.gift.discount > 0 ? (
              <>
                <p>
                  Yoyo Points -{' '}
                  <span className={classes.actualPrice}>
                    {props.gift.actualYoyoPoint}
                  </span>
                  <br />
                  Discount -{' '}
                  <span className={classes.discount}>
                    {props.gift.discount}%
                  </span>
                  <br />
                  Discounted Yoyo Points - {props.gift.yoyoPoint}
                </p>
              </>
            ) : (
              <p>Yoyo Points - {props.gift.yoyoPoint}</p>
            )}
          </Typography>
        </CardContent>
        <CardActions>
          <Link
            to={`/gift-card-details/${props.gift.id}`}
            className={classes.btn}
          >
            View Details
          </Link>
        </CardActions>
      </Card>
    </>
  );
};

export default GiftCard;
