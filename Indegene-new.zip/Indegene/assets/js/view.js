function View() {
    var dragArea = document.createElement('div');
}