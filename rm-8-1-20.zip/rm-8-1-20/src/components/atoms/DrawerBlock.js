import React from "react";
import Drawer from "@material-ui/core/Drawer";

const HiddenBlock = props => {
  const { children, ...properties } = props;
  return <Drawer {...properties}>{children}</Drawer>;
};

export default HiddenBlock;
