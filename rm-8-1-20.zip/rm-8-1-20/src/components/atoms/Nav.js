import React from "react";

const Nav = props => {
  const { className, children } = props;
  return <nav className={className}>{children}</nav>;
};

export default Nav;
