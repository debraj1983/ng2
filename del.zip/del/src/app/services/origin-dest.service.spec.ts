import { TestBed } from '@angular/core/testing';

import { OriginDestService } from './origin-dest.service';

describe('OriginDestService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: OriginDestService = TestBed.get(OriginDestService);
    expect(service).toBeTruthy();
  });
});
