import { TestBed } from '@angular/core/testing';

import { AppStorageUtilityService } from './app-storage-utility.service';

describe('AppStorageUtilityService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AppStorageUtilityService = TestBed.get(AppStorageUtilityService);
    expect(service).toBeTruthy();
  });
});
