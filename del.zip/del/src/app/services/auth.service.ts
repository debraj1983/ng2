import { Injectable } from '@angular/core';
import { AppStorageUtilityService } from './app-storage-utility.service';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private storageUtility: AppStorageUtilityService) { }

  public checkedLogin() {
    return this.storageUtility.checkUserLoggedIn();
  }

  public doSignUp(payload): Promise<any> {
    return new Promise((resolve, reject) => {
      if (this.storageUtility.doSignUpUtility(payload)) {
        resolve(true);
      } else {
        reject();
      }
    });
  }

  public doSignIn(payload): Promise<any> {
    return new Promise((resolve, reject) => {
      if (this.storageUtility.doSignInUtility(payload)) {
        resolve(true);
      } else {
        reject(false);
      }
    });
  }
}
