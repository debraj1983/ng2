import { TestBed } from '@angular/core/testing';

import { IonicAlertService } from './ionic-alert.service';

describe('IonicAlertService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: IonicAlertService = TestBed.get(IonicAlertService);
    expect(service).toBeTruthy();
  });
});
