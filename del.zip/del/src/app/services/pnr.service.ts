import { Injectable, EventEmitter } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class PnrService {
  public pnrObservable = new EventEmitter();
}
