import { SESSION_STORAGE } from "ngx-webstorage-service";
import { Injectable } from "@angular/core";
import { AppStorageService } from "./app-storage.service";
import { PnrService } from "./pnr.service";
import { STORAGE_CONST } from "../data";
import { Subject } from "rxjs";

export const STORAGE_TYPE = {
  SESSION: "session",
  LOCAL: "local",
};

export const CABIN = {
  main: "Main Cabin",
  comfort: "Comfort Cabin",
  first: "First Cabin",
};

@Injectable({
  providedIn: "root",
})
export class AppStorageUtilityService {
  public pointsInfo = new Subject();

  constructor(
    private appStorageService: AppStorageService,
    private pnrService: PnrService
  ) {}

  public setPointInfo(points) {
    this.pointsInfo.next(points);
  }

  public checkUserLoggedIn(): boolean {
    const loggedIn = this.appStorageService.getData(
      "loggedIn",
      STORAGE_TYPE.LOCAL
    );
    return loggedIn && loggedIn.toString() === "1" ? true : false;
  }

  public doSignUpUtility(payload): any {
    const updatedStorageData = { ...STORAGE_CONST, user: { ...payload } };
    return this.appStorageService.clearAndSetDataInStorage(
      updatedStorageData,
      STORAGE_TYPE.LOCAL
    );
  }

  public doSignInUtility(payload): any {
    const user = this.appStorageService.getData("user", STORAGE_TYPE.LOCAL);
    if (
      user.username === payload.username &&
      user.password === payload.password
    ) {
      this.appStorageService.setData("loggedIn", "1", STORAGE_TYPE.LOCAL);
      return true;
    } else {
      return false;
    }
  }

  public gerUsername(): string {
    const user = this.appStorageService.getData("user", STORAGE_TYPE.LOCAL);
    return user && user.username ? user.username : "";
  }

  public getSkyAndEdgePt(): any {
    const skymilePoints = this.appStorageService.getData(
      "skymilePoints",
      STORAGE_TYPE.LOCAL
    );
    const edgePoints = this.appStorageService.getData(
      "edgePoints",
      STORAGE_TYPE.LOCAL
    );
    const travelHistory = this.appStorageService.getData(
      "travelHistory",
      STORAGE_TYPE.LOCAL
    );
    return { skymilePoints, edgePoints, travelHistory };
  }

  public getSearchResult(): any {
    return this.appStorageService.getData("flights", STORAGE_TYPE.LOCAL);
  }

  public bookFlight(bookingObj): void {
    let b = this.appStorageService.getData(
      "bookingDetails",
      STORAGE_TYPE.LOCAL
    );
    if (!b) {
      b = [];
    }
    b.push(bookingObj);
    this.appStorageService.setData("bookingDetails", b, STORAGE_TYPE.LOCAL);

    // Enter data for pnr
    const pnr = "DL" + new Date().getMilliseconds();
    const pnrObj = {
      pnr: pnr,
      bookingDetails: {
        ...bookingObj,
      },
    };
    const travelHistory = this.appStorageService.getData(
      "travelHistory",
      STORAGE_TYPE.LOCAL
    );
    travelHistory.unshift(pnrObj);
    this.appStorageService.setData(
      "travelHistory",
      travelHistory,
      STORAGE_TYPE.LOCAL
    );
    this.getTravelHistory();
  }

  public updateSkymilePoints(bookingPoints): void {
    let smp = this.appStorageService.getData(
      "skymilePoints",
      STORAGE_TYPE.LOCAL
    );

    smp = parseInt(smp) - parseInt(bookingPoints);
    this.setPointInfo(smp);
    this.appStorageService.setData("skymilePoints", smp, STORAGE_TYPE.LOCAL);
  }

  public toBookFlight(data): void {
    this.appStorageService.setData(
      "toBookFlightObj",
      data,
      STORAGE_TYPE.SESSION
    );
  }
  public getSelectedFlightObj(): any {
    return this.appStorageService.getData(
      "toBookFlightObj",
      STORAGE_TYPE.SESSION
    );
  }

  public setPnrData(pnr): void {
    this.appStorageService.setData(
      "pnrForReBooking",
      pnr,
      STORAGE_TYPE.SESSION
    );
  }

  public getPnrDataForBooking(): any {
    return this.appStorageService.getData(
      "pnrForReBooking",
      STORAGE_TYPE.SESSION
    );
  }

  public getTravelHistory() {
    const travelHistory = this.appStorageService.getData(
      "travelHistory",
      STORAGE_TYPE.LOCAL
    );
    this.pnrService.pnrObservable.emit(travelHistory);
  }
}
