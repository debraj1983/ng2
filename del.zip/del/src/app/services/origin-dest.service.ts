import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root",
})
export class OriginDestService {
  constructor() {}

  public getResults(search?: string): any {
    search = typeof search === "string" ? search : "";
    return PLACES.filter((item) => {
      return item.toLowerCase().indexOf(search.toLowerCase()) !== -1;
    });
  }
}

export const PLACES = [
  "Bangalore -BLR",
  "Kolkata - CCU",
  "Delhi - DEL",
  "Pune - PNQ",
  "Bhubaneswar - BBI",
  "Mumbai - BOM",
  "Hyderabad - HYD",
  "Goa - GOI",
  "Patna - PAT",
  "Pathankot - IXP",
];
