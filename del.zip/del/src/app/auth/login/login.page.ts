import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  public loginForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }


  public userLogin(): void {
    const payload = {
      username: this.loginForm.value.username,
      password: this.loginForm.value.password
    };
    this.authService.doSignIn(payload).then(res => {
      if (res) {
        this.router.navigateByUrl('/user');
      }
    }, error => {
      console.log(error);
    });
  }

}
