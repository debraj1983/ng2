export const STORAGE_CONST = {
  user: { username: "", password: "" },
  loggedIn: "0",
  skymilePoints: 10000,
  edgePoints: 5000,
  flights: [
    {
      flightName: "Flight 1",
      departureTime: "9:00",
      arrivalTime: "11:30",
      travelTime: "2:30 hrs",
      fare: "3500",
      skymilePt: "1750",
      main: {
        fare: 4000,
        point: 2000,
      },
      comfort: {
        fare: 3500,
        point: 1750,
      },
      first: {
        fare: 3000,
        point: 1500,
      },
    },
    {
      flightName: "Flight 2",
      departureTime: "13:00",
      arrivalTime: "15:30",
      travelTime: "2:30 hrs",
      fare: "5000",
      skymilePt: "2500",
      main: {
        fare: 4000,
        point: 2000,
      },
      comfort: {
        fare: 3500,
        point: 1750,
      },
      first: {
        fare: 3000,
        point: 1500,
      },
    },
    {
      flightName: "Flight 3",
      departureTime: "16:00",
      arrivalTime: "18:30",
      travelTime: "2:30 hrs",
      fare: "4500",
      skymilePt: "2250",
      main: {
        fare: 4500,
        point: 2250,
      },
      comfort: {
        fare: 4000,
        point: 2000,
      },
      first: {
        fare: 3500,
        point: 1750,
      },
    },
    {
      flightName: "Flight 4",
      departureTime: "17:00",
      arrivalTime: "19:30",
      travelTime: "2:30 hrs",
      fare: "6500",
      skymilePt: "3250",
      main: {
        fare: 6500,
        point: 3250,
      },
      comfort: {
        fare: 6000,
        point: 3000,
      },
      first: {
        fare: 5500,
        point: 2750,
      },
    },
  ],
  travelHistory: [
    {
      pnr: "DA234",
      travelDate: "09/11/2019",
      bookingDetails: {
        flight: {
          flightName: "Flight 2",
          departureTime: "13:00",
          arrivalTime: "15:30",
          fare: "5000",
          skymilePt: "2500",
        },
        passenger: {
          firstname: "Debraj",
          middlename: "",
          lastname: "Dutta",
          age: "37",
          sex: "Male",
        },
        travelDetails: {
          origin: "Origin 1",
          destination: "Destination 1",
          travelDate: "2020-07-13T10:27:48.635+05:30",
          noOfPassenger: 1,
        },
      },
    },
    {
      pnr: "DA543",
      travelDate: "10/29/2019",
      bookingDetails: {
        flight: {
          flightName: "Flight 2",
          departureTime: "13:00",
          arrivalTime: "15:30",
          fare: "5000",
          skymilePt: "2500",
        },
        passenger: {
          firstname: "Debraj",
          middlename: "",
          lastname: "Dutta",
          age: "37",
          sex: "Male",
        },
        travelDetails: {
          origin: "Origin 1",
          destination: "Destination 1",
          travelDate: "2019-10-29T10:27:48.635+05:30",
          noOfPassenger: 1,
        },
      },
    },
    {
      pnr: "DA268",
      travelDate: "11/23/2019",
      bookingDetails: {
        flight: {
          flightName: "Flight 2",
          departureTime: "13:00",
          arrivalTime: "15:30",
          fare: "5000",
          skymilePt: "2500",
        },
        passenger: {
          firstname: "Debraj",
          middlename: "",
          lastname: "Dutta",
          age: "37",
          sex: "Male",
        },
        travelDetails: {
          origin: "Origin 1",
          destination: "Destination 1",
          travelDate: "2019-11-23T10:27:48.635+05:30",
          noOfPassenger: 1,
        },
      },
    },
    {
      pnr: "DA098",
      travelDate: "12/31/2019",
      bookingDetails: {
        flight: {
          flightName: "Flight 2",
          departureTime: "13:00",
          arrivalTime: "15:30",
          fare: "5000",
          skymilePt: "2500",
        },
        passenger: {
          firstname: "Debraj",
          middlename: "",
          lastname: "Dutta",
          age: "37",
          sex: "Male",
        },
        travelDetails: {
          origin: "Origin 1",
          destination: "Destination 1",
          travelDate: "2019-12-31T10:27:48.635+05:30",
          noOfPassenger: 1,
        },
      },
    },
    {
      pnr: "DA276",
      travelDate: "02/13/2020",
      bookingDetails: {
        flight: {
          flightName: "Flight 2",
          departureTime: "13:00",
          arrivalTime: "15:30",
          fare: "5000",
          skymilePt: "2500",
        },
        passenger: {
          firstname: "Debraj",
          middlename: "",
          lastname: "Dutta",
          age: "37",
          sex: "Male",
        },
        travelDetails: {
          origin: "Origin 1",
          destination: "Destination 1",
          travelDate: "2020-02-13T10:27:48.635+05:30",
          noOfPassenger: 1,
        },
      },
    },
  ],
  bookingDetails: [],
};
