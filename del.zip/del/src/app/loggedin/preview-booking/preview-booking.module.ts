import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { SharedModule } from "../../shared/shared.module";

import { IonicModule } from "@ionic/angular";

import { PreviewBookingPageRoutingModule } from "./preview-booking-routing.module";

import { PreviewBookingPage } from "./preview-booking.page";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    SharedModule,
    PreviewBookingPageRoutingModule,
  ],
  declarations: [PreviewBookingPage],
})
export class PreviewBookingPageModule {}
