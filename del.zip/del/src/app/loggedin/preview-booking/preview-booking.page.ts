import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  AppStorageUtilityService,
  CABIN,
} from "../../services/app-storage-utility.service";
import { IonicAlertService } from "../../services/ionic-alert.service";

@Component({
  selector: "app-preview-booking",
  templateUrl: "./preview-booking.page.html",
  styleUrls: ["./preview-booking.page.scss"],
})
export class PreviewBookingPage implements OnInit {
  public selectedFlight: any;
  public travelDetails: any;
  public cabin: any;
  public displayCabin: any;
  public passenger: any;

  private bookingFrom: any = "";
  constructor(
    private appStorageUtilityService: AppStorageUtilityService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit() {
    this.bookingFrom = this.activatedRoute.snapshot.queryParamMap.get(
      "bookingFrom"
    );
    const toBookingData = this.appStorageUtilityService.getSelectedFlightObj();
    this.selectedFlight = toBookingData.flight;
    this.passenger = toBookingData.passenger;
    this.travelDetails = toBookingData.travelDetails;
    this.cabin = toBookingData.seat;
    this.displayCabin = CABIN[this.cabin];
  }

  confirmBooking() {
    this.router.navigateByUrl(
      `user/payment-option${
        this.bookingFrom === "pnr" ? "?bookingFrom=pnr" : ""
      }`
    );
  }

  /*
  public confirmBooking() {
    const bookingDetails = {
      flight: this.selectedFlight,
      passenger: this.passenger,
      travelDetails: this.travelDetails,
    };
    this.appStorageUtilityService.bookFlight(bookingDetails);
    this.appStorageUtilityService.updateSkymilePoints(
      this.selectedFlight.skymilePt
    );

    this.ionicAlertService.createAlert({
      message: "Your booking is confirmed.",
      buttons: [
        {
          text: "Ok",
          handler: () => {
            this.router.navigateByUrl("/user/mydelta");
          },
        },
      ],
    });
  }*/
}
