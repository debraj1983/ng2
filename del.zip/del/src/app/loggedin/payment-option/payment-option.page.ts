import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  AppStorageUtilityService,
  CABIN,
} from "../../services/app-storage-utility.service";
import { IonicAlertService } from "../../services/ionic-alert.service";

@Component({
  selector: "app-payment-option",
  templateUrl: "./payment-option.page.html",
  styleUrls: ["./payment-option.page.scss"],
})
export class PaymentOptionPage implements OnInit {
  public selectedFlight: any;
  public travelDetails: any;
  public cabin: any;
  public displayCabin: any;
  public passenger: any;
  public skymilePoints: any;
  private bookingFrom: any = "";

  constructor(
    private appStorageUtilityService: AppStorageUtilityService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private ionicAlertService: IonicAlertService
  ) {}

  ngOnInit() {
    this.bookingFrom = this.activatedRoute.snapshot.queryParamMap.get(
      "bookingFrom"
    );
    const toBookingData = this.appStorageUtilityService.getSelectedFlightObj();
    this.selectedFlight = toBookingData.flight;
    this.travelDetails = toBookingData.travelDetails;
    this.cabin = toBookingData.seat;
    this.displayCabin = CABIN[this.cabin];
    this.passenger = toBookingData.passenger;
    const points = this.appStorageUtilityService.getSkyAndEdgePt();
    this.skymilePoints = points.skymilePoints;
  }

  public confirmBooking() {
    const bookingDetails = {
      flight: this.selectedFlight,
      cabin: this.cabin,
      passenger: this.passenger,
      travelDetails: this.travelDetails,
    };
    this.appStorageUtilityService.bookFlight(bookingDetails);

    this.appStorageUtilityService.updateSkymilePoints(
      this.selectedFlight[this.cabin].point
    );

    this.ionicAlertService.createAlert({
      message: "Your booking is confirmed.",
      buttons: [
        {
          text: "Ok",
          handler: () => {
            this.router.navigateByUrl("/user/mydelta");
          },
        },
      ],
    });
  }
}
