import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";

import { AppStorageUtilityService } from "../../services/app-storage-utility.service";
@Component({
  selector: "app-search-result",
  templateUrl: "./search-result.page.html",
  styleUrls: ["./search-result.page.scss"],
})
export class SearchResultPage implements OnInit {
  public searchRes: any;
  public toFlightBook: any;
  public originDest: any;
  public showBlock: any;
  private bookingFrom: any = "";

  constructor(
    private appStorageUtilityService: AppStorageUtilityService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.bookingFrom = this.route.snapshot.queryParamMap.get("bookingFrom");
    this.searchRes = this.appStorageUtilityService.getSearchResult();
    this.toFlightBook = this.appStorageUtilityService.getSelectedFlightObj();
    this.originDest = this.toFlightBook.travelDetails;
  }

  public selectFlight(flightObj, seat): void {
    const data = this.appStorageUtilityService.getSelectedFlightObj();
    this.appStorageUtilityService.toBookFlight({
      ...data,
      flight: flightObj,
      seat: seat,
    });
    this.router.navigateByUrl(
      `user/passenger-info${
        this.bookingFrom === "pnr" ? "?bookingFrom=pnr" : ""
      }`
    );
  }

  public showHide(i) {
    if (this.showBlock && this.showBlock === i + 1) {
      this.showBlock = undefined;
    } else {
      this.showBlock = i + 1;
    }
  }
}
