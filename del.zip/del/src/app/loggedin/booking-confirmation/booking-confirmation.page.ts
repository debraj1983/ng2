import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-confirmation',
  templateUrl: './booking-confirmation.page.html',
  styleUrls: ['./booking-confirmation.page.scss'],
})
export class BookingConfirmationPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
