import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { PopoverController } from "@ionic/angular";

import { AppStorageUtilityService } from "../../services/app-storage-utility.service";
import { PnrService } from "../../services/pnr.service";

@Component({
  selector: "app-mydelta",
  templateUrl: "./mydelta.page.html",
  styleUrls: ["./mydelta.page.scss"],
})
export class MydeltaPage implements OnInit {
  public pageData;
  public skyMilePoint: any;
  public travelHistory: any;
  constructor(
    private appStorageUtilityService: AppStorageUtilityService,
    private router: Router,
    private pnrService: PnrService,
    public popoverController: PopoverController
  ) {}

  ngOnInit() {
    // this.popoverController.create()
    this.pageData = this.appStorageUtilityService.getSkyAndEdgePt();
    this.skyMilePoint = this.pageData.skymilePoints;
    this.appStorageUtilityService.pointsInfo.subscribe((data) => {
      this.skyMilePoint = data;
    });
    this.travelHistory = this.pageData.travelHistory.slice(0, 5);
    this.pnrService.pnrObservable.subscribe((data) => {
      this.travelHistory = [...data.slice(0, 5)];
    });
  }

  bookingUsingExistingDetails(pnrObj): void {
    this.appStorageUtilityService.setPnrData(pnrObj);
    this.router.navigateByUrl("/user/book?bookingFrom=pnr");
  }

  navigateToSearch() {
    this.router.navigateByUrl("/user/book");
  }
}
