import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { SharedModule } from "../../shared/shared.module";

import { IonicModule } from "@ionic/angular";

import { PassengerInfoPageRoutingModule } from "./passenger-info-routing.module";

import { PassengerInfoPage } from "./passenger-info.page";

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    IonicModule,
    PassengerInfoPageRoutingModule,
  ],
  declarations: [PassengerInfoPage],
})
export class PassengerInfoPageModule {}
