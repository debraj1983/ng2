import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import {
  AppStorageUtilityService,
  CABIN,
} from "../../services/app-storage-utility.service";

@Component({
  selector: "app-passenger-info",
  templateUrl: "./passenger-info.page.html",
  styleUrls: ["./passenger-info.page.scss"],
})
export class PassengerInfoPage implements OnInit {
  public selectedFlight: any;
  public travelDetails: any;
  public cabin: any;
  public displayCabin: any;
  public firstname: string;
  public middlename: string;
  public lastname: string;
  public age: string;
  public sex: string;

  public pnrData: any;

  private bookingFrom: any = "";

  constructor(
    private appStorageUtilityService: AppStorageUtilityService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.bookingFrom = this.route.snapshot.queryParamMap.get("bookingFrom");
    if (this.bookingFrom === "pnr") {
      this.pnrData = this.appStorageUtilityService.getPnrDataForBooking();
      this.firstname = this.pnrData.bookingDetails.passenger.firstname;
      this.middlename = this.pnrData.bookingDetails.passenger.middlename;
      this.lastname = this.pnrData.bookingDetails.passenger.lastname;
      this.age = this.pnrData.bookingDetails.passenger.age;
      this.sex = this.pnrData.bookingDetails.passenger.sex;
    }
    const toBookingData = this.appStorageUtilityService.getSelectedFlightObj();
    this.selectedFlight = toBookingData.flight;
    this.travelDetails = toBookingData.travelDetails;
    this.cabin = toBookingData.seat;
    this.displayCabin = CABIN[this.cabin];
  }

  bookFlight() {
    const passengerObj = {
      firstname: this.firstname,
      middlename: this.middlename,
      lastname: this.lastname,
      age: this.age,
      sex: this.sex,
    };
    this.appStorageUtilityService.toBookFlight({
      travelDetails: this.travelDetails,
      flight: this.selectedFlight,
      seat: this.cabin,
      passenger: passengerObj,
    });
    this.router.navigateByUrl(
      `user/preview-booking${
        this.bookingFrom === "pnr" ? "?bookingFrom=pnr" : ""
      }`
    );
  }
}
