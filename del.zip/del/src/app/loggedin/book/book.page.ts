import { Component, OnInit } from "@angular/core";
import { Router, ActivatedRoute } from "@angular/router";
import { AppStorageUtilityService } from "../../services/app-storage-utility.service";

@Component({
  selector: "app-book",
  templateUrl: "./book.page.html",
  styleUrls: ["./book.page.scss"],
})
export class BookPage implements OnInit {
  public blockFor = "oneway";
  public pnrData: any;
  private bookingFrom: any = "";

  constructor(
    private appStorageUtilityService: AppStorageUtilityService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.bookingFrom = this.route.snapshot.queryParamMap.get("bookingFrom");
    if (this.bookingFrom === "pnr") {
      this.pnrData = this.appStorageUtilityService.getPnrDataForBooking();
    }
  }

  changeTripType(type): void {
    this.blockFor = type;
  }
  public doSearch(evt) {
    this.appStorageUtilityService.toBookFlight({ travelDetails: evt });
    this.router.navigateByUrl(
      `/user/search-result${
        this.bookingFrom === "pnr" ? "?bookingFrom=pnr" : ""
      }`
    );
  }

  segmentChanged(event) {
    // console.log(event);
    this.blockFor = event.detail.value;
  }
}
