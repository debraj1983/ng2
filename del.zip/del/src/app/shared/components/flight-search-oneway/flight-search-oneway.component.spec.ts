import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { FlightSearchOnewayComponent } from './flight-search-oneway.component';

describe('FlightSearchOnewayComponent', () => {
  let component: FlightSearchOnewayComponent;
  let fixture: ComponentFixture<FlightSearchOnewayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FlightSearchOnewayComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(FlightSearchOnewayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
