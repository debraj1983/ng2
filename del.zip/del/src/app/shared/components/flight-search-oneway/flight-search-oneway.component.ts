import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter,
} from "@angular/core";

import { AutoCompleteOptions } from "ionic4-auto-complete";

import { OriginDestService } from "../../../services/origin-dest.service";

@Component({
  selector: "app-flight-search-oneway",
  templateUrl: "./flight-search-oneway.component.html",
  styleUrls: ["./flight-search-oneway.component.scss"],
})
export class FlightSearchOnewayComponent implements OnInit, OnChanges {
  @Input()
  public pnrData: any;

  @Output()
  public doSearch: EventEmitter<any> = new EventEmitter();

  public origin: string;
  public destination: string;
  public travelDate: any;
  public noOfPassenger: number;
  public today: string;

  public sourceList: string[];
  public destList: string[];

  public selected: string;

  public optionsOrigin: AutoCompleteOptions;
  public optionsDest: AutoCompleteOptions;

  constructor(public originDestService: OriginDestService) {
    this.optionsOrigin = new AutoCompleteOptions();
    this.optionsOrigin.placeholder = "Select Origin";

    this.optionsDest = new AutoCompleteOptions();
    this.optionsDest.placeholder = "Select Destination";
  }

  ngOnChanges() {
    if (this.pnrData) {
      this.travelDate = this.pnrData.bookingDetails.travelDetails.travelDate;
      this.origin = this.pnrData.bookingDetails.travelDetails.origin;
      this.destination = this.pnrData.bookingDetails.travelDetails.destination;
      this.noOfPassenger = this.pnrData.bookingDetails.travelDetails.noOfPassenger;
    }
  }

  ngOnInit() {
    this.noOfPassenger = 1;
    this.today = this.getToday();
    this.sourceList = this.getSource();
    this.destList = this.getDestination();
  }

  public addRemovePassenger(op): void {
    if (op === "add") {
      this.noOfPassenger++;
    } else {
      if (this.noOfPassenger > 1) {
        this.noOfPassenger--;
      }
    }
  }

  public doSearchFn() {
    const travelData = {
      origin: this.origin,
      destination: this.destination,
      travelDate: this.travelDate,
      noOfPassenger: this.noOfPassenger,
    };
    this.doSearch.emit(travelData);
  }

  on(output, event): void {
    console.log(output);
    // console.log(event);
  }

  private getToday() {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, "0");
    const mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    const yyyy = today.getFullYear();
    // console.log(dd,mm,yyyy);
    return `${yyyy}-${mm}-${dd}`;
  }

  private getSource() {
    const sources = [];
    for (let i = 1; i <= 10; i++) {
      sources.push("Source " + i);
    }
    return sources;
  }

  private getDestination() {
    const destination = [];
    for (let i = 1; i <= 10; i++) {
      destination.push("Destination " + i);
    }
    return destination;
  }
}
