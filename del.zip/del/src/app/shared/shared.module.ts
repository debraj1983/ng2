import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { IonicModule } from "@ionic/angular";
import { AutoCompleteModule } from "ionic4-auto-complete";

import { FlightSearchOnewayComponent } from "./components/flight-search-oneway/flight-search-oneway.component";
import { LoggedinHeaderComponent } from "./components/loggedin-header/loggedin-header.component";

const COMPONENTS = [FlightSearchOnewayComponent, LoggedinHeaderComponent];
@NgModule({
  declarations: [...COMPONENTS],
  imports: [CommonModule, FormsModule, AutoCompleteModule, IonicModule],
  exports: [...COMPONENTS],
})
export class SharedModule {}
