import { Component, OnInit } from '@angular/core';
import { BankService } from '../../service/bank.service';
import { AC } from '../../../app.constant';
import { AppStorageService } from '../../../services/app-storage.service';
import { LoaderService } from '../../../loader/loader.service';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss']
})
export class RequestComponent implements OnInit {
  public requests: any;
  public previewingDoc: any;
  public canAccept: boolean;

  public isShowHistory: boolean;
  public history: any;
  public merchantKey: string;

  public norecordsfound: boolean;
  public nrfMsg: string;
  public breadCrumbsMsg: string;

  constructor(private bankService: BankService, 
    private appStorageService: AppStorageService, 
    private loaderService: LoaderService,
    private route: ActivatedRoute, private r: Router) { }

  ngOnInit() {
    this.norecordsfound = false;
    this.getBankRequest();
  }

  public previewDoc(obj): void {
    this.previewingDoc = obj;
    this.canAccept = (AC.DOCUMENT_CAN_ACCEPT_BY_BANK === this.previewingDoc.Type 
      && AC.DOC_STATUS.PENDING === this.previewingDoc.Status) ? true : false;

    const innerHtml = `<embed width="100%" height="100%" src="${obj.Data}" type="application/pdf" />`;
    document.getElementById('pdfContentId').innerHTML = innerHtml;
    document.getElementById('previewId').style.display = 'block';
  }

  public closeDialog(): void {
    document.getElementById('previewId').style.display = 'none';
    document.getElementById('pdfContentId').innerHTML = '';
  }

  
public closeHistoryDialog(): void {
    this.isShowHistory = false;
  }

  public isAcceptDocuments(op: string): void {
    const localDoc = this.appStorageService.getData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, 'local');
    const requestDoc = localDoc[this.previewingDoc['merchantKey']];
    const updatedLocalDoc = requestDoc.map( elem => {
      if (elem.status === AC.DOC_STATUS.PENDING) {
        elem.status = (op === 'Y') ? AC.DOC_STATUS.ACCEPTED : AC.DOC_STATUS.REJECTED;
        elem.acceptTime = Date.now();
      }
      return elem;
    });
    localDoc[this.previewingDoc['merchantKey']] = updatedLocalDoc;
    this.appStorageService.setData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, localDoc, 'local');
    this.closeDialog();
    this.getBankRequest();
  }

  public updateRequest(payload: any): void {
    this.loaderService.show();
    this.bankService.postUpdatestatus(payload).subscribe(res => {
      if (res.status && res.status.statusCode === '200') {
        this.loaderService.hide();
        if (res.data && res.data.bank && res.data.bank.status === 'SUCCESS') {
          this.getBankRequest(true);
        }
      }
    });
  }

  public getHistory(event: any): void {
    const payload = {
      "merchantId": event.merchantId
    };
    this.loaderService.show();
    this.bankService.postBankGetHistory(payload).subscribe(res => {
      if (res && res.status && res.status.statusCode === '200') {
        this.history = res.data;
        this.merchantKey = event.merchantKey;
        this.isShowHistory = true;
        this.loaderService.hide();
      }
    })
  }

  private getBankRequest(noRecordsRedirect?: boolean): void {
    this.route.queryParams.subscribe(params => {
      const status = (params['status']) ? params['status'] : 'PENDING';
      
      this.nrfMsg = AC.STATIC_TEXT.REQUEST.NODATA[status];
      this.breadCrumbsMsg = AC.STATIC_TEXT.REQUEST.BREAD_CRUMBS[status];

      this.loaderService.show();
      this.bankService.getBankRequest().subscribe( res => {
        const filtered = [];
        if (res && res.data && res.data.bank && res.data.bank.length > 0) {
            for (let i = 0; i < res.data.bank.length; i++) {
              if (res.data.bank[i]['dockList'][0]['Status'] === status) {
                filtered.push(res.data.bank[i]);
              }
          }
          this.requests = filtered;
        } 
        if (noRecordsRedirect) {
          this.r.navigateByUrl('/bank/dashboard');
        }
        this.norecordsfound = (filtered.length === 0);
        this.loaderService.hide();
      });
    });
  }
}
