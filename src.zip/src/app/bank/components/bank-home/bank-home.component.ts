import { Component, OnInit } from '@angular/core';
import { AppStorageService } from '../../../services/app-storage.service';
import { AC } from '../../../app.constant';
import { LoaderService } from '../../../loader/loader.service';
import { BankService } from '../../service/bank.service';
import { CommonUtilityService } from '../../../services/common-utility.service';

@Component({
  selector: 'app-bank-home',
  templateUrl: './bank-home.component.html',
  styleUrls: ['./bank-home.component.scss']
})
export class BankHomeComponent implements OnInit {
  public requests: any;
  public hasRequest: any;
  public catConfigured: boolean;
  public allCatConf: boolean;
  public todoListMessage: string;

  constructor(private appStorageService: AppStorageService,
              private loaderService: LoaderService,
              private bankService: BankService,
              private commonUtilityService: CommonUtilityService) { }

  ngOnInit() {
    const conf = this.appStorageService.getData(AC.STORAGE_KEYS.CATEGORY_CONFIGURED, 'local');
    // this.catConfigured = true;
    this.catConfigured = (conf && conf === '1') ? true : false;
    const cC = this.commonUtilityService.getCatNamesFromSettings();
    const conCatName = this.commonUtilityService.getCatName(cC.pending_configuredCat);
    if (cC.pending_configuredCat.length === 0) {
      this.allCatConf = true;
    }

    if (conCatName.length > 0) {
      this.todoListMessage = `The following ${(conCatName.length > 1) ? 'categories are ' : 'category is '}not yet configured -
          <br /><div style="text-align: left !improtant;">${conCatName.join('<br />')}</div>`;
    }


    this.hasRequest = false;
    this.loaderService.show();
    this.bankService.getBankRequest().subscribe(res => {
      this.requests = (res.data && res.data.bank && res.data.bank.length > 0) ? res.data.bank : null;
      this.hasRequest = true;
      this.loaderService.hide();
    });
  }

}
