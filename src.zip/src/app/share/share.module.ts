import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomValidatorService } from './utility/custom.validator.service';
@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [],
  providers: [CustomValidatorService]
})
export class ShareModule { }
