import { TestBed, inject } from '@angular/core/testing';

import { Custom.ValidatorService } from './custom.validator.service';

describe('Custom.ValidatorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Custom.ValidatorService]
    });
  });

  it('should be created', inject([Custom.ValidatorService], (service: Custom.ValidatorService) => {
    expect(service).toBeTruthy();
  }));
});
