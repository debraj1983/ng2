export const STATIC_TEXT = {
    REQUEST: {
        BREAD_CRUMBS: {
            PENDING: 'Pending Request',
            APPROVED: 'Approved Request',
            REJECTED: 'Reject Request'
        },
        NODATA: {
            PENDING: 'No pending request found in the system',
            APPROVED: 'No approved request found in the system',
            REJECTED: 'No rejected request found in the system'
        }
    }
};