import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidator } from '../../../share/utility/custom.validator';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  public signUpForm: FormGroup;
  public passwordFormGroup: FormGroup;

  public firstRandom: number;
  public secondRandom: number;
  public sum: any;
  
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.getRandomNumbers();

    this.passwordFormGroup = this.fb.group({
      Password: ['', Validators.required],
      RePassword: ['', Validators.required]
    },{
      validator: CustomValidator.passwordValidator.bind(this)
    });



    this.signUpForm = this.fb.group({
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      EmailId: ['', [Validators.required, Validators.pattern("[^ @]*@[^ @]*") ] ],
      passwordFormGroup: this.passwordFormGroup,
      sumFirstSecond:  ['', Validators.required]
    });
  }

  public submitSignupForm(): void {
    // Create a model and call the service
  }

  
 public getRandomNumbers(): void {
    this.firstRandom = Math.floor(Math.random() * 10) + 1;
    this.secondRandom = Math.floor(Math.random() * 99) + 11;
    this.sum = this.firstRandom + this.secondRandom;
 }

}
