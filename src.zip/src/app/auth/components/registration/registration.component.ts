import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  public signUpForm: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.signUpForm = this.fb.group({
      'FirstName': ['', Validators.required],
      'LastName': ['', Validators.required],
      'EmailId': ['', [Validators.required, Validators.pattern("[^ @]*@[^ @]*") ] ],
      'Password': ['', Validators.required],
      'RePassword': ['', Validators.required]
    });
  }

}
