import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators} from '@angular/forms';
import { AppStorageService } from '../../../service/app.storage.service';
import { AuthService } from '../../../service/auth.service';
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;

  constructor(
    private fb: FormBuilder, 
    private appStorageService: AppStorageService,
    private route: Router,
    private authService: AuthService) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
        username: ['', [Validators.required, Validators.pattern("[^ @]*@[^ @]*") ]],
        password: ['', Validators.required]
      });
  }

  public userLogin(): void {
    const loginData = {
        username: this.loginForm.value['username'],
        password: this.loginForm.value['password']
    };

    this.appStorageService.setData('loggedIn', 1);
    this.authService.isLoggedIn(true);
    this.route.navigateByUrl('/user/my-account');
  }

}
