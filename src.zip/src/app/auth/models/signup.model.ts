export class SignupModel {
    constructor(public FirstName: string = '',
    public LastName: string = '',
    public EmailID: string = '',
    public Password: string = '',
    public ReTypePassword: string = '') {
        

    }
}