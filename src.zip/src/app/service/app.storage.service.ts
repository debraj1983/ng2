import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';

const STORAGE_KEY = 'pap-storage';

@Injectable({
  providedIn: 'root'
})
export class AppStorageService {

  constructor(@Inject(SESSION_STORAGE) private storage: StorageService) { }

  public setData(key: string, data: any): void {
    let addedData = this.getData(key);
    if (!addedData) {
      addedData = {};
      addedData[key] = data;
      this.storage.set(STORAGE_KEY, addedData);
    } else {
      addedData[key] = data;
      this.storage.set(STORAGE_KEY, addedData);
    }
    
  }

  public getData(key): any {
    const data = this.storage.get(STORAGE_KEY);
    return (data && data[key]) ? data[key] : null;
  }

  public clearData(): void {
    this.storage.clear();
  }

}
