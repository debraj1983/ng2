import { Injectable } from '@angular/core';
import { AppStorageService } from './app.storage.service';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public showNavBarEmitter: Observable<boolean>; 
  private _showNavBar: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  
  constructor(private appStorageService: AppStorageService) {
    if (this.checkUserLoggedIn()) {
      this.isLoggedIn(true);
    }
    this.showNavBarEmitter = this._showNavBar.asObservable(); 
   }

  public checkUserLoggedIn(): boolean {
    if (this.appStorageService.getData('loggedIn') === 1) {
      return true;
    }
    return false;
  }

  public isLoggedIn(data: boolean): void {
    this._showNavBar.next(data);
  }

}
