import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppStorageService } from '../../services/app-storage.service';

export const endPoints = {
  getRequest: environment.apiUrls.agencyRequest,
  submitAction: environment.apiUrls.agencySubmitAction,
  getHistory: environment.apiUrls.agencyGetHistory,
};

@Injectable({
  providedIn: 'root'
})
export class AgencyService {

  constructor(private http: HttpClient,
    private appStorageService: AppStorageService) { 
    
  }

  public getRequests(): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.http.get(endPoints.getRequest, httpOptions);
  }

  public submitRequest(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.submitAction, payload, httpOptions);
  }

  public agencyGetHistory(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.getHistory, payload, httpOptions);
  }

  private getHttpOption(): any {
    return {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + this.appStorageService.getData('token')
      })
    };
  }

  private callLoginService(url: string, payload: any, httpOptions: any): Observable<any> {
    if (environment.production) {
      return this.http.post(url, payload, httpOptions);
    } else {
      return this.http.get(url);
    }
  }
}
