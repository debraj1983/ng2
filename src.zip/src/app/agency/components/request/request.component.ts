import { Component, OnInit } from '@angular/core';
import { AgencyService } from '../../service/agency.service';
import { LoaderService } from '../../../loader/loader.service';
import { AC } from '../../../app.constant';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss']
})
export class RequestComponent implements OnInit {

  public requests: any;
  public canAccept: boolean;
  public previewingDoc: any;

  public isShowHistory: boolean;
  public history: any;

  public norecordsfound: boolean;
  public nrfMsg: string;
  public breadCrumbsMsg: string;

  constructor(private agencyService: AgencyService,
              private loaderService: LoaderService,
              private route: ActivatedRoute,
              private r: Router) { }

  ngOnInit() {
    this.getRequest();
  }

  public previewDoc(obj): void {
    this.previewingDoc = obj;
    this.canAccept = (AC.DOC_STATUS.PENDING === this.previewingDoc.Status) ? true : false;
    const innerHtml = `<embed width="100%" height="100%" src="${obj.Data}" type="application/pdf" />`;
    document.getElementById('pdfContentId').innerHTML = innerHtml;
    document.getElementById('previewId').style.display = 'block';
  }

  public closeDialog(): void {
    document.getElementById('previewId').style.display = 'none';
    document.getElementById('pdfContentId').innerHTML = '';
  }

  public isAcceptDocuments(op: string): void {
    const payload = {
      merchantId: this.previewingDoc.MerchantId,
      status: (op === 'Y') ? 'APPROVED' : 'REJECTED'
    };
    this.loaderService.show();
    this.agencyService.submitRequest(payload).subscribe(res => {
      this.closeDialog();
      this.loaderService.hide();
      this.getRequest(true);
    });
  }

  public closeHistoryDialog(): void {
    this.isShowHistory = false;
  }

  public getHistory(event: any): void {
    const payload = {
      merchantId: event.merchantId
    };
    this.loaderService.show();
    this.agencyService.agencyGetHistory(payload).subscribe(res => {
      if (res && res.status && res.status.statusCode === '200') {
        this.history = res.data;
        this.isShowHistory = true;
        this.loaderService.hide();
      }
    });
  }

  private getRequest(noRecordsRedirect?: boolean): void {
    this.route.queryParams.subscribe(params => {
      const p = (params.status) ? params.status : 'PENDING';
      this.nrfMsg = AC.STATIC_TEXT.REQUEST.NODATA[p];
      this.breadCrumbsMsg = AC.STATIC_TEXT.REQUEST.BREAD_CRUMBS[p];

      this.loaderService.show();
      this.agencyService.getRequests().subscribe(res => {
        this.loaderService.hide();
        const filtered = [];
        if (res && res.data && res.data.length > 0) {
            for (const d of res.data) {
              if (d.document && d.document.Status && d.document.Status === p) {
                filtered.push(d);
              }
          }
        }
        this.requests = filtered;
        if (noRecordsRedirect) {
          this.r.navigateByUrl('/agency/dashboard');
        }
        this.norecordsfound = (filtered.length === 0);
      });
    });
  }

}
