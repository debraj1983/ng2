import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { LogoutComponent } from './components/logout/logout.component';
import { GuardService, NotLoggedInGuardService } from './service/guard.service';


const routes: Routes = [
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { 
      path: 'auth', 
      loadChildren: './auth/auth.module#AuthModule', 
      canLoad: [NotLoggedInGuardService] 
    },
    {
      path: 'user', 
      loadChildren: './user/user.module#UserModule', 
      canLoad: [GuardService] 
    }
    ,
    {
      path: 'logout', 
      component: LogoutComponent, 
      canActivate: [GuardService] 
    }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
