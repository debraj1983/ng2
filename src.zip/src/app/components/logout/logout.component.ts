import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppStorageService } from '../../service/app.storage.service';
import { AuthService } from '../../service/auth.service';

@Component({
  selector: 'app-logout',
  templateUrl: './logout.component.html',
  styleUrls: ['./logout.component.scss']
})
export class LogoutComponent implements OnInit {

  constructor(private route: Router,
  private appStorageService: AppStorageService,
  private authService: AuthService) { }



  ngOnInit() {
      this.appStorageService.clearData();
      this.authService.isLoggedIn(false);
      this.route.navigate(['/auth/login']);
  }

}
