import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-my-stories',
  templateUrl: './my-stories.component.html',
  styleUrls: ['./my-stories.component.scss']
})
export class MyStoriesComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  public newStory(): void {
    this.router.navigate(['/user/add-story']);
  }

  public newSeries(): void {
    this.router.navigate(['/user/add-series']);
  }

}
