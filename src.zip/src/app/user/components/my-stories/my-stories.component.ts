import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-stories',
  templateUrl: './my-stories.component.html',
  styleUrls: ['./my-stories.component.scss']
})
export class MyStoriesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
