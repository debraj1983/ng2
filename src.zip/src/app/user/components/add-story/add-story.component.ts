import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-add-story',
  templateUrl: './add-story.component.html',
  styleUrls: ['./add-story.component.scss']
})
export class AddStoryComponent implements OnInit {
  public editProfileFormGroup: FormGroup;
  constructor(private fb: FormBuilder) { }


  ngOnInit() {
    this.editProfileFormGroup = this.fb.group({
      'StoryTitle': ['', Validators.required],
      'StoryContent': ['', Validators.required]
    });
  }

}
