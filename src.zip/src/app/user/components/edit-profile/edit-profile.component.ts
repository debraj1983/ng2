import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.scss']
})
export class EditProfileComponent implements OnInit {

  public editProfileFormGroup: FormGroup;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    const userData = this.getUserData();
    this.editProfileFormGroup = this.fb.group({
      'FirstName': [userData.FirstName, Validators.required],
      'MiddleName': [userData.MiddleName, Validators.required],
      'LastName': [userData.LastName, Validators.required],
      'EmailId': [userData.EmailId, Validators.required]
    });
  }

  private getUserData(): any {
    const userData = {
      'FirstName': 'Debraj',
      'MiddleName': '',
      'LastName': 'Dutta',
      'EmailId': 'debraj@gmail.com'
    };

    return userData;
  }

}
