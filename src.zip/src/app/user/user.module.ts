import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';
import { MyaccountComponent } from './components/myaccount/myaccount.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { MyStoriesComponent } from './components/my-stories/my-stories.component';
import { AddStoryComponent } from './components/add-story/add-story.component';

@NgModule({
  imports: [
    CommonModule,
    UserRoutingModule
  ],
  declarations: [
    UserComponent, 
    MyaccountComponent, 
    EditProfileComponent, 
    MyStoriesComponent, 
    AddStoryComponent
  ],
  bootstrap: [ UserComponent ]
})
export class UserModule { }
