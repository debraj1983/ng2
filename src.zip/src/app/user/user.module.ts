import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';


import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';
import { MyaccountComponent } from './components/myaccount/myaccount.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { MyStoriesComponent } from './components/my-stories/my-stories.component';
import { AddStoryComponent } from './components/add-story/add-story.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';
import { AddSeriesComponent } from './components/add-series/add-series.component';

@NgModule({
  imports: [
    CommonModule,
    UserRoutingModule,
    ReactiveFormsModule
  ],
  declarations: [
    UserComponent, 
    MyaccountComponent, 
    EditProfileComponent, 
    MyStoriesComponent, 
    AddStoryComponent,
    ChangePasswordComponent,
    AddSeriesComponent
  ],
  bootstrap: [ UserComponent ]
})
export class UserModule { }
