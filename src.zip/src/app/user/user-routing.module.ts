import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user.component';
import { MyaccountComponent } from './components/myaccount/myaccount.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { MyStoriesComponent } from './components/my-stories/my-stories.component';
import { AddStoryComponent } from './components/add-story/add-story.component';
import { AddSeriesComponent } from './components/add-series/add-series.component';
import { ChangePasswordComponent } from './components/change-password/change-password.component';


const routes: Routes = [ { path: '', component: UserComponent, children: [
      { path: 'my-account', component: MyaccountComponent  },
      { path: 'edit', component: EditProfileComponent  },
      { path: 'my-stories', component: MyStoriesComponent  },
      { path: 'add-story', component: AddStoryComponent  },
      { path: 'change-password', component: ChangePasswordComponent },
      { path: 'add-series', component: AddSeriesComponent  }
  ] },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
