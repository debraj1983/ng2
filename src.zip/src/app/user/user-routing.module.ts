import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyaccountComponent } from './components/myaccount/myaccount.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';
import { MyStoriesComponent } from './components/my-stories/my-stories.component';
import { AddStoryComponent } from './components/add-story/add-story.component';

const routes: Routes = [ { path: '', redirectTo: 'my-account' },
{ path: 'my-account', component: MyaccountComponent  },
{ path: 'edit', component: EditProfileComponent  },
{ path: 'my-stories', component: MyStoriesComponent  },
{ path: 'add-story', component: AddStoryComponent  }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
