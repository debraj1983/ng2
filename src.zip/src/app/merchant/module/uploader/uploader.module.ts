import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../../../shared/shared.module';
import { COMPONENT } from './component/index';

@NgModule({
  declarations: [
    ...COMPONENT
  ],
  imports: [
    CommonModule,
    SharedModule
  ],
  exports: [
    ...COMPONENT
  ]
})
export class UploaderModule { }
