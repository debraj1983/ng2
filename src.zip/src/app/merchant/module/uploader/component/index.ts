import { MerchantOnboardingFormComponent } from './merchant-onboarding-form/merchant-onboarding-form.component';
import { BankDetailsComponent } from './bank-details/bank-details.component';
import {
  BusinessRegistrationCertificatesComponent
 } from './business-registration-certificates/business-registration-certificates.component';
import { FileUploadComponent } from './file-upload/file-upload.component';

export const COMPONENT = [
    MerchantOnboardingFormComponent,
    BankDetailsComponent,
    BusinessRegistrationCertificatesComponent,
    FileUploadComponent
];
