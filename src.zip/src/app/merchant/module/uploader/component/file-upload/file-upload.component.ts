import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import { FileService } from '../../../../../services/file.service';
import { LoaderService } from '../../../../../loader/loader.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {

  public isDocumentSelected: boolean;
  public isPreview: boolean;
  public content: any;
  public fileData: any;

  @ViewChild('t', {static: false})
  public thisFile: ElementRef;

  @Input()
  public fileFor: any;

  @Output()
  public uploadedFileContent: EventEmitter<any> = new EventEmitter();

  constructor(private fileService: FileService, private loaderService: LoaderService) { }

  ngOnInit() {
    const fD = this.fileService.getAddedRecords(this.fileFor);
    console.log(this.fileFor);
    console.log(fD);
    if (fD) {
      this.isDocumentSelected = true;
      this.content = fD.content;
      this.fileData = fD.fileData;
      const toEmit = {
        fileContent: this.content,
        fileData: this.fileData
      };
      this.uploadedFileContent.emit(toEmit);
    }
  }

  public getFileDetails(fileList: any): void {
    this.loaderService.show();
    const self = this;
    const reader = new FileReader();
    if (fileList && fileList.length > 0) {
      this.fileData = fileList[0];
      reader.readAsDataURL(this.fileData);
      reader.onload = () => {
        self.content = reader.result;
        const toEmit = {
          fileContent: self.content,
          fileData: self.fileData
        };
        self.uploadedFileContent.emit(toEmit);
        self.isDocumentSelected = true;
        self.loaderService.hide();
      };
    }
  }

  public getContent(): void {
    this.isPreview = true;
    // this.content = this.fileService.getFileContent();
  }

  public removeDocument(): void {
    this.thisFile.nativeElement.value = '';
    const toEmit = {
      fileContent: '',
      fileData: undefined
    };
    this.uploadedFileContent.emit(toEmit);
    this.isDocumentSelected = false;
    this.fileService.removeDataFromContent();
    this.fileData = undefined;
  }

  public closeModal(isClose: boolean): void {
    this.isPreview = isClose;
  }

}
