import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantOnboardingFormComponent } from './merchant-onboarding-form.component';

describe('MerchantOnboardingFormComponent', () => {
  let component: MerchantOnboardingFormComponent;
  let fixture: ComponentFixture<MerchantOnboardingFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantOnboardingFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantOnboardingFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
