import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppStorageService } from '../../services/app-storage.service';

export const endPoints = {
  getBank: environment.apiUrls.merchantGetBank,
  getDocForRequest: environment.apiUrls.merchantGetDocForRequest,
  requestsList: environment.apiUrls.merchantRequestsList,
  submitRequest: environment.apiUrls.merchantSubmitRequest,
  getHistory: environment.apiUrls.merchantGetHistory,
};

@Injectable({
  providedIn: 'root'
})
export class MerchantService {
  constructor(private http: HttpClient, private appStorageService: AppStorageService) { 
    
  }

  public getBankList(): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.http.get(endPoints.getBank, httpOptions);
  }

  public getRequests(): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.http.get(endPoints.requestsList, httpOptions);
  }

  public getDocForRequest(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.getDocForRequest, payload, httpOptions);
  }

  public submitRequest(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.submitRequest, payload, httpOptions);
  }

  public getHistory(payload: any): Observable<any> {
    const httpOptions = this.getHttpOption();
    return this.callLoginService(endPoints.getHistory, payload, httpOptions);
  }

  private getHttpOption(): any {
    return {
      headers: new HttpHeaders({
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${this.appStorageService.getData('token')}`
      })
    };
  }

  private callLoginService(url: string, payload: any, httpOptions: any): Observable<any> {
    if (environment.production) {
      return this.http.post(url, payload, httpOptions);
    } else {
      return this.http.get(url);
    }
  }

}
