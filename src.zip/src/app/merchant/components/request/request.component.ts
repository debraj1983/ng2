import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../../service/merchant.service';
import { LoaderService } from '../../../loader/loader.service';
import { ActivatedRoute } from "@angular/router";
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.scss']
})
export class RequestComponent implements OnInit {

  public requests: any;
  public isShowHistory: boolean;
  public history: any;
  public merchantKey: string;

  public norecordsfound: boolean;
  public nrfMsg: string;
  public breadCrumbsMsg: string;

  constructor(private merchantService: MerchantService,
    private loaderService: LoaderService,
    private route: ActivatedRoute) { }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      const p = params['status'];
      this.nrfMsg = AC.STATIC_TEXT.REQUEST.NODATA[p];
      this.breadCrumbsMsg = AC.STATIC_TEXT.REQUEST.BREAD_CRUMBS[p];
      this.loaderService.show();
      this.merchantService.getRequests().subscribe(res => {
        this.loaderService.hide();
        const filtered = [];
        if (res && res.data && res.data.length > 0) {
            for (let i = 0; i < res.data.length; i++) {
              if (res.data[i].Status === p) {
                filtered.push(res.data[i]);
              }
          }
        }
        this.requests = filtered;
        this.norecordsfound = (filtered.length === 0);
       
      });
    });
   
    
  }

  public previewDoc(obj): void {
    const innerHtml = `<embed width="100%" height="100%" src="${obj.Data}" type="application/pdf" />`;
    document.getElementById('pdfContentId').innerHTML = innerHtml;
    document.getElementById('previewId').style.display = 'block';
  }

  public closeDialog(): void {
    document.getElementById('previewId').style.display = 'none';
    document.getElementById('pdfContentId').innerHTML = '';
  }

  public closeHistoryDialog(): void {
    this.isShowHistory = false;
  }

  public getHistory(event: any): void {
    const payload = {
      "bankId": event.bankUniqueID
    };
    this.loaderService.show();
    this.merchantService.getHistory(payload).subscribe(res => {
      if (res && res.status && res.status.statusCode === '200') {
        this.history = res.data;
        this.merchantKey = event.merchantKey;
        this.isShowHistory = true;
        this.loaderService.hide();
      }
    })
  }

}
