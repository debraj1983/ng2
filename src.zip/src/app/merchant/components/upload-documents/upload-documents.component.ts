import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MerchantService } from '../../service/merchant.service';
import { AC } from 'src/app/app.constant';
import { CommonUtilityService } from '../../../services/common-utility.service';
import { AppStorageService } from '../../../services/app-storage.service';
import { LoaderService } from '../../../loader/loader.service';
import { FileService } from '../../../services/file.service';

@Component({
  selector: 'app-upload-documents',
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss']
})
export class UploadDocumentsComponent implements OnInit {

  public requestSteps: any = AC.DOCUMENT_UPLOAD_STEPS;
  public currentStep: number;
  public curStepFileFor: string;

  public uploadedContent: any;
  public document: any;
  public documentForLocalStorage: any;

  public stepWiseRecords: any = [];

  public merchantCategory: string = AC.SIGNUP_CATEGORY[0].catLabel + '-' + AC.SIGNUP_CATEGORY[0].catCode;
  public selectedBankID: number;
  public isBankSelected: boolean;

  public bankList: any;
  public getBankListResponse: boolean;
  public uploadDoc: any;
  public selectedBank: any;

  public message: string;
  public showModal: boolean;


  constructor(private merchantService: MerchantService,
              private commonUtilityService: CommonUtilityService,
              private appStorageService: AppStorageService,
              private route: Router,
              private loaderService: LoaderService,
              private fileService: FileService) { }

  ngOnInit() {
    this.currentStep = 0;
    this.showModal = false;
    this.bankList = undefined;
    this.uploadedContent = [];
    this.document = [];
    this.documentForLocalStorage = [];
    this.setBankId('0');

    this.loaderService.show();
    this.merchantService.getBankList().subscribe(res => {
      if (res && res.status && res.status.statusCode === '200') {
        this.bankList = res.data;
        this.loaderService.hide();
        this.getBankListResponse = true;
      }
    }, error => {
      this.showModal = true;
      this.message = 'Please try again later';
      this.loaderService.hide();
    });
  }

  public setBankId(pos: any): void {
    if (pos !== '') {
      this.selectedBankID = pos;
      this.isBankSelected = true;
    } else {
      this.selectedBankID = undefined;
      this.isBankSelected = false;
    }
  }

  public getDocNeedToUpload(): void {
    if (!this.selectedBankID ) {
      this.showModal = true;
      this.message = 'Please select bank';
    } else {
      const data = this.bankList[this.selectedBankID];
      this.selectedBank = data.bankUniqueId;
      this.loaderService.show();
      this.merchantService.getDocForRequest(data).subscribe(res => {
        if (res && res.status && res.status.statusCode === '200') {
          this.loaderService.hide();
          const newRequestSteps = [];
          newRequestSteps.push(this.requestSteps[0]);
          this.uploadDoc = [...res.data.NotVerified, ...AC.DOCUMENT_NEED_TO_PUSH_LOCAL];
          if (this.uploadDoc && this.uploadDoc.length > 0) {
            for (const u of this.uploadDoc) {
              newRequestSteps.push({
                stepName: u,
                isActive: false
              });
            }
          }
          newRequestSteps.push(this.requestSteps[2]);
          this.requestSteps = newRequestSteps;
          this.nextStep();
        }
      });
    }
  }

  public uploadedFileOption(fileObj: any): void {
    this.nextStep();
  }

  public prevStep(): void {
    this.currentStep = (this.currentStep - 1);
    this.modifyStepObject();
  }

  private nextStep(): void {
    if (this.currentStep < (this.requestSteps.length - 2)) {
      this.currentStep++;
      this.modifyStepObject();
    } else {
      this.upload();
    }
  }

  private modifyStepObject(): void {
    const newReq = [];
    for (let i = 0; i < this.requestSteps.length; i++) {
      newReq.push({
        stepName: this.requestSteps[i].stepName,
        isActive: (this.currentStep === i)
      });
    }
    this.requestSteps = newReq;
    this.curStepFileFor = this.requestSteps.find(e => {
      return e.isActive === true;
    })['stepName'];
  }

  public upload() {
    this.setToUploadFiles();
    const merchantKey = this.commonUtilityService.getLocalDocKey(this.selectedBank);
    if (this.document.length === AC.DOCUMENT_NEED_TO_SEND_TO_SERVICE.length
          && this.documentForLocalStorage.length === AC.DOCUMENT_NEED_TO_PUSH_LOCAL.length) {
      const payload = {
        amount: '',
        documents: this.document,
        orgName: this.selectedBank
      };
      this.loaderService.show();
      this.merchantService.submitRequest(payload).subscribe(res => {
        if (res && res.status && res.status.statusCode === '200') {
          this.currentStep++;
          this.modifyStepObject();
          // alert('Documents sucessfully uploaded'); // TODO:: Need to replace by modal popup
          this.loaderService.hide();
         // this.route.navigateByUrl('/merchant/request/?status=PENDING');
        }
      });
      let localStorageData: any = this.appStorageService.getData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, 'local');
      if (!localStorageData) {
        localStorageData = {};
      }
      localStorageData[merchantKey] = this.documentForLocalStorage;
      this.appStorageService.setData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, localStorageData, 'local');
    } else {
      this.showModal = true;
      this.message = 'Please select all the documents';
    }
  }

  public closeModal(event): void {
    this.showModal = false;
  }

  private setToUploadFiles(): void {
    const addedFiles = this.fileService.stepWiseRecords;
    console.log('addedFiles-->');
    console.log(addedFiles);
    if (addedFiles && addedFiles.length > 0) {
      for (const fileObj of addedFiles) {
        if (this.commonUtilityService.inArray(AC.DOCUMENT_NEED_TO_SEND_TO_SERVICE, fileObj.fileFor)) {
          // Document need to send to service for saving data into database
          this.document.push({
            data: fileObj.content,
            type: fileObj.fileFor
          });
        } else {
          // Document need to send to service for saving data into database
          this.documentForLocalStorage.push({
            data: fileObj.content,
            type: fileObj.fileFor,
            acceptTime:  (AC.DEFAULT_APPROVED === fileObj.fileFor) ? Date.now() : '',
            uploadTime: Date.now(),
            status: (AC.DEFAULT_APPROVED === fileObj.fileFor) ? AC.DOC_STATUS.ACCEPTED : AC.DOC_STATUS.PENDING
          });
        }
      }
    }
    console.log('addedFiles-->');
    console.log(this.document);
    console.log('documentForLocalStorage-->');
    console.log(this.documentForLocalStorage);
  }
}


