import { Component, OnInit } from '@angular/core';
import { AppStorageService } from '../../../services/app-storage.service';

@Component({
  selector: 'app-merchant-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  public details: any;
  constructor(private appStorageService: AppStorageService) { }

  ngOnInit() {
    this.details = this.appStorageService.getData('details');
  }

}
