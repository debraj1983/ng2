import { Component, OnInit } from '@angular/core';
import { MerchantService } from '../../service/merchant.service';
import { LoaderService } from '../../../loader/loader.service';

@Component({
  selector: 'app-merchant-home',
  templateUrl: './merchant-home.component.html',
  styleUrls: ['./merchant-home.component.scss']
})
export class MerchantHomeComponent implements OnInit {
  public requests: any;
  public hasRequest: any;
  constructor(private merchantService: MerchantService,
    private loaderService: LoaderService) { }

  ngOnInit() {
    this.hasRequest = false;
    this.loaderService.show();
    this.merchantService.getRequests().subscribe(res => {
      this.requests = res.data;
      this.hasRequest = true;
      this.loaderService.hide();
    });
  }
}
