import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { MerchantHomeComponent } from './components/merchant-home/merchant-home.component';
import { MerchantRoutingModule } from './merchant-routing.module';

import { MerchantService } from './service/merchant.service';
import { RequestComponent } from './components/request/request.component';
import { UploadDocumentsComponent } from './components/upload-documents/upload-documents.component';
import { ProfileComponent } from './components/profile/profile.component';
import { HeaderComponent } from './components/header/header.component';
import { SidenavComponent } from './components/sidenav/sidenav.component';
import { MerchantComponent } from './merchant.component';
import { UploaderModule } from './module/uploader/uploader.module';
import { UnderConstructionComponent } from './components/under-construction/under-construction.component';

@NgModule({
  declarations: [
    MerchantHomeComponent,
    RequestComponent,
    UploadDocumentsComponent,
    ProfileComponent,
    HeaderComponent,
    SidenavComponent,
    MerchantComponent,
    UnderConstructionComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    MerchantRoutingModule,
    UploaderModule
  ],
  providers: [MerchantService]
})
export class MerchantModule { }
