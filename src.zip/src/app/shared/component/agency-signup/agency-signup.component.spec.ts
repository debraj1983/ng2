import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencySignupComponent } from './agency-signup.component';

describe('AgencySignupComponent', () => {
  let component: AgencySignupComponent;
  let fixture: ComponentFixture<AgencySignupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencySignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencySignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
