import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppStorageService } from '../../../services/app-storage.service';
import { CommonUtilityService } from '../../../services/common-utility.service';

import { AC } from '../../../app.constant';
@Component({
  selector: 'app-request-block',
  templateUrl: './request-block.component.html',
  styleUrls: ['./request-block.component.scss']
})
export class RequestBlockComponent implements OnInit {

  address = `587 Dresher Road Allen Park
             NY 10019`;

  @Input()
  public request: any;

  @Input()
  public userType: any;

  @Output()
  public previewFile = new EventEmitter();

  @Output()
  public updateRequest = new EventEmitter();

  @Output()
  public history = new EventEmitter();

  public allDocuments: any;
  public cardTitle: string;
  public cardIcon: string;

  public pending: string = AC.DOC_STATUS.PENDING;
  public approved: string = AC.DOC_STATUS.ACCEPTED;
  public rejected: string = AC.DOC_STATUS.REJECTED;

  public requestStatus: string;
  public requestStatusLabel = AC.DOC_STATUS_LABEL;
  public requestStatusIcon = AC.DOC_STATUS_ICON;

  public merchantId: string;
  public bankUniqueID: string;

  public merchantKey: string;

  public displayBankName: any = AC.BANKNAME;

  public merchantCategory: string = AC.SIGNUP_CATEGORY[0]['catLabel'] + '-' + AC.SIGNUP_CATEGORY[0]['catCode'];

  constructor(private commonUtilityService: CommonUtilityService,
              private appStorageService: AppStorageService) { }

  ngOnInit() {
    if (this.userType === 'merchant') {
      this.requestStatusLabel = AC.DOC_STATUS_LABEL_MERCHANT;
    } else if (this.userType === 'agency') {
      this.requestStatusLabel = AC.DOC_STATUS_LABEL_AGENCY;
    }
    let lD = [];
    this.cardIcon = 'fa-store';
    if (this.userType === 'merchant') {
        this.cardIcon = 'fa-university';
        this.merchantId = this.request.docs[0]['MerchantId'];
        this.bankUniqueID = this.request['Type'];
        const merchantKey = this.commonUtilityService.getLocalDocKey(this.bankUniqueID, this.merchantId);
        const localDocuments = this.appStorageService.getData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, 'local');
        this.merchantKey = merchantKey;
        this.cardTitle = 'Processor/Acquiring Bank1'; // this.displayBankName[this.request['Type']];

        if (localDocuments && localDocuments[merchantKey] && localDocuments[merchantKey].length > 0) {
          lD = localDocuments[merchantKey].map(elem => {
            return {
              Data: elem.data,
              MerchantId: this.merchantId,
              Status: elem.status,
              Type: elem.type,
              AcceptTime: elem.acceptTime,
              UploadTime: elem.uploadTime
            };
          });
      }
        this.allDocuments = [...this.request.docs, ...lD];
        let c = 0;
        if (this.allDocuments && this.allDocuments.length > 0) {
          for (const aD of this.allDocuments) {
            if (aD.Status === this.approved) {
              c++;
            }
          }
        }
        this.requestStatus =
            (c === this.allDocuments.length && this.request.Status !== AC.DOC_STATUS.ACCEPTED) ? 'PFB' : this.request.Status;
    } else if (this.userType === 'bank') {
      this.merchantId = this.request.dockList[0]['MerchantId'];
      const merchantKey = this.commonUtilityService.getLocalDocKey(undefined, this.merchantId);
      const localDocuments = this.appStorageService.getData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, 'local');
      this.merchantKey = merchantKey;

      this.cardTitle = this.request['name'];
      if (localDocuments && localDocuments[merchantKey] && localDocuments[merchantKey].length > 0) {
        lD = localDocuments[merchantKey].map(elem => {
          return {
            Data: elem.data,
            MerchantId: this.merchantId,
            Status: elem.status,
            Type: elem.type,
            AcceptTime: elem.acceptTime,
            UploadTime: elem.uploadTime
          };
        });
      }
      this.allDocuments = [...this.request.dockList[0].docs, ...lD];
      this.requestStatus = this.request.dockList[0]['Status'];
    } else {
      this.cardTitle = this.request['merchantName'];
      this.allDocuments = [this.request.document];
      this.requestStatus = this.request.document['Status'];
      this.merchantId = this.request.document.MerchantId;
    }
  }
  public previewDoc(obj): void {
    if (this.userType === 'bank' || this.userType === 'merchant') {
      obj['merchantKey'] = this.merchantKey;
    }
    this.previewFile.emit(obj);
  }

  public acceptRejectRequest(op: string): void {
    const payload = {
      merchantId: this.merchantId,
      status: (op === 'Y') ? 'APPROVED' : 'REJECTED'
    };
    this.updateRequest.emit(payload);
  }

  public getHistory(): void {
    //merchantKey
    if (this.userType === 'merchant') {
      this.history.emit({
        bankUniqueID: this.bankUniqueID,
        merchantKey: this.merchantKey
      });
    } else {
      this.history.emit({
        merchantId: this.merchantId,
        merchantKey: (this.merchantKey)?this.merchantKey:undefined
      });
    }
  }
}
