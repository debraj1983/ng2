import { LoginCommonComponent } from './login-common/login-common.component';
import { HeaderComponent } from './header/header.component';
import { BankSignupComponent } from './bank-signup/bank-signup.component';
import { AgencySignupComponent } from './agency-signup/agency-signup.component';
import { MerchantSignupComponent } from './merchant-signup/merchant-signup.component';
import { RequestBlockComponent } from './request-block/request-block.component';
import { HistoryComponent } from './history/history.component';
import { FooterComponent } from './footer/footer.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { ModalPopupComponent } from './modal-popup/modal-popup.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UnderConstructionComponent } from './under-construction/under-construction.component';
import { MobPopupComponent } from './mob-popup/mob-popup.component';

export const COMPONENTS = [
    LoginCommonComponent,
    HeaderComponent,
    BankSignupComponent,
    AgencySignupComponent,
    MerchantSignupComponent,
    RequestBlockComponent,
    HistoryComponent,
    FooterComponent,
    SidenavComponent,
    ModalPopupComponent,
    DashboardComponent,
    UnderConstructionComponent,
    MobPopupComponent
];
