import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss']
})
export class SidenavComponent implements OnInit {

  @Input()
  public options: any;

  @Input()
  public menuOptions: any;

  public filteredMenuOptions: any;

  constructor() { }

  ngOnInit() {
    this.filteredMenuOptions = this.menuOptions.filter((e: any) => {
      if (e.active) {
        return e;
      }
    })
  }

}
