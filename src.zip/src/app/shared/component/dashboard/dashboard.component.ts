import { Component, OnInit, Input } from '@angular/core';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  @Input()
  public userType: string;

  @Input()
  public requests: any;

  public pending: number;
  public accepted: number;
  public rejected: number;

  public pendingRequestUrl: string;
  public acceptedRequestUrl: string;
  public rejectedRequestUrl: string;

  constructor() { }

  ngOnInit() {
    this.pending = 0;
    this.accepted = 0;
    this.rejected = 0;

    this.pendingRequestUrl = `/${this.userType}/request/?status=${AC.DOC_STATUS.PENDING}`;
    this.acceptedRequestUrl = `/${this.userType}/request/?status=${AC.DOC_STATUS.ACCEPTED}`;
    this.rejectedRequestUrl = `/${this.userType}/request/?status=${AC.DOC_STATUS.REJECTED}`;

    switch(this.userType) {
      case 'agency':
          this.countRequstForAgency();
        break;
      case 'merchant':
          this.countRequstForMerchant();
        break;
      case 'bank':
          this.countRequstForBank();
        break;
    }
  }

  private countRequstForMerchant(): void {
    if (this.requests && this.requests.length > 0) {
      for (let i = 0; i < this.requests.length; i++) {
        if (this.requests[i].Status) {
          switch(this.requests[i].Status) {
            case AC.DOC_STATUS.PENDING:
                this.pending++;
              break;
            case AC.DOC_STATUS.ACCEPTED:
                this.accepted++;
              break;
            case AC.DOC_STATUS.REJECTED:
                this.rejected++;
              break;
          }
        }
      }
    }
  }

  private countRequstForBank(): void {
    if (this.requests && this.requests.length > 0) {
      for (let i = 0; i < this.requests.length; i++) {
        if (this.requests[i]['dockList'][0]['Status']) {
          switch(this.requests[i]['dockList'][0]['Status']) {
            case AC.DOC_STATUS.PENDING:
                this.pending++;
              break;
            case AC.DOC_STATUS.ACCEPTED:
                this.accepted++;
              break;
            case AC.DOC_STATUS.REJECTED:
                this.rejected++;
              break;
          }
        }
      }
    }
  }

  private countRequstForAgency(): void {
    if (this.requests && this.requests.length > 0) {
      for (let i = 0; i < this.requests.length; i++) {
        if (this.requests[i].document && this.requests[i].document.Status) {
          switch(this.requests[i].document.Status) {
            case AC.DOC_STATUS.PENDING:
                this.pending++;
              break;
            case AC.DOC_STATUS.ACCEPTED:
                this.accepted++;
              break;
            case AC.DOC_STATUS.REJECTED:
                this.rejected++;
              break;
          }
        }
      }
    }
  }

}
