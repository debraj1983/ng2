import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankSignupComponent } from './bank-signup.component';

describe('BankSignupComponent', () => {
  let component: BankSignupComponent;
  let fixture: ComponentFixture<BankSignupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankSignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankSignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
