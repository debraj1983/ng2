import { Component, OnInit, Input } from '@angular/core';
import { AppStorageService } from '../../../services/app-storage.service';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.scss']
})
export class HistoryComponent implements OnInit {

  @Input()
  public historyData: any;

  @Input()
  public userType: any;

  @Input()
  public merchantKey: any;

  public status: any = AC.DOC_STATUS_LABEL;

  constructor(private appStorageService: AppStorageService) { }

  ngOnInit() {
    if (this.historyData && this.historyData.length > 0) {
        for (let i = 0; i < this.historyData.length; i++) {
          this.historyData[i]['Timestamp'] = new Date(this.historyData[i]['Timestamp']).getTime();
        }
    }

    if (this.userType !== 'agency') {    
      const localDocs = this.appStorageService.getData(AC.STORAGE_KEYS.UPLOADED_DOCUMENTS, 'local')[this.merchantKey];
      if (localDocs && localDocs.length > 0) {
        for (let i = 0; i < localDocs.length; i++) {
          this.historyData.push({
            'TxId': AC.TXN_ID[i][0],
            'Value': {
              'Type': localDocs[i]['type'],
              'Status': 'PENDING'
            },
            'Timestamp': localDocs[i]['uploadTime']
          });
          if (localDocs[i]['acceptTime'] != '') {
            this.historyData.push({
              'TxId': AC.TXN_ID[i][1],
              'Value': {
                'Type': localDocs[i]['type'],
                'Status': localDocs[i]['status']
              },
              'Timestamp': localDocs[i]['acceptTime']
            });
          }
        }
      }
    }
    this.historyData.sort((date1, date2) => {
      if (date1.Timestamp > date2.Timestamp) return -1;
      if (date1.Timestamp < date2.Timestamp) return 1;
      return 0;
    });

  }

  public timeConverter(UNIX_timestamp){
    var a = new Date(UNIX_timestamp);
    var months = ['01','02','03','04','05','06','07','08','09','10','11','12'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
    return time;
  }

  

}
