import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AC } from '../../../app.constant';
import { INgxMyDpOptions, IMyDateModel } from 'ngx-mydatepicker';

@Component({
  selector: 'app-merchant-signup',
  templateUrl: './merchant-signup.component.html',
  styleUrls: ['./merchant-signup.component.scss']
})
export class MerchantSignupComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public backToLogin: EventEmitter<any> = new EventEmitter();

  @Output()
  public merchantSignUpDataObj: EventEmitter<any> = new EventEmitter();

  @Output()
  public showModalOptions: EventEmitter<any> = new EventEmitter();

  public myOptions: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd.mm.yyyy',
  };

  public merchantSignUpForm: FormGroup;
  public merchantCategory: any = AC.SIGNUP_CATEGORY;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.merchantSignUpForm = this.fb.group({
      uniqueId: [this.options.signUpPrefilled.uniqueId, [Validators.required]],
      name: [this.options.signUpPrefilled.name, Validators.required],
      password: [this.options.signUpPrefilled.password, Validators.required],
      category: [this.options.signUpPrefilled.category, [Validators.required]],
      emailId: [this.options.signUpPrefilled.email, Validators.required],
      dateOfEstablishment: [this.options.signUpPrefilled.date, Validators.required]
    });
  }

  public merchantSignUp(): void {
    const arr = (this.merchantSignUpForm.value.category) ? this.merchantSignUpForm.value.category.split('-') : undefined;
    const merchantSignUpSata: any = {
      uniqueId: this.merchantSignUpForm.value.uniqueId,
      fullName: this.merchantSignUpForm.value.name,
      password: this.merchantSignUpForm.value.password,
      category: (arr && arr.length > 0) ? arr[0] : null,
      emailId: this.merchantSignUpForm.value.emailId,
      dateOfEstablishment: this.merchantSignUpForm.value.dateOfEstablishment.formatted,
      role: AC.ROLE.MERCHANT
    };

    this.merchantSignUpDataObj.emit(merchantSignUpSata);
  }

  public backToLoginView(): void {
     // console.log(this.merchantSignUpForm.value);
   this.backToLogin.emit();
  }

  public setDate(): void {
      // Set today date using the patchValue function
      const date = new Date();
      this.merchantSignUpForm.patchValue({dateOfEstablishment: {
      date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()}
      }});
  }

  public clearDate(): void {
      // Clear the date using the patchValue function
      this.merchantSignUpForm.patchValue({dateOfEstablishment: null});
  }

  public showCatCode(): void {
    // Need to remove alert and add a small modal popup for displaying the message
    const arr = (this.merchantSignUpForm.value.category) ? this.merchantSignUpForm.value.category.split('-') : undefined;
    if (arr && arr.length > 0) {
      this.showModalOptions.emit({
        showModal: true,
        message: 'Your have selected \'' + arr[1] + '\''
      });
    }
  }
}
