import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-route.module';

import { StorageServiceModule } from 'ngx-webstorage-service';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { LogoutComponent } from './components/logout/logout.component';

import { AppStorageService } from './service/app.storage.service';
import { GuardService, NotLoggedInGuardService } from './service/guard.service';
import { AuthService } from './service/auth.service';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    RouterModule,
    AppRoutingModule,
    StorageServiceModule
  ],
  providers: [
    AppStorageService,
    GuardService,
    AuthService,
    NotLoggedInGuardService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
