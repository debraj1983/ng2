
import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, LOCAL_STORAGE, StorageService } from 'ngx-webstorage-service';

const STORAGE_KEY = 'mob';

@Injectable()
export class AppStorageService {
  private storage: any;

  constructor(@Inject(SESSION_STORAGE) private sessionStorage: StorageService, 
  @Inject(LOCAL_STORAGE) private localStorage: StorageService) { }

  public setData(key: string, data: any, storageType?: string): void {
    if (!storageType) {
      storageType = 'session';
    }
    this.storage = (storageType === 'session') ? this.sessionStorage : this.localStorage;
    let addedData = this.storage.get(STORAGE_KEY);
    if (!addedData) {
      addedData = {};
      addedData[key] = data;
    } else {
      addedData[key] = data;
    }
    this.storage.set(STORAGE_KEY, addedData);
  }

  public getData(key: string, storageType?: string): any {
    if (!storageType) {
      storageType = 'session';
    }
    this.storage = (storageType === 'session') ? this.sessionStorage : this.localStorage;
    const data = this.storage.get(STORAGE_KEY);    
    return (data && data[key]) ? data[key] : null;
  }

  public setDataInObject(key: string, subkey: string, data: string, storageType?: string) {
    const keyData = this.getData(key, storageType);
    keyData[subkey] = data;
    this.setData(key, keyData, storageType);
  }

  public clearData(storageType?: string): void {
    if (!storageType) {
      storageType = 'session';
    }
    this.storage = (storageType === 'session') ? this.sessionStorage : this.localStorage;
    this.storage.clear();
  }

}