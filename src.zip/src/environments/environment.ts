// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

const protocal = 'http://';
const ip = '52.172.146.60';
const port = '51099';
const domain = `${protocal}${ip}:${port}/merchant-onboarding-services/apis/`;
const loginApi = `${domain}app/login`;
export const environment = {
  production: true,
  apiUrls: {
    login: {
      bankLogin: loginApi,
      agentLogin: loginApi,
      merchantLogin: loginApi
    },
    signUp: `${domain}app/signup`,
    merchantRequestsList: `${domain}merchant/requests`,
    merchantGetBank: `${domain}merchant/getbanks`,
    merchantGetDocForRequest: `${domain}merchant/getdocforrequest`,
    merchantSubmitRequest: `${domain}merchant/submitrequest`,
    merchantGetHistory: `${domain}merchant/getHistory`,
    bankRequest: `${domain}bank/requests`,
    bankSetrules: `${domain}bank/setrules`,
    bankGetHistory: `${domain}bank/getHistory`,
    bankUpdatestatus: `${domain}bank/updatestatus`,
    agencyRequest: `${domain}noca/requests`,
    agencySubmitAction: `${domain}noca/submitaction`,
    agencyGetHistory: `${domain}noca/getHistory`,
  }
};

/*
const loginApi = 'assets/mock/login-response.json';

export const environment = {
  production: false,
  apiUrls: {
    login: {
      bankLogin: loginApi,
      agentLogin: loginApi,
      merchantLogin: loginApi
    },
    signUp: 'assets/mock/signup-response.json',
    merchantRequestsList: 'assets/mock/merchant-request.json',
    merchantGetBank: 'assets/mock/merchant-getbank.json',
    merchantGetDocForRequest: 'assets/mock/merchant-getdocforrequest.json',
    merchantSubmitRequest: 'assets/mock/merchant-submitrequest.json',
    merchantGetHistory: '',
    bankRequest: 'assets/mock/bank-requests.json',
    bankSetrules: 'assets/mock/bank-setrules.json',
    bankGetHistory: 'assets/mock/bank-getHistory.json',
    bankUpdatestatus: 'assets/mock/bank-updatestatus.json',
    agencyRequest: 'assets/mock/agency-requests.json',
    agencySubmitAction: 'assets/mock/agency-submitaction.json',
    agencyGetHistory: ''
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
