import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AC } from '../../../app.constant';

@Component({
  selector: 'app-agency-signup',
  templateUrl: './agency-signup.component.html',
  styleUrls: ['./agency-signup.component.scss']
})
export class AgencySignupComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public backToLogin: EventEmitter<any> = new EventEmitter();

  @Output()
  public agencySignUpDataObj: EventEmitter<any> = new EventEmitter();

  public agencySignUpForm: FormGroup;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.agencySignUpForm = this.fb.group({
      uniqueId: ['', [Validators.required]],
      name: ['', Validators.required],
      password: ['', Validators.required],
      domainName: ['', Validators.required]
    });
  }

  public agencySignUp(): void {
    const agencySignUpSata: any = {
      uniqueId: this.agencySignUpForm.value.uniqueId,
      name: this.agencySignUpForm.value.name,
      password: this.agencySignUpForm.value.password,
      domainName: this.agencySignUpForm.value.domainName,
      role: AC.ROLE.AGENCY
    };
    this.agencySignUpDataObj.emit(agencySignUpSata);
  }

  public backToLoginView(): void {
    this.backToLogin.emit();
  }
}
