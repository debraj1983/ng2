import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AC } from '../../../app.constant';
import {INgxMyDpOptions, IMyDateModel} from 'ngx-mydatepicker';

@Component({
  selector: 'app-merchant-signup',
  templateUrl: './merchant-signup.component.html',
  styleUrls: ['./merchant-signup.component.scss']
})
export class MerchantSignupComponent implements OnInit {

  @Input()
  public options: any;

  @Output()
  public backToLogin: EventEmitter<any> = new EventEmitter();

  @Output()
  public merchantSignUpDataObj: EventEmitter<any> = new EventEmitter();

  public myOptions: INgxMyDpOptions = {
    // other options...
    dateFormat: 'dd.mm.yyyy',
  };

  public merchantSignUpForm: FormGroup;
  public merchantCategory: any = AC.CATEGORY;

  constructor(private fb: FormBuilder) { }

  ngOnInit() {



    console.log(this.merchantCategory);
    this.merchantSignUpForm = this.fb.group({
      uniqueId: ['', [Validators.required]],
      name: ['', Validators.required],
      password: ['', Validators.required],
      category: ['', [Validators.required]],
      emailId: ['', Validators.required],
      dateOfEstablishment: [null, Validators.required]
    });
  }

  public merchantSignUp(): void {
    const merchantSignUpSata: any = {
      uniqueId: this.merchantSignUpForm.value.uniqueId,
      name: this.merchantSignUpForm.value.name,
      password: this.merchantSignUpForm.value.password,
      category: this.merchantSignUpForm.value.category,
      emailId: this.merchantSignUpForm.value.emailId,
      dateOfEstablishment: this.merchantSignUpForm.value.dateOfEstablishment,
      role: AC.ROLE.MERCHANT
    };

    this.merchantSignUpDataObj.emit(merchantSignUpSata);
  }

  public backToLoginView(): void {
    console.log(this.merchantSignUpForm.value);
    // this.backToLogin.emit();
  }

  public setDate(): void {
      // Set today date using the patchValue function
      let date = new Date();
      this.merchantSignUpForm.patchValue({dateOfEstablishment: {
      date: {
          year: date.getFullYear(),
          month: date.getMonth() + 1,
          day: date.getDate()}
      }});
  }

  public clearDate(): void {
      // Clear the date using the patchValue function
      this.merchantSignUpForm.patchValue({dateOfEstablishment: null});
  }

}
