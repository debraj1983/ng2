import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgencyHomeComponent } from './components/agency-home/agency-home.component';

const routes: Routes = [ 
  { path: '', component: AgencyHomeComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgencyRoutingModule { }
