import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { AgencyHomeComponent } from './components/agency-home/agency-home.component';
import { AgencyRoutingModule } from './agency-routing.module';

import { AgencyService } from './service/agency.service';

@NgModule({
  declarations: [AgencyHomeComponent],
  imports: [
    CommonModule,
    SharedModule,
    AgencyRoutingModule
  ],
  providers: [AgencyService]
})
export class AgencyModule { }
