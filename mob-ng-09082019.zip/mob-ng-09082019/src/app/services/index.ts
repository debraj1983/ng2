import { AppStorageService } from './app-storage.service';
import { GuardService } from './guard.service';
import { LoginService } from './login.service';
import { AuthService } from './auth.service';

export const SERVICES = [
    AppStorageService,
    GuardService,
    LoginService,
    AuthService
];