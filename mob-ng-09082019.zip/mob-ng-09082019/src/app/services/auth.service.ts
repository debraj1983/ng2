import { Injectable } from '@angular/core';
import { AppStorageService } from './app-storage.service';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  public showNavBarEmitter: Observable<boolean>; 
  private _showNavBar: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  
  constructor(private appStorageService: AppStorageService) {
    if (this.checkUserLoggedIn()) {
      this.isLoggedIn(true);
    }
    this.showNavBarEmitter = this._showNavBar.asObservable(); 
   }

   public checkLoggedIN(): void {
    this.isLoggedIn(this.checkUserLoggedIn());
    this.showNavBarEmitter = this._showNavBar.asObservable(); 
   }


   public checkUserLoggedIn(): boolean {
    if (this.appStorageService.getData('bankLoggedIn') === 1 || 
          this.appStorageService.getData('agencyLoggedIn') === 1 || 
          this.appStorageService.getData('merchantLoggedIn') === 1) {
      return true;
    }
    return false;
  }
  

  public isLoggedIn(data: boolean): void {
    this._showNavBar.next(data);
  }

  public logout(): void {
    this.appStorageService.clearData();
  }

}
