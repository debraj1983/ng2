export const AC = {
    ROLE: {
        BANK: 'Bank',
        AGENCY: 'NOCA',
        MERCHANT: 'Merchant'
    },
    CATEGORY: [{ // Merchant type
        catName: 'MCC1'
    }, {
        catName: 'MCC2'
    }]
};