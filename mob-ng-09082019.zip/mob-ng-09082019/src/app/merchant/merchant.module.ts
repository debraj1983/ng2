import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { MerchantHomeComponent } from './components/merchant-home/merchant-home.component';
import { MerchantRoutingModule } from './merchant-routing.module';

import { MerchantService } from './service/merchant.service';

@NgModule({
  declarations: [MerchantHomeComponent],
  imports: [
    CommonModule,
    SharedModule,
    MerchantRoutingModule
  ],
  providers: [MerchantService]
})
export class MerchantModule { }
