import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';

import { BankHomeComponent } from './components/bank-home/bank-home.component';
import { BankRoutingModule } from './bank-routing.module';
import { BankService } from './service/bank.service';

@NgModule({
  declarations: [BankHomeComponent],
  imports: [
    CommonModule,
    SharedModule,
    BankRoutingModule
  ],
  providers: [BankService]
})
export class BankModule { }
