# Function definition is here
def changeme( data ):
   "This changes a passed list into this function"
   data = 10 # This would assi new reference in mylist
   print ("Values inside the function: ", data)
   return

# Now you can call changeme function
mylist = [10,20,30]
changeme( mylist )
print ("Values outside the function: ", mylist)

print('----------------------------');

# Function definition is here
def printinfo( name, age ):
   "This prints a passed info into this function"
   print ("Name: ", name)
   print ("Age ", age)
   return

# Now you can call printinfo function
printinfo( age = 50, name = "miki" )
printinfo( "Debraj", 36 )