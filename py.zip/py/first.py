data = { 'Ben': 1000.00, 'Johnson': 32000.00, 'George': 2000.00 }
for item in data:
    print(item)

print('123'+'abc')

x = 1+2*3-8/4
print(x)

print(int(98.6))