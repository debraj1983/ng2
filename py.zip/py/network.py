print(ord('l') , ord('i'), ord('n'), ord('e'))
print(chr(42))