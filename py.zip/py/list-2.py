fname = input("Enter file name: ")
fh = open(fname)
lst = list()
for line in fh:
    if not line.startswith("From ") : continue
    ln = line.split();
    lst.append(ln[1]);
print("\n".join(lst))
print("There were " + str(len(lst)) + " lines in the file with From as the first word")