import urllib.request, urllib.parse, urllib.error
import json
import ssl

# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

jsonFileUrl = 'http://py4e-data.dr-chuck.net/comments_255102.json'
uh = urllib.request.urlopen(jsonFileUrl, context=ctx)
data = uh.read()
jsonData = json.loads(data)

sum = 0
if len(jsonData["comments"]) > 0:
    for r in jsonData["comments"]:
      sum += int(r["count"])

print(sum)