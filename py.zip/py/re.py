import re;

t = '<p>Please click <a href="http://www.dr-chuck.com">here</a></p>'
d = re.findall('href="(.+)"', t)
print(d)  

fname = 'regex_sum_255097.txt'
fh = open(fname)
content = fh.read();
numbers = re.findall('[0-9]+', content)
sum = 0;
for n in numbers:
    sum += int(n)
print(sum)  
#print("Average spam confidence:" + (sum/count))