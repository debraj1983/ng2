#x , y = 3, 4

#x = { 'chuck' : 1 , 'fred' : 42, 'jan': 100}
#y = x.items()

#print(y)

tmp = list()
c = {'x': 1}
for k, v in c.items() :
    tmp.append( (v, k) )

print(tmp)


days = ('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')
print(days.append('X'))
daysD = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
print(daysD.append('X'))

