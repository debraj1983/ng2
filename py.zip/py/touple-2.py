name = input("Enter file:")
if len(name) < 1 : name = "mbox-short.txt"
handle = open(name)
dictionary = dict()
for line in handle:
    if not line.startswith("From ") : continue
    ln = line.split();
    lt = ln[5].split(':')
    dictionary[lt[0]] = dictionary.get(lt[0],0) + 1;

#dictionary.sorted()
for k,v in sorted(dictionary.items()):
    print(k + ' ' + str(v))