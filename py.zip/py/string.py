#greet = 'Hello Bob';

#print(greet.upper());

#x = 'From marquard@uct.ac.za'
#print(x[14:17])

#data = 'From stephen.marquard@uct.ac.za Sat Jan  5 09:14:16 2008'
#pos = data.find('.')
#print(data[pos:pos+3])


#text = "X-DSPAM-Confidence:    0.8475";
#pos = text.find('0.8475')
#print(float(text[pos:]))

#stuff = 'Hello world'
#type(stuff)
#dir(stuff)

#fname = input("Enter file name: ")
#fh = open(fname)
#fd = fh.read();
#print(fd.upper())


# Use the file name mbox-short.txt as the file name
fname = input("Enter file name: ")
fh = open(fname)
sum = 0;
count = 0
for line in fh:
    if not line.startswith("X-DSPAM-Confidence:") : continue
    pos = line.find(' ')
    sum += float(line[pos:])
    count++
print("Average spam confidence:" + (sum/count))