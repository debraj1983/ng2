#stuff = dict()
#print(stuff.get('candy',-1))

name = input("Enter file:")
if len(name) < 1 : name = "mbox-short.txt"
handle = open(name)
dictionary = dict()
for line in handle:
    if not line.startswith("From ") : continue
    ln = line.split();
    dictionary[ln[1]] = dictionary.get(ln[1],0) + 1;

maxVal = 0
maxKey = ''
for k,v in dictionary.items():
    if v > maxVal:
        maxKey = k
        maxVal = v

print(maxKey + " " + str(maxVal))

#print(max(list(dictionary.values())))