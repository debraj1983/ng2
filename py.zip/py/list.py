#fruit = ['Banana','A','V']
#print(len(fruit))


#a = [1, 2, 3]
#b = [4, 5, 6]
#c = a + b
#print(len(c))

#t = [9, 41, 12, 3, 74, 15]
#print(t[2:4])

def checkIfElementExists(elemet, listVar):
    isExists = False;
    if (len(listVar) > 0):
        for lV in listVar:
            if lV == elemet: 
                isExists = True;
                break;
    return isExists;

fname = input("Enter file name: ")
fh = open(fname)
lst = list()
for line in fh:
    arr = line.rstrip().split()
    for elem in arr:
        if (checkIfElementExists(elem, lst) == False):
            lst.append(elem);

lst.sort();
print(lst);



    