import urllib.request, urllib.parse, urllib.error
import xml.etree.ElementTree as ET
import ssl

# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

xmlFileUrl = 'http://py4e-data.dr-chuck.net/comments_255101.xml'
uh = urllib.request.urlopen(xmlFileUrl, context=ctx)
data = uh.read()

tree = ET.fromstring(data)
results = tree.findall('comments/comment')

sum = 0
if len(results) > 0:
    for r in results:
      sum += int(r.find('count').text)

print(sum)