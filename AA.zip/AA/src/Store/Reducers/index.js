import { combineReducers } from "redux";

import CheckIn from "./CheckIn/Checkin";

export default combineReducers({
  CheckIn
});
