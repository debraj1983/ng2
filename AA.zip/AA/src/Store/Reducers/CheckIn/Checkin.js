const CheckIn = (state = [], action) => {
  switch (action.type) {
    default:
      return state;
  }
};

export default CheckIn;
