import React from "react";
import "./Admin.scss";

function Admin() {
  return <div>Admin Works</div>;
}

export default Admin;
