const APP_CONSTANT = {
  STORAGE_KEYS: {
    USERS: "users",
    FLIGHT_DETAILS: "flightDetails"
  },
  COLOR_CODE_ONLY: {
    checkedIdSeat: "#083e70",
    availableSeat: "#8fb6db",
    checkedInWithWheelChair: "#991c39",
    checkedInWithMeal: "#077034",
    checkedInWithMealAndWheelChair: "#076d70"
  },
  COLOR_CODE: [
    {
      key: "Checked In Seat",
      value: "#083e70"
    },
    {
      key: "Available Seat",
      value: "#8fb6db"
    },
    {
      key: "Checked In With Wheel Chair",
      value: "#991c39"
    },
    {
      key: "Checked In With Meal",
      value: "#077034"
    },
    {
      key: "Checked In With and Wheel Chair and Meal",
      value: "#076d70"
    }
  ]
};

export default APP_CONSTANT;
