import React from "react";
import APP_CONSTANT from "../../Constants";

function FlightDetails(props) {
  const flight = props.flightData;
  return (
    <div className="flightListRight">
      <div className="flight">
        <div className="flightDetails">
          <h1>{`${flight.airlinesName} : ${flight.flightNo} - ${flight.fromTo}`}</h1>
          <p>Departure Time: {flight.departureTime}</p>
          <p>Arrival Time: {flight.arrivalTime}</p>
          <ColorCodeBlock />
        </div>
        <SeatsInFlight seats={flight.seats}></SeatsInFlight>
      </div>
    </div>
  );
}

function SeatsInFlight(props) {
  const getButtonClass = obj => {
    if (!obj["checkedIn"]) {
      return "availableSeat";
    } else {
      if (obj["hasWheelChair"] && obj["hasMealOption"]) {
        return "checkedInWithMealAndWheelChair";
      } else if (obj["hasWheelChair"]) {
        return "checkedInWithWheelChair";
      } else if (obj["hasMealOption"]) {
        return "checkedInWithMeal";
      } else {
        return "checkedIdSeat";
      }
    }
    return "";
  };
  const seats = props.seats;
  return (
    <div className="flightSeatAvailibility">
      <h1>Seat Availibility</h1>
      {Object.entries(seats).map(element => (
        <div key={`rowid_${element[0]}`}>
          {Object.entries(element[1]).map((eachRowSeats, i) => (
            <span key={element[0] + eachRowSeats[0]}>
              <button
                className={`seatButton ${getButtonClass(eachRowSeats[1])}`}
              >
                {element[0] + eachRowSeats[0]}
              </button>
              <WalkingArea columnNo={i} />
            </span>
          ))}
        </div>
      ))}
    </div>
  );
}

function WalkingArea(props) {
  if (props.columnNo === 2) {
    return <span className="gap">&nbsp;</span>;
  } else {
    return <span></span>;
  }
}

function ColorCodeBlock() {
  const colorCode = APP_CONSTANT["COLOR_CODE"];
  return (
    <div>
      {colorCode.map((elem, index) => (
        <div key={index}>
          <button
            style={{
              backgroundColor: elem.value,
              width: "20px",
              height: "20px"
            }}
          ></button>
          &nbsp;
          <span
            style={{
              display: "inline-block",
              lineHeight: "25px"
            }}
          >
            {elem.key}
          </span>
        </div>
      ))}
    </div>
  );
}

export default FlightDetails;
