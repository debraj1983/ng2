import React from "react";

function Passengers(props) {
  console.log(props.passengersData);
  return (
    <div>
      <table border="1">
        <thead>
          <tr>
            <td>Passenger Name</td>
            <td>Seat No</td>
            <td>Meal</td>
            <td>Wheel Chail</td>
          </tr>
        </thead>
        <tbody>
          {props.passengersData.map(passenger => (
            <tr>
              <td>{passenger.passengerName}</td>
              <td>{passenger.seatNo}</td>
              <td>Meal</td>
              <td>Wheel Chail</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Passengers;
