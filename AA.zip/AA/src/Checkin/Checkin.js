import React, { useState } from "react";
import {
  Route,
  Link,
  BrowserRouter as Router,
  Redirect
} from "react-router-dom";

import FlightDetails from "./Components/FlightDetails";
import Passengers from "./Components/Passengers";

import "./Checkin.scss";
import APP_CONSTANT from "../Constants";
import dataStorage from "../Utility/AppStorage";

function Checkin() {
  const flights = dataStorage.getData(APP_CONSTANT.STORAGE_KEYS.FLIGHT_DETAILS);
  const [flightData, setFlightData] = useState(flights[0]);
  const [passengersData, setPassengersData] = useState(flights[0].passengers);
  const flightOnClick = data => {
    setFlightData(data);
    setPassengersData(data.passengers);
  };
  return (
    <div className="flightPanel">
      <FlightList flights={flights} flightOnClick={flightOnClick}></FlightList>
      <Router>
        <Redirect from="/" to="/checkin/flightdetails" />
        <div>
          <nav>
            <ul className="nav">
              <li>
                <Link to="/checkin/flightdetails">Flight Details</Link>
              </li>
              <li>
                <Link to="/checkin/passengers">Passengers</Link>
              </li>
            </ul>
          </nav>

          <div className="clear"></div>
          <Route
            path="/checkin/flightdetails"
            render={() => <FlightDetails flightData={flightData} />}
          />
          <Route
            path="/checkin/passengers"
            render={() => <Passengers passengersData={passengersData} />}
          />
        </div>
      </Router>
    </div>
  );
}
/*      <FlightDetails flightData={flightData}></FlightDetails>
 */

function FlightList(props) {
  const flights = props.flights;
  return (
    <div className="flightListLeft">
      {flights.map(flight => (
        <div
          key={flight.flightNo}
          onClick={() => props.flightOnClick(flight)}
        >{`${flight.airlinesName} : ${flight.flightNo} - ${flight.fromTo}`}</div>
      ))}
    </div>
  );
}

export default Checkin;
