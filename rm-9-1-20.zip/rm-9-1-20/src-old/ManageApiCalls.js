import { getApiCall } from "./ApiCalls";

const getCharectors = params => {
  return getApiCall(params);
};

export default getCharectors;
