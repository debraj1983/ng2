import React from "react";
import "./App.css";

import HomePage from './components/pages/Home';

function App() {
  return (
    <HomePage />
  );
}
export default App;
