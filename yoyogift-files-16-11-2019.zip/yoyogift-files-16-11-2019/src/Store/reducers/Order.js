import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.ORDER_PLACED:
      console.log(state);
      return {
        ...state,
        orderPlaced: {
          numberOfOrder:
            state && state.orderPlaced && state.orderPlaced.numberOfOrder
              ? state.orderPlaced.numberOfOrder + 1
              : 1,
          usedYoyo:
            state && state.orderPlaced && state.orderPlaced.usedYoyo
              ? state.orderPlaced.usedYoyo + action.data.yoyoPoint
              : action.data.yoyoPoint
        }
      };
    default:
      return state;
  }
};
