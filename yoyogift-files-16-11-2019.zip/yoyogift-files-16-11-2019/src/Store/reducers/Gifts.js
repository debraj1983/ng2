import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.GET_GIFT_CARDS:
      return { ...state, data: action.data };
    default:
      return state;
  }
};
