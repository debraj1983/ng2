import React from "react";
import { connect } from "react-redux";

import UserAccountView from "../Components/UserAccount/UserAccount";

class UserAccount extends React.Component {
  render() {
    return <UserAccountView userData={this.props.loginData}></UserAccountView>;
  }
}

const mapStateToProps = state => ({
  ...state
});

// const mapDispatchToProps = dispatch => ({
//   getCatList: () => dispatch(getCategoryListAction()),
//   getGiftCards: () => dispatch(getGiftCardListAction())
// });

const mapDispatchToProps = null;

export default connect(mapStateToProps, mapDispatchToProps)(UserAccount);
