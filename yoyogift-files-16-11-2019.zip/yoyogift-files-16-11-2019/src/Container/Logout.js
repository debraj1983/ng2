import React from "react";
import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

import { loginSuccessAction } from "../Store/actions/LoginAction";
import StorageUtility from "../Utility/StorageUtility";
class Logout extends React.Component {
  componentDidMount() {
    this.props.logout({});
    StorageUtility.setLogout();
    StorageUtility.setLoggedInUserData(null);
    this.props.history.push("/");
  }

  render() {
    return <div>Logging Out....</div>;
  }
}

const mapStatesWithProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  logout: payload => dispatch(loginSuccessAction(payload))
});

export default connect(
  mapStatesWithProps,
  mapDispatchToProps
)(withRouter(Logout));
