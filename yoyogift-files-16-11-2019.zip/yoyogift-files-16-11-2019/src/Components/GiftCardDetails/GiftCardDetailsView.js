import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
const GiftCardDetailsView = props => {
  const [gitfCard, setGiftCard] = useState({});
  useEffect(() => {
    const card =
      props.gifts &&
      props.gifts.data &&
      props.gifts.data.find(g => g.id.toString() === props.params.id);
    if (card) {
      setGiftCard(card);
    }
  }, [props.gifts, props.params.id]);
  return (
    <div>
      {gitfCard ? (
        <div>
          <h3>{gitfCard.cardName}</h3>
          <p>{gitfCard.cardDescription}</p>
          <p>Card Value - Rs {gitfCard.cardValue}/-</p>
          <p>Yoyo Price - {gitfCard.yoyoPoint} Points</p>
          <p>
            {props.itemAddedToCart ? (
              <>
                <input
                  type="button"
                  value="Added to Cart"
                  className="btn btn-info btn-sm"
                />
                &nbsp;&nbsp;
                <Link to="/cart" className="btn btn-info btn-sm">
                  Cart
                </Link>
              </>
            ) : (
              <input
                type="button"
                value="Add to Cart"
                className="btn btn-info btn-sm"
                onClick={() =>
                  props.addToCart({
                    cardId: gitfCard.id,
                    name: gitfCard.cardName,
                    cardValue: gitfCard.cardValue,
                    yoyoPoint: gitfCard.yoyoPoint
                  })
                }
              />
            )}
          </p>
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default GiftCardDetailsView;
