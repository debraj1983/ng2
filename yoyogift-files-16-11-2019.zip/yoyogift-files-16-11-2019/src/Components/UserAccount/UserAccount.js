import React, { useState, useEffect } from "react";

const UserAccountView = props => {
  const [userData, setUserData] = useState({});
  console.log(props);
  return (
    <>
      <div className="row mb-3">
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">My Profile</div>
            <div className="card-body">Name: </div>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">My Orders</div>
            <div className="card-body">test</div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">Transaction History</div>
            <div className="card-body">test</div>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">Add Yoyo Balance</div>
            <div className="card-body">test</div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserAccountView;
