import React from "react";
import { connect } from "react-redux";
import { getCategoryListAction } from "../Store/actions/CategoryAction";
import {
  getGiftCardListAction,
  getGiftCardSearchAction
} from "../Store/actions/GiftCardAction";
import GiftCardListMain from "../Components/GiftCardList/GiftCardListView";

class GiftCardList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      searchTxt: ""
    };
    this.changeData = this.changeData.bind(this);
    this.doSearch = this.doSearch.bind(this);
  }
  componentDidMount() {
    this.props.getCatList();
    this.props.getGiftCards();
  }

  changeData(event) {
    const { value } = event.target;
    this.setState({ searchTxt: value });
  }

  doSearch(event) {
    event.preventDefault();
    const q = this.state.searchTxt;
    console.log(q, this.state);
    this.props.getGiftSearch(q);
  }

  render() {
    return (
      <GiftCardListMain
        categories={this.props.categories}
        giftcards={this.props.giftcards}
        changeData={this.changeData}
        doSearch={this.doSearch}
      ></GiftCardListMain>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  getCatList: () => dispatch(getCategoryListAction()),
  getGiftCards: () => dispatch(getGiftCardListAction()),
  getGiftSearch: q => dispatch(getGiftCardSearchAction(q))
});

export default connect(mapStateToProps, mapDispatchToProps)(GiftCardList);
