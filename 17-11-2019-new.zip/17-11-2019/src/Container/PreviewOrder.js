import React from "react";
import { connect } from "react-redux";
import storageUtility from "../Utility/StorageUtility";
import PreviewOrderView from "../Components/PreviewOrder/PreviewOrderView";
import { updateOrderAction } from "../Store/actions/OrderAction";
import { updateUserAction } from "../Store/actions/UserAction";
import { updateYoyoTransactionAction } from "../Store/actions/OrderAction";

class PreviewOrder extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isUpdated: false
    };
    this.submitOrder = this.submitOrder.bind(this);
  }

  submitOrder() {
    const orderItems = storageUtility.getToPlaceOrder();
    const userId = this.props.loginData.loggedInData.id;
    let items = orderItems.map(oT => {
      return { ...oT, userId };
    });
    items.forEach(item => {
      this.props.updateOrder(item);
    });
  }

  checkAllSubmitted() {
    if (
      !this.state.isUpdated &&
      this.props.order &&
      this.props.order.orderPlaced &&
      this.props.order.orderPlaced.numberOfOrder &&
      this.props.order.orderPlaced.numberOfOrder ===
        storageUtility.getToPlaceOrder().length
    ) {
      this.setState(() => {
        return { isUpdated: true };
      });

      // Update User's Yoyo Balance
      const userDetails = storageUtility.getLoggedInUserData();
      userDetails.yoyoBalance =
        userDetails.yoyoBalance - this.props.order.orderPlaced.usedYoyo;
      const { id, ...userDetailsPayload } = userDetails;
      this.props.updateUser(userDetailsPayload, id);

      // Update Transaction History
      const payload = {
        userId: id,
        amount: this.props.order.orderPlaced.usedYoyo,
        transactionType: "debit"
      };
      this.props.updateYoyoTransaction(payload);
      // TODO: Need to write logic for removing cart and to Order data from session storage
      storageUtility.setCartData([]);
    }
  }

  checkOperationComplete() {
    return this.state.isUpdated;
  }

  render() {
    return (
      <>
        {this.checkAllSubmitted()}
        {this.checkOperationComplete() ? (
          this.props.history.push("/order-success")
        ) : (
          <PreviewOrderView
            toPlaceOrder={storageUtility.getToPlaceOrder()}
            submitOrder={this.submitOrder}
          ></PreviewOrderView>
        )}
      </>
    );
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  updateOrder: payload => dispatch(updateOrderAction(payload)),
  updateUser: (payload, id) => dispatch(updateUserAction(payload, id)),
  updateYoyoTransaction: payload =>
    dispatch(updateYoyoTransactionAction(payload))
});

export default connect(mapStateToProps, mapDispatchToProps)(PreviewOrder);
