import React from "react";
import { withRouter } from "react-router-dom";
import storageUtility from "../Utility/StorageUtility";
import CartView from "../Components/Cart/CartView";

class Cart extends React.Component {
  constructor(props) {
    super(props);
    this.checkAndNavigate = this.checkAndNavigate.bind(this);
  }

  checkAndNavigate() {
    if (storageUtility.checkLoggedIn()) {
      this.props.history.push("/add-information");
    } else {
      this.props.history.push("/login");
      storageUtility.setRedirectTo("/add-information");
    }
  }

  render() {
    return (
      <CartView
        cartItems={storageUtility.getCartData()}
        checkAndNavigate={this.checkAndNavigate}
      ></CartView>
    );
  }
}

export default withRouter(Cart);
