import React from "react";
import { Route, Redirect } from "react-router-dom";

export const ProtectedRouter = ({
  component: Comp,
  loggedIn,
  path,
  ...rest
}) => {
  return (
    <Route
      key={`protected${path}`}
      path={path}
      {...rest}
      render={props => {
        return loggedIn && loggedIn.loggedInData && loggedIn.loggedInData.id ? (
          <Comp {...props} />
        ) : (
          <div>Unauthorizes user</div>
        );
      }}
    />
  );
};
