import { combineReducers } from "redux";
import loginData from "./Login";
import categories from "./Categories";
import giftcards from "./Gifts";
import order from "./Order";

export default combineReducers({ loginData, categories, giftcards, order });
