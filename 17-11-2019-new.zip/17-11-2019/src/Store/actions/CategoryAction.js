import * as types from "../actionTypes";
import { getApiCall } from "../../ApiCall/apiCalls";

export const getCatSuccessAction = data => ({
  type: types.GET_CATEGORIES,
  data
});

export const getCategoryListAction = () => {
  return function(dispatch, getState) {
    return getApiCall("Category").then(data => {
      if (data && data.length > 0) {
        dispatch(getCatSuccessAction(data));
      }
    });
  };
};
