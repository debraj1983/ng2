const baseUrl = "http://localhost:3001/";

export function getApiCall(apiName) {
  return fetch(baseUrl + apiName, {
    method: "GET"
  })
    .then(handleResponse)
    .catch(handleError);
}

export function updateApiCall(apiName, payload, id) {
  return fetch(`${baseUrl}${apiName}/${id}`, {
    method: "PUT",
    body: payload,
    headers: { "Content-Type": "application/json" }
  })
    .then(handleResponse)
    .catch(handleError);
}

export function postApiCall(apiName, payload) {
  return fetch(`${baseUrl}${apiName}`, {
    method: "POST",
    body: JSON.stringify(payload),
    headers: { "Content-Type": "application/json" }
  })
    .then(handleResponse)
    .catch(handleError);
}

export function putApiCall(apiName, payload) {
  return fetch(`${baseUrl}${apiName}`, {
    method: "PUT",
    body: JSON.stringify(payload),
    headers: { "Content-Type": "application/json" }
  })
    .then(handleResponse)
    .catch(handleError);
}

export async function handleResponse(response) {
  if (response.ok) return response.json();
  if (response.status === 400) {
    // So, a server-side validation error occurred.
    // Server side validation returns a string error message, so parse as text instead of json.
    const error = await response.text();
    throw new Error(error);
  }
  throw new Error("Network response was not ok.");
}

// In a real app, would likely call an error logging service.
export function handleError(error) {
  // eslint-disable-next-line no-console
  console.error("API call failed. " + error);
  throw error;
}
