import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
const GiftCardDetailsView = props => {
  const [giftCard, setGiftCard] = useState({});
  useEffect(() => {
    const card =
      props.gifts &&
      props.gifts.data &&
      props.gifts.data.find(g => g.id.toString() === props.params.id);
    if (card) {
      setGiftCard(card);
    }
  }, [props.gifts, props.params.id]);
  return (
    <div>
      {giftCard ? (
        <div className="m-3">
          <div>
            <h3>{giftCard.cardName}</h3>
            <p>{giftCard.cardDescription}</p>
            <p>Card Value - Rs {giftCard.cardValue}/-</p>
            <p>
              {giftCard.discount > 0 ? (
                <>
                  <p>
                    Yoyo Points -{" "}
                    <span style={{ textDecoration: "line-through" }}>
                      {giftCard.actualYoyoPoint}
                    </span>
                    <br />
                    Discount - {giftCard.discount}%
                    <br />
                    Discounted Yoyo Points - {giftCard.yoyoPoint}
                  </p>
                </>
              ) : (
                <p>Yoyo Points - {giftCard.yoyoPoint}</p>
              )}
            </p>
            <p>Avg Rating: {giftCard.avgRating}</p>
            <p>
              {props.itemAddedToCart ? (
                <>
                  <input
                    type="button"
                    value="Added to Cart"
                    className="btn btn-info btn-sm"
                  />
                  &nbsp;&nbsp;
                  <Link to="/cart" className="btn btn-info btn-sm">
                    Cart
                  </Link>
                </>
              ) : (
                <input
                  type="button"
                  value="Add to Cart"
                  className="btn btn-info btn-sm"
                  onClick={() =>
                    props.addToCart({
                      cardId: giftCard.id,
                      name: giftCard.cardName,
                      cardValue: giftCard.cardValue,
                      yoyoPoint: giftCard.yoyoPoint
                    })
                  }
                />
              )}
            </p>
          </div>
          {giftCard.ratingComments && giftCard.ratingComments.length > 0 ? (
            <div>
              <h5>Reviews:</h5>
              {giftCard.ratingComments.map((rC, index) => (
                <div key={`review_${index}`} className="card mb-3">
                  <div className="card-body">
                    Rating: {rC.rating}
                    <br />
                    {rC.comments}
                    <br />
                    Posted By - {rC.postedBy}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            ""
          )}
        </div>
      ) : (
        ""
      )}
    </div>
  );
};

export default GiftCardDetailsView;
