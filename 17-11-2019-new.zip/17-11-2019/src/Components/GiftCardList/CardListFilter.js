import React from "react";
import Checkbox from "./Checkbox";

const CardListFilter = props => {
  const cat = props.categoryData;
  return (
    <div className="filterBlock">
      <h6>Categories</h6>
      <ul>
        {cat &&
          cat.length > 0 &&
          cat.map((c, index) => (
            <li key={`cat${c.id}_${index}`}>
              <Checkbox
                id={c.id}
                index={index}
                subIndex="-1"
                checked={c.checked}
                isSelect={props.isSelectCategory}
                label={c.name}
                value={`${index}_-1`}
              />
              <ul>
                {c.subCategory &&
                  c.subCategory.length &&
                  c.subCategory.map((sC, subIndex) => (
                    <li key={`cat${sC.id}_${index}_${subIndex}`}>
                      <Checkbox
                        id={sC.id}
                        index={index}
                        subIndex={subIndex}
                        checked={sC.checked}
                        isSelect={props.isSelectCategory}
                        label={sC.name}
                        value={`${index}_${subIndex}`}
                      />
                    </li>
                  ))}
              </ul>
            </li>
          ))}
      </ul>
      <h6>Price Range</h6>
      <ul>
        {props.priceFilter.map((pF, index) => (
          <li key={`pricekey${index}`}>
            <Checkbox
              id={`id_${pF.id}`}
              index={index}
              checked={pF.checked}
              isSelect={props.isSelectPrice}
              label={`Price ${pF.startRange} - ${pF.endRange}`}
              value={`${pF.startRange}_${pF.endRange}`}
            />
          </li>
        ))}
      </ul>
      <h6>Dicount</h6>
      <ul>
        {props.discoutFilter.map((pF, index) => (
          <li key={`pricekey${index}`}>
            <Checkbox
              id={`id_${pF.id}`}
              index={index}
              checked={pF.checked}
              isSelect={props.isDiscout}
              label={`${pF.discount}%`}
              value={pF.discount}
            />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default CardListFilter;
