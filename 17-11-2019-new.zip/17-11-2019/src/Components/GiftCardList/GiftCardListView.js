import React, { useState, useEffect } from "react";
import CardListFilter from "./CardListFilter";
import GiftList from "./GiftList";
import { PriceFilter, DiscoutFilter } from "../../AppConstant";

const GiftCardListMain = props => {
  // States
  const [categories, setCategories] = useState([]);
  const [gifts, setGifts] = useState(null);
  const [priceFilter, setPriceFilter] = useState(PriceFilter);
  const [discoutFilter, setDiscoutFilter] = useState(DiscoutFilter);

  // Effects
  useEffect(() => {
    setCategories(props.categories.data);
    setGifts(props.giftcards.data);
  }, [props.categories.data, props.giftcards.data]);

  // Changing value of "checked" in category array
  const isSelectCategory = event => {
    const toModify = [...categories]; // Assign all the category values

    const { value, checked } = event.target; // Get value and checked attribute from checkbox
    const [catPos, subCatPos] = value.split("_");
    const catIndex = parseInt(catPos);
    if (subCatPos === "-1") {
      toModify[catIndex]["checked"] = checked;
      let subCat = toModify[catIndex].subCategory.map(sC => {
        sC["checked"] = checked;
        return sC;
      });
      toModify[catIndex].subCategory = [...subCat];
    } else {
      const subCatIndex = parseInt(subCatPos);
      toModify[catIndex].subCategory[subCatIndex]["checked"] = checked;
      const isAllChecked = toModify[catIndex].subCategory.find(
        elem => elem.checked === false
      );
      if (!isAllChecked) {
        toModify[catIndex]["checked"] = true;
      } else {
        toModify[catIndex]["checked"] = false;
      }
    }
    setCategories(toModify);
    filterGiftsFn();
  };

  // Changing value of "checked" in priceFilter array
  const isSelectPrice = event => {
    const { value, checked } = event.target;
    const toModify = [...priceFilter];

    let modifiedPriceFilter = toModify.map(price => {
      if (price.startRange + "_" + price.endRange === value)
        price["checked"] = checked;
      return price;
    });

    setPriceFilter(modifiedPriceFilter);
    filterGiftsFn();
  };

  // Changing value of "checked" in priceFilter array
  const isDiscout = event => {
    const { value, checked } = event.target;
    const toModify = [...discoutFilter];

    let modifiedDiscoutFilter = toModify.map(disc => {
      if (disc.discount === parseInt(value)) {
        disc["checked"] = checked;
      }
      return disc;
    });

    setDiscoutFilter(modifiedDiscoutFilter);
    filterGiftsFn();
  };

  const filterGiftsFn = () => {
    let hasFilterOptions = false;

    // Check any category selected or not
    const subCatIds = [];
    categories.forEach(element => {
      element.subCategory.forEach(elem => {
        if (elem.checked) {
          subCatIds.push(elem.id);
        }
      });
    });

    // Check any price range selected or not
    let toFilter = priceFilter.filter(price => price.checked === true);

    // Check any discount selected or not
    let toDiscountFilter = discoutFilter.filter(disc => disc.checked === true);

    let needToFilter = [];
    if (subCatIds.length > 0) {
      needToFilter.push({
        filter: "category",
        condition: gift => subCatIds.includes(gift.subCatId)
      });
    }

    if (toFilter.length > 0) {
      needToFilter.push({
        filter: "price",
        condition: gift =>
          toFilter.find(tF => {
            const { startRange, endRange, ...rest } = tF;
            return gift.yoyoPoint >= startRange && gift.yoyoPoint <= endRange;
          })
      });
    }

    if (toDiscountFilter.length > 0) {
      needToFilter.push({
        filter: "discount",
        condition: gift =>
          toDiscountFilter.find(tDF => {
            return gift.discount === tDF.discount;
          })
      });
    }

    let filteredGifts = [...props.giftcards.data];
    if (needToFilter.length > 0) {
      /* 
       // Tried 2
      needToFilter.forEach(elem => {
        filteredGifts = filteredGifts.filter(gift => elem.condition(gift));
        hasFilterOptions = true;
      });
    */

      // Final code
      filteredGifts = filteredGifts.filter(gift => {
        let hasTrue = true;
        needToFilter.forEach(elem => {
          if (!elem.condition(gift)) {
            hasTrue = false;
          }
        });
        if (hasTrue) {
          return gift;
        }
      });
      hasFilterOptions = true;
    }

    /*
    // Tried 1
    let filteredGifts = [];
    if (subCatIds.length > 0 && toFilter.length > 0) {
      filteredGifts = props.giftcards.data.filter(
        gift =>
          subCatIds.includes(gift.subCatId) &&
          toFilter.find(tF => {
            const { startRange, endRange, ...rest } = tF;
            return gift.yoyoPoint >= startRange && gift.yoyoPoint <= endRange;
          })
      );
      hasFilterOptions = true;
    } else if (subCatIds.length > 0) {
      filteredGifts = props.giftcards.data.filter(gift =>
        subCatIds.includes(gift.subCatId)
      );
      hasFilterOptions = true;
    } else if (toFilter.length > 0) {
      filteredGifts = props.giftcards.data.filter(gift => {
        return toFilter.find(tF => {
          const { startRange, endRange } = tF;
          return gift.yoyoPoint >= startRange && gift.yoyoPoint <= endRange;
        });
      });
      hasFilterOptions = true;
    }
*/
    if (hasFilterOptions) {
      setGifts(filteredGifts);
    } else {
      setGifts(props.giftcards.data);
    }
  };

  return (
    <>
      <div className="text-left">
        <div className="d-flex flex-row row">
          <div className="col-lg-3 col-md-4 col-sm-12 pl-5">
            <CardListFilter
              categoryData={categories}
              priceFilter={priceFilter}
              discoutFilter={discoutFilter}
              isSelectCategory={isSelectCategory}
              isSelectPrice={isSelectPrice}
              isDiscout={isDiscout}
            ></CardListFilter>
          </div>
          <div className="col-lg-9 col-md-8 col-sm-12">
            <GiftList
              gifts={gifts}
              changeData={props.changeData}
              doSearch={props.doSearch}
            ></GiftList>
          </div>
        </div>
      </div>
    </>
  );
};

export default GiftCardListMain;
