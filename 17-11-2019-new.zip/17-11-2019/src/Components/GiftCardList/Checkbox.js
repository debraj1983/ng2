import React from "react";

const Checkbox = props => {
  return (
    <>
      <input
        key={`checkbox${[props.id, props.index, props.subIndex].join("_")}`}
        id={`id_checkbox${[props.id, props.index, props.subIndex].join("_")}`}
        type="checkbox"
        name="name[]"
        value={props.value}
        checked={props.checked}
        onChange={props.isSelect}
      />{" "}
      <label
        htmlFor={`id_checkbox${[props.id, props.index, props.subIndex].join(
          "_"
        )}`}
      >
        {props.label}
      </label>
    </>
  );
};

export default Checkbox;
