import React from "react";
import GiftCard from "./GiftCard";

const GiftList = props => {
  return (
    <>
      <div className="d-flex flex-row-reverse">
        <form onSubmit={props.doSearch}>
          <input type="text" name="search" onChange={props.changeData} />
          <button type="submit">Search</button>
        </form>
      </div>
      <div className="d-flex flex-row row  mt-1">
        {props.gifts &&
          props.gifts.length > 0 &&
          props.gifts.map((gift, index) => (
            <GiftCard pos={index} gift={gift} key={`card${index}`}></GiftCard>
          ))}

        {props.gifts && props.gifts.length === 0 ? (
          <div className="w-100 mt-1 alert alert-danger" role="alert">
            No Gift Card Found
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
};

export default GiftList;
