import React, { useState, useEffect } from "react";
import UserProfile from "./UserProfile";
import OrderHistory from "./OrderHistory";
import TransactionHistory from "./TransactionHistory";
import AddYoyoBalance from "./AddYoyoBalance";

const UserAccountView = props => {
  const [userData, setUserData] = useState({});
  const [orderHistory, setOrderHistory] = useState([]);
  const [transactionHistory, setTransactionHistory] = useState([]);
  useEffect(() => {
    setUserData(props.userData.loggedInData);
    setOrderHistory(props.order.orderHistory);
    setTransactionHistory(props.order.userTransactionHistory);
  }, [
    props.userData.loggedInData,
    props.order.orderHistory,
    props.order.transactionHistory,
    props.order.userTransactionHistory
  ]);

  return (
    <>
      <div className="row mb-3">
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">My Profile</div>
            <div className="card-body ua-max-height">
              <UserProfile userData={userData}></UserProfile>
            </div>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">Add Yoyo Balance</div>
            <div className="card-body ua-max-height">
              <AddYoyoBalance
                validateAndUpdateYoyo={props.validateAndUpdateYoyo}
                addedStatus={props.addedStatus}
                changeData={props.changeData}
              ></AddYoyoBalance>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">Transaction History</div>
            <div className="card-body ua-max-height">
              <TransactionHistory
                transactionHistory={transactionHistory}
              ></TransactionHistory>
            </div>
          </div>
        </div>
        <div className="col-lg-6 col-md-6 col-sm-12">
          <div className="card">
            <div className="card-header">My Orders</div>
            <div className="card-body ua-max-height">
              <OrderHistory orderHistory={orderHistory}></OrderHistory>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default UserAccountView;
