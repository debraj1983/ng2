import React from "react";

const AddYoyoBalance = props => {
  return (
    <form onSubmit={props.validateAndUpdateYoyo}>
      {props.addedStatus && props.addedStatus === "invalid" ? (
        <div className="alert alert-danger">Invalid Code</div>
      ) : (
        <>
          {props.addedStatus && props.addedStatus === "success" ? (
            <div className="alert alert-success">Coupon Successfully Added</div>
          ) : (
            ""
          )}
        </>
      )}
      <div className="form-group">
        <input
          type="text"
          className="form-control w-50"
          name="yoyocode"
          id="entercode"
          placeholder="Enter Yoyo Code"
          onChange={props.changeData}
        />
      </div>
      <button type="submit" className="btn btn-primary">
        Submit
      </button>
    </form>
  );
};

export default AddYoyoBalance;
