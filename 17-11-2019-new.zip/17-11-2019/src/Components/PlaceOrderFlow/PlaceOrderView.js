import React, { useState, useEffect } from "react";
import { Link, Redirect } from "react-router-dom";
import storageUtility from "../../Utility/StorageUtility";

const PlaceOrderView = props => {
  const [formElementData, setFormElementData] = useState([]);
  const [yoyoBalance, setYoyoBalance] = useState(0);
  const [previewOrder, setPreviewOrder] = useState(false);

  useEffect(() => {
    if (props.addedItems && props.addedItems.length > 0) {
      let modifiedCart = props.addedItems.map(item => {
        return { ...item, friendName: "", friendEmail: "" };
      });
      setFormElementData(modifiedCart);
    }

    if (
      props.userData &&
      props.userData.loggedInData &&
      props.userData.loggedInData.yoyoBalance
    ) {
      setYoyoBalance(props.userData.loggedInData.yoyoBalance);
    }
  }, [props.addedItems, props.userData]);

  const changeData = event => {
    const { name, value } = event.target;
    const splittedName = name.split("_");
    const cartObj = [...formElementData];
    cartObj[parseInt(splittedName[1])][splittedName[0]] = value;
    setFormElementData(cartObj);
  };

  const placeOrder = () => {
    const d = formElementData.find(
      elem => elem.friendName === "" || elem.friendEmail === ""
    );
    if (!d) {
      storageUtility.setToPlaceOrder(formElementData);
      setPreviewOrder(true);
      // props.history.push("/preview-order");
    } else {
      alert("Please fillup the information");
    }
  };

  const getTotalCartValue = () => {
    let total = 0;
    formElementData.forEach(eachElem => {
      total += parseInt(eachElem.yoyoPoint);
    });
    return total;
  };
  return (
    <div className="w-75 mx-auto">
      {previewOrder ? <Redirect to="/preview-order" /> : ""}
      <h4>Enter Details to Continue</h4>
      <table className="table">
        <thead className="thead-light">
          <tr>
            <th scope="col" width="25%">
              Item Details
            </th>
            <th scope="col">Friend Details</th>
          </tr>
        </thead>
        <tbody>
          {props.addedItems && props.addedItems.length > 0 ? (
            props.addedItems.map((item, index) => (
              <tr key={`itemsRow${index}`}>
                <td>
                  Name: {item.name}
                  <br />
                  Amount: {item.cardValue}
                  <br />
                  Yoyo: {item.yoyoPoint}
                </td>
                <td>
                  <div className="mb-2">
                    <input
                      type="text"
                      name={`friendName_${index}`}
                      required
                      className="form-control w-50"
                      placeholder="Enter Friend's Name"
                      onChange={changeData}
                    />
                  </div>
                  <div>
                    <input
                      type="email"
                      name={`friendEmail_${index}`}
                      required
                      className="form-control w-50"
                      placeholder="Enter Friend's Email"
                      onChange={changeData}
                    />
                  </div>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" className="alert alert-danger"></td>
            </tr>
          )}
        </tbody>
      </table>
      {props.addedItems && props.addedItems.length > 0 ? (
        <>
          {" "}
          {getTotalCartValue() > yoyoBalance ? (
            <>
              <span className="text-danger">
                Your cart total is <strong>{getTotalCartValue()}</strong> which
                is more than your yoyo balance. Kindly back to your cart and
                modify your order.
              </span>
              <br />
              <Link to="/cart" className="btn btn-info btn-sm">
                Back to Cart
              </Link>
            </>
          ) : (
            <input
              type="button"
              value="Continue"
              className="btn btn-info btn-sm"
              onClick={() => placeOrder()}
            />
          )}
          &nbsp;&nbsp;
          <Link to="/gift-card-list" className="btn btn-info btn-sm">
            Shop More
          </Link>
        </>
      ) : (
        ""
      )}
    </div>
  );
};

export default PlaceOrderView;
