import React, { useState, useEffect } from "react";

const PreviewOrderView = props => {
  const [orderItems, setOrderItems] = useState([]);
  useEffect(() => {
    setOrderItems(props.toPlaceOrder);
  }, [props.toPlaceOrder]);

  return (
    <div className="m-5">
      <div className="row">
        {orderItems.map((item, index) => (
          <div
            className="col-lg-4 col-md-6 col-sm-12 mb-3 pl-0"
            key={index.toString()}
          >
            <div className="card">
              <div className="card-header">Yoyo gift card</div>
              <div className="card-body">
                <h5 className="card-title">{item.name}</h5>
                <h6 className="card-subtitle mb-2 text-muted">
                  {item.cardValue} INR
                </h6>
                <p className="card-text">
                  Friend's Name: {item.friendName}
                  <br />
                  Friend's Email: {item.friendEmail}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
      <div className="row">
        <input
          type="button"
          value="Place Order"
          className="btn btn-info btn-sm"
          onClick={() => props.submitOrder()}
        />
      </div>
    </div>
  );
};

export default PreviewOrderView;
