import React from "react";
import "./App.css";
import AppRouter from "./AppRouter";

function App() {
  console.log(process.env);
  return (
    <>
      <AppRouter></AppRouter>
    </>
  );
}

export default App;
