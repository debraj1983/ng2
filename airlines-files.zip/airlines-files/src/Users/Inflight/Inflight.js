import React from "react";

class Inflight extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>Inflight Component Working</div>;
  }
}

export default Inflight;
