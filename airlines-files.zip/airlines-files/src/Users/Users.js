import React from "react";
import { Route, withRouter } from "react-router-dom";

import Admin from "./Admin/Admin";
import Checkin from "./Checkin/Checkin";
import Inflight from "./Inflight/Inflight";
import FlightDetails from "./Admin/FightDetails";

class Users extends React.Component {
  constructor(props) {
    super(props);
    const { userData } = props;
    this.userData = userData;

    const path = this.isAdmin()
      ? "/admin"
      : this.isCheckin()
      ? "/checkin"
      : "/inflight";
    props.history.push(path);
  }

  isAdmin = () =>
    this.userData.role === "admin" && this.userData.type === "admin";

  isCheckin = () =>
    this.userData.role === "staff" && this.userData.type === "checkin";

  isInflight = () =>
    this.userData.role === "staff" && this.userData.type === "inflight";

  render() {
    return (
      <>
        <Route path="/admin" component={Admin} />
        <Route path="/admin/manage-flights/:id" component={FlightDetails} />
        <Route path="/checkin" cmponent={Checkin} />
        <Route path="/inflight" coomponent={Inflight} />
      </>
    );
  }
}

export default withRouter(Users);
