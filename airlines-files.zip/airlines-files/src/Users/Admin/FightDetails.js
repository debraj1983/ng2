import React, { useState } from "react";
import PassengerList from "./PassengerList";
import Filter from "./Filter";
import EditUser from "./EditUsers";

import { updateFlightData } from "../../Store/actions/FlightAction";

const FlightDetails = props => {
  const [passenger, setPassenger] = useState(props.flight.Passengers);
  const [editUserDetails, setEditUserDetails] = useState(undefined);

  const filterOption = {};

  const setFilterOptions = event => {
    const { name, value } = event.target;
    filterOption[name] = value;
  };

  const onFilter = () => {
    let filtered = [...props.flight.Passengers];
    for (const property in filterOption) {
      console.log(property);
      if (property === "passengerName") {
        const filteredArr = filtered.filter(
          p => p[property].indexOf(filterOption[property]) !== -1
        );
        filtered = [...filteredArr];
      } else {
        const filteredArr =
          filterOption[property] && filterOption[property] === "Y"
            ? filtered.filter(p => p[property] !== "")
            : filterOption[property] && filterOption[property] === "N"
            ? filtered.filter(p => p[property] === "")
            : [...filtered];
        filtered = [...filteredArr];
      }
    }
    setPassenger(filtered);
  };

  const editPassenger = (passenger, pos) => {
    setEditUserDetails({ flightId: props.flight.id, pos, passenger });
  };

  const closeEdit = () => {
    setEditUserDetails(undefined);
  };

  const handleChange = event => {
    const { name, value } = event.target;
    editUserDetails.passenger[name] = value;
    setEditUserDetails({ ...editUserDetails });
  };

  const handleUpdatePassengerDetails = event => {
    event.preventDefault();
    const flightDetails = props.flight;
    flightDetails.Passengers[editUserDetails.pos] = editUserDetails.passenger;
    console.log(flightDetails);
    updateFlightData(flightDetails, editUserDetails.flightId);
  };

  return (
    <div className="text-left">
      <div className="d-flex flex-row row">
        <div className="col-lg-3 col-md-4 col-sm-12 pl-5">
          <h4>{`${props.flight.airlinesName}-${props.flight.flightNo}`}</h4>
          <p>Flight Route - {props.flight.fromTo}</p>
          <p>Departure Time - {props.flight.departureTime}</p>
          <p>Arrival Time - {props.flight.arrivalTime}</p>
          <p>
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => props.backToDashboard()}
            >
              Back to Dashboard
            </button>
          </p>
          <Filter
            setFilterOptions={setFilterOptions}
            onFilter={onFilter}
          ></Filter>
        </div>
        <div className="col-lg-9 col-md-8 col-sm-12">
          <PassengerList
            passengers={passenger}
            editPassenger={editPassenger}
          ></PassengerList>
        </div>
      </div>
      {editUserDetails ? (
        <EditUser
          editUserDetails={editUserDetails}
          closeEdit={closeEdit}
          changeData={handleChange}
          updatePassengerDetails={handleUpdatePassengerDetails}
        ></EditUser>
      ) : (
        ""
      )}
    </div>
  );
};

export default FlightDetails;
