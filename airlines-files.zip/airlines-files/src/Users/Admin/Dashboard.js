import React from "react";

const Dashboard = props => {
  return (
    <div className="d-flex flex-row row">
      {props.flights &&
        props.flights.map(flight => (
          <div
            className="col-lg-4 col-md-6 col-sm-12 mx-auto mt-5"
            key={flight.id.toString()}
          >
            <div className="card text-left">
              <div className="card-header">{`${flight.airlinesName}-${flight.flightNo}`}</div>
              <div className="card-body">
                <p>Flight Route - {flight.fromTo}</p>
                <p>Departure Time - {flight.departureTime}</p>
                <p>Arrival Time - {flight.arrivalTime}</p>
                <p>
                  <button
                    type="button"
                    className="btn btn-primary"
                    onClick={() => props.navigateToPage(flight.id)}
                  >
                    Flight Details
                  </button>
                </p>
              </div>
            </div>
          </div>
        ))}
    </div>
  );
};

export default Dashboard;
