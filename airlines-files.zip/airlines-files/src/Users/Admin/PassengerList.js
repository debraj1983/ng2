import React from "react";

const PassengerList = props => {
  return (
    <>
      <table className="table">
        <thead className="thead-light">
          <tr>
            <th scope="col">Passenger Name</th>
            <th>Passport</th>
            <th scope="col">Infant</th>
            <th scope="col">Seat No</th>
            <th scope="col">Checked In</th>
            <th scope="col">Wheel Chair</th>
            <th scope="col">Meal</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          {props.passengers.map((passenger, index) => (
            <tr key={index.toString()}>
              <td>{passenger.passengerName}</td>
              <td>{passenger.passport}</td>
              <td>{passenger.hasInfant ? "Yes" : "No"}</td>
              <td>{passenger.seatNo}</td>
              <td>{passenger.checkedIn ? "Yes" : "No"}</td>
              <td>{passenger.hasWheelChair ? "Yes" : "No"}</td>
              <td>
                {passenger.hasMealOption
                  ? passenger.mealType === "veg"
                    ? "Veg"
                    : "Non Veg"
                  : "NA"}
              </td>
              <td>
                <button
                  type="button"
                  className="btn btn-primary btn-sm"
                  onClick={() => props.editPassenger(passenger, index)}
                >
                  Edit
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
};

export default PassengerList;
