import React from "react";
import { connect } from "react-redux";
import { getFlightDetails } from "../../Store/actions/FlightAction";

import ManageAdmin from "./ManageAdmin";

class Admin extends React.Component {
  constructor(props) {
    super(props);
    props.getFlightDetails();
    this.props = props;
  }

  render() {
    return <ManageAdmin flights={this.props.flightData.flights} />;
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  getFlightDetails: () => dispatch(getFlightDetails())
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Admin);
