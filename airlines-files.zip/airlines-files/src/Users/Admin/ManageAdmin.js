import React, { useState } from "react";
import Dashboard from "./Dashboard";
import FlightDetails from "./FightDetails";

const ManageAdmin = props => {
  const [flightId, setFlightId] = useState(0);
  const [flight, setFlight] = useState(undefined);
  const assignFlightID = id => {
    setFlightId(id);

    // Set state for flight details
    const flightData = props.flights.find(flight => flight.id === id);
    setFlight(flightData);
  };

  const backToDashboard = () => {
    setFlightId(0);
    setFlight(undefined);
  };

  return (
    <>
      {flightId === 0 ? (
        <Dashboard flights={props.flights} navigateToPage={assignFlightID} />
      ) : (
        <FlightDetails flight={flight} backToDashboard={backToDashboard} />
      )}
    </>
  );
};

export default ManageAdmin;
