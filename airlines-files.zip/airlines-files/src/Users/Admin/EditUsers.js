import React from "react";

const EditUser = props => {
  return (
    <div>
      <div className="editPopup">
        <form onSubmit={props.updatePassengerDetails} className="m-1">
          <div className="form-group">
            <label htmlFor="passengerName">Passenger name</label>
            <input
              type="text"
              className="form-control"
              id="passengerName"
              name="passengerName"
              placeholder=""
              onChange={props.changeData}
              value={props.editUserDetails.passenger.passengerName}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="dob">DOB</label>
            <input
              type="text"
              className="form-control"
              id="dob"
              name="dob"
              placeholder=""
              onChange={props.changeData}
              value={props.editUserDetails.passenger.dob}
            />
          </div>
          <div className="form-group">
            <label htmlFor="passport">Passport</label>
            <input
              type="text"
              className="form-control"
              id="passport"
              name="passport"
              placeholder=""
              onChange={props.changeData}
              value={props.editUserDetails.passenger.passport}
            />
          </div>
          <div className="form-group">
            <label htmlFor="address">Address</label>
            <input
              type="text"
              className="form-control"
              id="address"
              name="address"
              placeholder=""
              onChange={props.changeData}
              value={props.editUserDetails.passenger.address}
            />
          </div>
          <div className="form-group">
            <label htmlFor="address">Meal:</label>
            {"   "}
            <input
              type="radio"
              onChange={props.changeData}
              name="mealType"
              value="veg"
              checked={
                props.editUserDetails.passenger.mealType === "veg"
                  ? "checked"
                  : ""
              }
            />
            Veg Meal{" "}
            <input
              type="radio"
              onChange={props.changeData}
              name="mealType"
              value="nonveg"
              checked={
                props.editUserDetails.passenger.mealType === "nonveg"
                  ? "checked"
                  : ""
              }
            />
            Nonveg Meal{" "}
          </div>
          <div className="form-group">
            <button type="submit" className="btn btn-primary">
              Update
            </button>
            {"  "}
            <button
              onClick={() => props.closeEdit()}
              className="btn btn-danger"
            >
              Close
            </button>
          </div>
        </form>
      </div>
      <div className="overlay" onClick={() => props.closeEdit()}></div>
    </div>
  );
};

export default EditUser;
