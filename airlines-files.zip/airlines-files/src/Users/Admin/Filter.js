import React from "react";

const Filter = props => {
  return (
    <div>
      <h4>Fliter Passenger</h4>
      <input
        type="text"
        onChange={props.setFilterOptions}
        name="passengerName"
        id="passengerName"
        placeholder="Name"
      />
      <p>
        Passport:
        <input
          type="radio"
          onChange={props.setFilterOptions}
          name="passport"
          value="Y"
        />
        Yes{" "}
        <input
          type="radio"
          onChange={props.setFilterOptions}
          name="passport"
          value="N"
        />
        No{" "}
      </p>
      <p>
        Address:
        <input
          type="radio"
          onChange={props.setFilterOptions}
          name="address"
          value="Y"
        />
        Yes{" "}
        <input
          type="radio"
          onChange={props.setFilterOptions}
          name="address"
          value="N"
        />
        No{" "}
      </p>
      <p>
        Date of birth:
        <input
          type="radio"
          onChange={props.setFilterOptions}
          name="dob"
          value="Y"
        />
        Yes{" "}
        <input
          type="radio"
          onChange={props.setFilterOptions}
          name="dob"
          value="N"
        />
        No{" "}
      </p>
      <p>
        <button
          type="button"
          className="btn btn-primary"
          onClick={props.onFilter}
        >
          Filter
        </button>
      </p>
    </div>
  );
};

export default Filter;
