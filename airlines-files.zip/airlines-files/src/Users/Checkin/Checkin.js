import React from "react";
import { connect } from "react-redux";

class Checkin extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>Checkin Component Working</div>;
  }
}

const mapStateToProps = state => ({
  ...state
});

/*
const mapDispatchToProps = dispatch => ({
  getFlightDetails: () => dispatch(getFlightDetails())
});*/
const mapDispatchToProps = null;

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Checkin);
