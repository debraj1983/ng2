import * as types from "../actionTypes";
import { getApiCall } from "../../ApiCall/apiCalls";
import { updateApiCall } from "../../ApiCall/apiCalls";

export const flightDataLoadSuccessAction = data => ({
  type: types.FLIGHT_DATA_LOADED,
  data
});

export const flightDataLoadFailedAction = data => ({
  type: types.FLIGHT_DATA_LOAD_FAILED,
  data
});

export const getFlightDetails = () => {
  return function(dispatch, getState) {
    return getApiCall("FlightData").then(data => {
      if (data && data.length > 0) {
        dispatch(flightDataLoadSuccessAction(data));
      } else {
        dispatch(flightDataLoadFailedAction({ dataLoad: false }));
      }
    });
  };
};

export const updateFlightData = (payload, id) => {
  return updateApiCall("FlightData", payload, id).then(data => {
    console.log(data);
    /*if (data && data.length > 0) {
      dispatch(flightDataLoadSuccessAction(data));
    } else {
      dispatch(flightDataLoadFailedAction({ dataLoad: false }));
    }*/
  });
};
