import * as types from "../actionTypes";
import { getApiCall } from "../../ApiCall/apiCalls";
import storageUtility from "../../Utility/StorageUtility";

export const loginSuccessAction = data => ({
  type: types.LOGIN_SUCCESS,
  data
});

export const loginFailedAction = data => ({
  type: types.LOGIN_FAILED,
  data
});

export const doLoginAction = payload => {
  return function(dispatch, getState) {
    return getApiCall("Users").then(data => {
      const user = data.find(
        elem =>
          elem.userId === payload.loginId && elem.password === payload.password
      );
      if (user) {
        const uData = {
          loggedIn: true,
          id: user.id,
          name: user.userId,
          role: user.role,
          type: user.type
        };
        storageUtility.setLoggedIn();
        storageUtility.setLoggedInUserData({
          id: user.id,
          name: user.userId,
          role: user.role,
          type: user.type
        });
        dispatch(loginSuccessAction(uData));
      } else {
        dispatch(loginFailedAction({ loginFailed: true }));
      }
    });
  };
};
