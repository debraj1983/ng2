import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.FLIGHT_DATA_LOADED:
      return { ...state, flights: action.data };
    default:
      return state;
  }
};
