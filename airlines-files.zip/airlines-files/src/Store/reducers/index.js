import { combineReducers } from "redux";
import loginData from "./Login";
import flightData from "./Flight";

export default combineReducers({ loginData, flightData });
