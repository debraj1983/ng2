import * as types from "../actionTypes";

export default (state = {}, action) => {
  switch (action.type) {
    case types.LOGIN_SUCCESS:
      return { ...state, loggedInData: action.data };
    case types.LOGIN_FAILED:
      return { ...state, loggedInData: action.data };
    default:
      return state;
  }
};
