import React from "react";
import "./App.scss";
import utility from "./Utility/StorageUtility";
import { connect } from "react-redux";
import Login from "./Login/Login";
import Users from "./Users/Users";
import { BrowserRouter as Router } from "react-router-dom";

class App extends React.Component {
  checkLoggedIn = () => {
    if (
      utility.checkLoggedIn() ||
      (this.props.loginData &&
        this.props.loginData.loggedInData &&
        this.props.loginData.loggedInData.loggedIn)
    ) {
      return true;
    }
    return false;
  };

  getLoggedInUserData = () => {
    return (
      utility.getLoggedInUserData() ||
      this.props.loginData.loggedInData.loggedIn
    );
  };

  render() {
    return (
      <div className="App">
        {this.checkLoggedIn() ? (
          <Router>
            <Users userData={this.getLoggedInUserData()} />
          </Router>
        ) : (
          <Login />
        )}
      </div>
    );
  }
}

const mapStateToProps = state => ({
  loginData: state.loginData
});

export default connect(
  mapStateToProps,
  null
)(App);
