// Data for Users
const Users = [
  {
    id: 1,
    emailId: "admin@yoyogift.com",
    password: "asd",
    role: "admin"
  },
  {
    id: 2,
    emailId: "user1@gmail.com",
    password: "asd",
    firstName: "FN User 1",
    lastName: "LN User 1",
    address: {
      address1: "Address 1",
      address2: "Address 2",
      city: "City 1",
      state: "State 1",
      zip: "123456"
    },
    yoyoBalance: 1000,
    role: "user"
  },
  {
    id: 3,
    emailId: "user3@gmail.com",
    password: "asd",
    firstName: "FN User 2",
    lastName: "LN User 2",
    address: {
      address1: "Address 1",
      address2: "Address 2",
      city: "City 1",
      state: "State 1",
      zip: "123456"
    },
    yoyoBalance: 900,
    role: "user"
  }
];

const YoyoPaymentHistory = [
  {
    id: 1,
    userId: 2,
    amount: 1000,
    transactionType: "credit"
  },
  {
    id: 2,
    userId: 3,
    amount: 1500,
    transactionType: "credit"
  },
  {
    id: 3,
    userId: 2,
    amount: 600,
    transactionType: "debit"
  }
];

const UsersOrder = [];

const Category = [
  {
    id: 1,
    name: "Ecommerce",
    parentId: 0
  },
  {
    id: 2,
    name: "Entertainment",
    parentId: 0
  },
  {
    id: 3,
    name: "Travel and hospitality",
    parentId: 0
  },
  {
    id: 4,
    name: "Health and beauty"
  },
  {
    id: 5,
    name: "Food and beverages",
    parentId: 0
  },
  {
    id: 6,
    parentId: 1,
    name: "Amazon"
  },
  {
    id: 7,
    parentId: 1,
    name: "Myntra"
  },
  {
    id: 8,
    parentId: 2,
    name: "BookmyShow"
  },
  {
    id: 9,
    parentId: 2,
    name: "Saavn"
  },
  {
    id: 10,
    parentId: 3,
    name: "MakeMytrip"
  },
  {
    id: 11,
    parentId: 3,
    name: "tripadvisor api"
  },
  {
    id: 12,
    parentId: 4,
    name: "Lakme salon"
  },
  {
    id: 13,
    parentId: 4,
    name: "VLCC"
  },
  {
    id: 14,
    parentId: 5,
    name: "KFC"
  },
  {
    id: 15,
    parentId: 5,
    name: "McDonald"
  }
];

const GiftCards = [
  {
    id: 1,
    catId: 1,
    subCatId: 6,
    cardName: "Amazon GC 2000",
    cardDescription: "Amazon Gift Card 2000",
    cardValue: 2000,
    yoyoPoint: 600,
    avgRating: 4,
    ratingComments: [
      {
        id: 1,
        rating: 5,
        comments: "This is good gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 2,
        rating: 3,
        comments: "This is ok type gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 3,
        rating: 4,
        comments: "Good One",
        postedBy: "Anynomous User"
      },
      {
        id: 4,
        rating: 4,
        comments: "Rocking...",
        postedBy: "Anynomous User"
      }
    ]
  },
  {
    id: 2,
    catId: 1,
    subCatId: 6,
    cardName: "Amazon GC 5000",
    cardDescription: "Amazon Gift Card 5000",
    cardValue: 5000,
    yoyoPoint: 1500,
    avgRating: 4,
    ratingComments: [
      {
        id: 1,
        rating: 5,
        comments: "This is good gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 2,
        rating: 3,
        comments: "This is ok type gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 3,
        rating: 4,
        comments: "Good One",
        postedBy: "Anynomous User"
      },
      {
        id: 4,
        rating: 4,
        comments: "Rocking...",
        postedBy: "Anynomous User"
      }
    ]
  },
  {
    id: 3,
    catId: 1,
    subCatId: 7,
    cardName: "Myntra GC 2000",
    cardDescription: "Myntra Gift Card 2000",
    cardValue: 2000,
    yoyoPoint: 600,
    avgRating: 4,
    ratingComments: [
      {
        id: 1,
        rating: 5,
        comments: "This is good gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 2,
        rating: 3,
        comments: "This is ok type gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 3,
        rating: 4,
        comments: "Good One",
        postedBy: "Anynomous User"
      },
      {
        id: 4,
        rating: 4,
        comments: "Rocking...",
        postedBy: "Anynomous User"
      }
    ]
  },
  {
    id: 4,
    catId: 2,
    subCatId: 8,
    cardName: "BMS 100",
    cardDescription: "Book My Show Gift Card 100",
    cardValue: 100,
    yoyoPoint: 30,
    avgRating: 4,
    ratingComments: [
      {
        id: 1,
        rating: 5,
        comments: "This is good gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 2,
        rating: 3,
        comments: "This is ok type gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 3,
        rating: 4,
        comments: "Good One",
        postedBy: "Anynomous User"
      },
      {
        id: 4,
        rating: 4,
        comments: "Rocking...",
        postedBy: "Anynomous User"
      }
    ]
  },
  {
    id: 5,
    catId: 2,
    subCatId: 8,
    cardName: "BMS 500",
    cardDescription: "Book My Show Gift Card 500",
    cardValue: 500,
    yoyoPoint: 150,
    avgRating: 4,
    ratingComments: [
      {
        id: 1,
        rating: 5,
        comments: "This is good gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 2,
        rating: 3,
        comments: "This is ok type gift card",
        postedBy: "Anynomous User"
      },
      {
        id: 3,
        rating: 4,
        comments: "Good One",
        postedBy: "Anynomous User"
      },
      {
        id: 4,
        rating: 4,
        comments: "Rocking...",
        postedBy: "Anynomous User"
      }
    ]
  }
];

// Using CommonJS style export so we can consume via Node (without using Babel-node)
module.exports = {
  Users,
  UsersOrder,
  Category,
  GiftCards,
  YoyoPaymentHistory
};
