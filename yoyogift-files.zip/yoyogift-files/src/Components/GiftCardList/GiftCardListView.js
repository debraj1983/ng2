import React from "react";

const GiftCardListMain = props => {
  return <div>Gift Card List View Works</div>;
};

export default GiftCardListMain;
