import storage from "./AppStorage";

const STORAGE_KEYS = {
  LOGGEDIN: "loggedIn",
  LOGGEDIN_USER_DETAILS: "loggedInUserDetails"
};

const storageUtility = {
  checkLoggedIn: () => storage.getData(STORAGE_KEYS.LOGGEDIN, "session"),
  getLoggedInUserData: () =>
    storage.getData(STORAGE_KEYS.LOGGEDIN_USER_DETAILS, "session"),
  setLoggedIn: () => storage.setData(STORAGE_KEYS.LOGGEDIN, true, "session"),
  setLoggedInUserData: data =>
    storage.setData(STORAGE_KEYS.LOGGEDIN_USER_DETAILS, data, "session"),
  doLogout: () => storage.clearData("session")
};

export default storageUtility;
