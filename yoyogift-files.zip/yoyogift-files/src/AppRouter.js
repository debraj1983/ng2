import React from "react";
import {
  BrowserRouter as Router,
  Link,
  Route,
  Redirect,
  Switch
} from "react-router-dom";

import RouteConfig from "./AppConstant";
import Header from "./Components/Shared/Header";

class AppRouter extends React.Component {
  render() {
    return (
      <Router>
        <Header></Header>
        <Redirect from="/" to="/gift-card-list" />
        <Switch>
          {RouteConfig.map((config, index) => (
            <Route
              path={config.path}
              component={config.component}
              key={`route${index}`}
            />
          ))}
        </Switch>
      </Router>
    );
  }
}

export default AppRouter;
