export const getGiftCardListAction = () => {};
