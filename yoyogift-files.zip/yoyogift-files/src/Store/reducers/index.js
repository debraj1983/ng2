import { combineReducers } from "redux";
import loginData from "./Login";

export default combineReducers({ loginData });
