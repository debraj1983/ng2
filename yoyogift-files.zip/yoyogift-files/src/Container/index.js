import GiftCardList from "./GiftCardList";
import GiftCardDetails from "./GiftCardDetails";
import Cart from "./Cart";
import Login from "./Login";
import PlaceOrder from "./PlaceOrder";
import PreviewOrder from "./PreviewOrder";
import UserAccount from "./UserAccount";

export default {
  GiftCardList,
  GiftCardDetails,
  Cart,
  Login,
  PlaceOrder,
  PreviewOrder,
  UserAccount
};
