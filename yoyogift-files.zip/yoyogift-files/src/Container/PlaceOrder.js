import React from "react";

class PlaceOrder extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>PlaceOrder Components Work</div>;
  }
}

export default PlaceOrder;
