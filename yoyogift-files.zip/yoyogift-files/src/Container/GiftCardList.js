import React from "react";
import { connect } from "react-redux";

import { getCategoryListAction } from "../Store/actions/CategoryAction";
import { getGiftCardListAction } from "../Store/actions/GiftCardAction";
import GiftCardListMain from "../Components/GiftCardList/GiftCardListView";

class GiftCardList extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <GiftCardListMain></GiftCardListMain>;
  }
}

const mapStateToProps = state => ({
  ...state
});

const mapDispatchToProps = dispatch => ({
  getCatList: () => dispatch(getCategoryListAction()),
  getGiftCards: () => dispatch(getGiftCardListAction())
});

export default connect(mapStateToProps, mapDispatchToProps)(GiftCardList);
