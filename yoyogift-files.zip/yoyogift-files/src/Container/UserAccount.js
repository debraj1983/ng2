import React from "react";

class UserAccount extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>UserAccount Components Work</div>;
  }
}

export default UserAccount;
