import React from "react";

class PreviewOrder extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>Cart Components Work</div>;
  }
}

export default PreviewOrder;
