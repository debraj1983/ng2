import React from "react";

class GiftCardDetails extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>Gift Card details Components Work</div>;
  }
}

export default GiftCardDetails;
