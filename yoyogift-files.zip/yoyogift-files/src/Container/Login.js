import React from "react";

class Login extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>Login Components Work</div>;
  }
}

export default Login;
